package com.company.engineeringmcp;

import org.junit.jupiter.api.Test;

class EngineeringMcpServerApplicationTests {
    @Test
    void placeholder() {
        // Context startup test can be enabled after enterprise Bitbucket config is available.
    }
}
