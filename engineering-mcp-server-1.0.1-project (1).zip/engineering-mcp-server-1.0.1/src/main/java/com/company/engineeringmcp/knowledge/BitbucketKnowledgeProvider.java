package com.company.engineeringmcp.knowledge;

import com.company.engineeringmcp.config.EngineeringMcpProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Starter Bitbucket Server/Data Center provider.
 * Adjust REST paths if your enterprise Bitbucket version differs.
 */
@Component
public class BitbucketKnowledgeProvider implements KnowledgeProvider {
    private final EngineeringMcpProperties props;
    private final RestClient restClient;
    private final ObjectMapper mapper;

    public BitbucketKnowledgeProvider(EngineeringMcpProperties props, ObjectMapper mapper) {
        this.props = props;
        this.mapper = mapper;
        var bb = props.knowledge().bitbucket();
        RestClient.Builder builder = RestClient.builder().baseUrl(bb.baseUrl());
        String token = System.getenv(bb.tokenEnv());
        if (token != null && !token.isBlank()) {
            builder.defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + token);
        }
        this.restClient = builder.build();
    }

    @Override
    public List<KnowledgeDocument> search(String query, int maxResults) {
        // Minimal portable implementation: list configured folders and rank matching markdown files.
        // For large repos, replace this with Bitbucket search API or an indexed cache/vector store.
        List<KnowledgeDocument> docs = new ArrayList<>();
        for (String root : roots()) {
            docs.addAll(scanFolder(root, query, maxResults));
            if (docs.size() >= maxResults) break;
        }
        return docs.stream().limit(maxResults).toList();
    }

    @Override
    public Optional<KnowledgeDocument> getByPath(String path) {
        try {
            var bb = props.knowledge().bitbucket();
            String encoded = encodePath(path);
            String uri = "/rest/api/1.0/projects/%s/repos/%s/raw/%s?at=refs/heads/%s"
                    .formatted(bb.project(), bb.repository(), encoded, bb.branch());
            String content = restClient.get().uri(uri).retrieve().body(String.class);
            if (content == null) return Optional.empty();
            return Optional.of(new KnowledgeDocument(path, trim(content), sourceName(), 1.0));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    private List<KnowledgeDocument> scanFolder(String root, String query, int maxResults) {
        List<KnowledgeDocument> out = new ArrayList<>();
        try {
            var bb = props.knowledge().bitbucket();
            String uri = "/rest/api/1.0/projects/%s/repos/%s/files/%s?at=refs/heads/%s&limit=1000"
                    .formatted(bb.project(), bb.repository(), encodePath(root), bb.branch());
            JsonNode json = restClient.get().uri(uri).retrieve().body(JsonNode.class);
            if (json == null || !json.path("values").isArray()) return out;

            String q = query == null ? "" : query.toLowerCase();
            for (JsonNode node : json.path("values")) {
                String path = node.asText();
                if (!path.toLowerCase().endsWith(".md") && !path.toLowerCase().endsWith(".yml") && !path.toLowerCase().endsWith(".yaml")) continue;
                Optional<KnowledgeDocument> doc = getByPath(path);
                if (doc.isEmpty()) continue;
                String haystack = (path + "\n" + doc.get().content()).toLowerCase();
                double score = q.isBlank() ? 0.1 : simpleScore(haystack, q);
                if (q.isBlank() || score > 0) {
                    out.add(new KnowledgeDocument(path, doc.get().content(), sourceName(), score));
                }
                if (out.size() >= maxResults) break;
            }
        } catch (Exception ignored) {
        }
        return out.stream().sorted((a,b) -> Double.compare(b.score(), a.score())).toList();
    }

    private List<String> roots() {
        var p = props.knowledge().paths();
        return List.of(p.prompts(), p.knowledge(), p.services(), p.serviceCatalog());
    }

    private double simpleScore(String haystack, String query) {
        double score = 0;
        for (String token : query.split("\\s+")) {
            if (token.length() < 2) continue;
            if (haystack.contains(token)) score += 1.0;
        }
        return score;
    }

    private String trim(String content) {
        int max = props.knowledge().retrieval().maxCharsPerResult();
        return content.length() <= max ? content : content.substring(0, max);
    }

    private String encodePath(String path) {
        return URLEncoder.encode(path, StandardCharsets.UTF_8).replace("%2F", "/");
    }

    @Override
    public String sourceName() {
        var bb = props.knowledge().bitbucket();
        return "bitbucket:" + bb.project() + "/" + bb.repository() + "@" + bb.branch();
    }
}
