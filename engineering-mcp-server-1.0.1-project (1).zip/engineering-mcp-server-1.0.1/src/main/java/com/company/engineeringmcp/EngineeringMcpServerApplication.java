package com.company.engineeringmcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class EngineeringMcpServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(EngineeringMcpServerApplication.class, args);
    }
}
