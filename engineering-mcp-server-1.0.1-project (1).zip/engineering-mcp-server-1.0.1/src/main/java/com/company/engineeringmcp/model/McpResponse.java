package com.company.engineeringmcp.model;

import com.fasterxml.jackson.databind.JsonNode;

public record McpResponse(String jsonrpc, JsonNode id, JsonNode result, McpError error) {
    public static McpResponse success(JsonNode id, JsonNode result) {
        return new McpResponse("2.0", id, result, null);
    }

    public static McpResponse error(JsonNode id, int code, String message) {
        return new McpResponse("2.0", id, null, new McpError(code, message));
    }

    public record McpError(int code, String message) {}
}
