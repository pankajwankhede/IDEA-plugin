package com.company.engineeringmcp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "engineering-mcp")
public record EngineeringMcpProperties(Knowledge knowledge, Mcp mcp, Integrations integrations) {
    public record Knowledge(boolean enabled, String provider, Bitbucket bitbucket, Paths paths, Retrieval retrieval, Cache cache) {}
    public record Bitbucket(String baseUrl, String project, String repository, String branch, String tokenEnv) {}
    public record Paths(String prompts, String knowledge, String services, String serviceCatalog) {}
    public record Retrieval(int maxResults, int maxCharsPerResult) {}
    public record Cache(boolean enabled, int refreshMinutes, boolean allowStaleOnBitbucketOutage) {}
    public record Mcp(String endpoint) {}

    public record Integrations(
            Splunk splunk,
            NewRelic newRelic,
            Pcf pcf,
            Database oracle,
            Database sqlServer,
            Jenkins jenkins) {}

    public record Splunk(boolean enabled, String baseUrl, String tokenEnv, String defaultIndex) {}
    public record NewRelic(boolean enabled, String baseUrl, String apiKeyEnv, String accountId) {}
    public record Pcf(boolean enabled, String apiUrl, String tokenEnv, String org, String space) {}
    public record Database(boolean enabled, String jdbcUrl, String usernameEnv, String passwordEnv) {}
    public record Jenkins(boolean enabled, String baseUrl, String usernameEnv, String tokenEnv) {}
}
