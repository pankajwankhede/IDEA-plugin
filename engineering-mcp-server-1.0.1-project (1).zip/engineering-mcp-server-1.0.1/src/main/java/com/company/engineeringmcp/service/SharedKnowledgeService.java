package com.company.engineeringmcp.service;

import com.company.engineeringmcp.config.EngineeringMcpProperties;
import com.company.engineeringmcp.knowledge.KnowledgeDocument;
import com.company.engineeringmcp.knowledge.KnowledgeProvider;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SharedKnowledgeService {
    private final KnowledgeProvider provider;
    private final EngineeringMcpProperties props;

    public SharedKnowledgeService(KnowledgeProvider provider, EngineeringMcpProperties props) {
        this.provider = provider;
        this.props = props;
    }

    public List<KnowledgeDocument> search(String query) {
        return provider.search(query, props.knowledge().retrieval().maxResults());
    }

    public Optional<KnowledgeDocument> getPrompt(String name) {
        String base = props.knowledge().paths().prompts();
        return provider.getByPath(base + "/" + normalizeMd(name));
    }

    public List<KnowledgeDocument> getServiceContext(String service, String environment) {
        return search(service + " " + (environment == null ? "" : environment));
    }

    private String normalizeMd(String name) {
        String n = name.endsWith(".md") ? name : name + ".md";
        return n.replace("..", "").replace("\\", "/");
    }
}
