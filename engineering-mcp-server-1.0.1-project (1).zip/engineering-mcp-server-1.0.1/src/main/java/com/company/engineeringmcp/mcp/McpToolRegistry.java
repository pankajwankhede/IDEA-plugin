package com.company.engineeringmcp.mcp;

import com.company.engineeringmcp.config.EngineeringMcpProperties;
import com.company.engineeringmcp.knowledge.KnowledgeDocument;
import com.company.engineeringmcp.service.SharedKnowledgeService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class McpToolRegistry {
    private final SharedKnowledgeService knowledge;
    private final ObjectMapper mapper;
    private final EngineeringMcpProperties properties;

    public McpToolRegistry(SharedKnowledgeService knowledge, ObjectMapper mapper, EngineeringMcpProperties properties) {
        this.knowledge = knowledge;
        this.mapper = mapper;
        this.properties = properties;
    }

    public ArrayNode listTools() {
        ArrayNode tools = mapper.createArrayNode();

        if (properties.knowledge() == null || properties.knowledge().enabled()) {
            tools.add(tool("search_shared_docs",
                    "Search centralized xyzagent knowledge, prompts, services and catalogs",
                    oneStringFieldSchema("query", true)));
            tools.add(tool("get_prompt",
                    "Read a named prompt from xyzagent/prompts",
                    oneStringFieldSchema("name", true)));

            ObjectNode serviceSchema = mapper.createObjectNode();
            serviceSchema.put("type", "object");
            ObjectNode serviceProps = serviceSchema.putObject("properties");
            serviceProps.putObject("service").put("type", "string");
            serviceProps.putObject("environment").put("type", "string");
            serviceSchema.putArray("required").add("service");
            tools.add(tool("get_service_context",
                    "Get centralized shared context for a service/environment",
                    serviceSchema));
        }

        EngineeringMcpProperties.Integrations i = properties.integrations();
        if (i != null) {
            if (i.splunk() != null && i.splunk().enabled()) {
                tools.add(tool("search_splunk", "Search Splunk logs", searchSchema()));
            }
            if (i.newRelic() != null && i.newRelic().enabled()) {
                tools.add(tool("search_new_relic", "Search New Relic telemetry and traces", searchSchema()));
            }
            if (i.pcf() != null && i.pcf().enabled()) {
                tools.add(tool("get_pcf_app_status", "Get PCF application/runtime status", serviceEnvironmentSchema()));
            }
            if (i.oracle() != null && i.oracle().enabled()) {
                tools.add(tool("query_oracle", "Execute an approved read-only Oracle query", oneStringFieldSchema("query", true)));
            }
            if (i.sqlServer() != null && i.sqlServer().enabled()) {
                tools.add(tool("query_sql_server", "Execute an approved read-only SQL Server query", oneStringFieldSchema("query", true)));
            }
            if (i.jenkins() != null && i.jenkins().enabled()) {
                ObjectNode schema = mapper.createObjectNode();
                schema.put("type", "object");
                ObjectNode props = schema.putObject("properties");
                props.putObject("job").put("type", "string");
                props.putObject("build").put("type", "string");
                schema.putArray("required").add("job");
                tools.add(tool("get_jenkins_build", "Get Jenkins job/build information", schema));
            }
        }
        return tools;
    }

    public JsonNode call(String name, JsonNode args) {
        JsonNode safeArgs = args == null || args.isMissingNode() ? mapper.createObjectNode() : args;
        return switch (name) {
            case "search_shared_docs" -> enabledKnowledge(name)
                    ? asContent(knowledge.search(safeArgs.path("query").asText("")))
                    : disabled(name);
            case "get_prompt" -> enabledKnowledge(name)
                    ? knowledge.getPrompt(safeArgs.path("name").asText(""))
                        .<JsonNode>map(d -> asContent(List.of(d)))
                        .orElseGet(() -> errorContent("Prompt not found"))
                    : disabled(name);
            case "get_service_context" -> enabledKnowledge(name)
                    ? asContent(knowledge.getServiceContext(
                        safeArgs.path("service").asText(""), safeArgs.path("environment").asText("")))
                    : disabled(name);
            case "search_splunk" -> integrationStub("Splunk", isSplunkEnabled());
            case "search_new_relic" -> integrationStub("New Relic", isNewRelicEnabled());
            case "get_pcf_app_status" -> integrationStub("PCF", isPcfEnabled());
            case "query_oracle" -> integrationStub("Oracle", isOracleEnabled());
            case "query_sql_server" -> integrationStub("SQL Server", isSqlServerEnabled());
            case "get_jenkins_build" -> integrationStub("Jenkins", isJenkinsEnabled());
            default -> errorContent("Unknown tool: " + name);
        };
    }

    private boolean enabledKnowledge(String ignored) {
        return properties.knowledge() == null || properties.knowledge().enabled();
    }

    private boolean isSplunkEnabled() { return properties.integrations() != null && properties.integrations().splunk() != null && properties.integrations().splunk().enabled(); }
    private boolean isNewRelicEnabled() { return properties.integrations() != null && properties.integrations().newRelic() != null && properties.integrations().newRelic().enabled(); }
    private boolean isPcfEnabled() { return properties.integrations() != null && properties.integrations().pcf() != null && properties.integrations().pcf().enabled(); }
    private boolean isOracleEnabled() { return properties.integrations() != null && properties.integrations().oracle() != null && properties.integrations().oracle().enabled(); }
    private boolean isSqlServerEnabled() { return properties.integrations() != null && properties.integrations().sqlServer() != null && properties.integrations().sqlServer().enabled(); }
    private boolean isJenkinsEnabled() { return properties.integrations() != null && properties.integrations().jenkins() != null && properties.integrations().jenkins().enabled(); }

    private JsonNode integrationStub(String integration, boolean enabled) {
        if (!enabled) return disabled(integration);
        return errorContent(integration + " integration is enabled and advertised by MCP, but its concrete adapter is not implemented in this starter project yet.");
    }

    private JsonNode disabled(String tool) {
        return errorContent(tool + " is disabled by engineering-mcp configuration");
    }

    private ObjectNode searchSchema() {
        ObjectNode schema = mapper.createObjectNode();
        schema.put("type", "object");
        ObjectNode props = schema.putObject("properties");
        props.putObject("query").put("type", "string");
        props.putObject("environment").put("type", "string");
        props.putObject("service").put("type", "string");
        schema.putArray("required").add("query");
        return schema;
    }

    private ObjectNode serviceEnvironmentSchema() {
        ObjectNode schema = mapper.createObjectNode();
        schema.put("type", "object");
        ObjectNode props = schema.putObject("properties");
        props.putObject("service").put("type", "string");
        props.putObject("environment").put("type", "string");
        schema.putArray("required").add("service");
        return schema;
    }

    private ObjectNode oneStringFieldSchema(String field, boolean required) {
        ObjectNode schema = mapper.createObjectNode();
        schema.put("type", "object");
        schema.putObject("properties").putObject(field).put("type", "string");
        if (required) schema.putArray("required").add(field);
        return schema;
    }

    private ObjectNode tool(String name, String description, ObjectNode inputSchema) {
        ObjectNode t = mapper.createObjectNode();
        t.put("name", name);
        t.put("description", description);
        t.set("inputSchema", inputSchema);
        return t;
    }

    private JsonNode asContent(List<KnowledgeDocument> docs) {
        ObjectNode result = mapper.createObjectNode();
        ArrayNode content = result.putArray("content");
        for (KnowledgeDocument d : docs) {
            ObjectNode item = content.addObject();
            item.put("type", "text");
            item.put("text", "SOURCE: " + d.source() + "\nPATH: " + d.path() + "\nSCORE: " + d.score() + "\n\n" + d.content());
        }
        result.put("isError", false);
        return result;
    }

    private JsonNode errorContent(String message) {
        ObjectNode result = mapper.createObjectNode();
        result.putArray("content").addObject().put("type", "text").put("text", message);
        result.put("isError", true);
        return result;
    }
}
