package com.company.engineeringmcp.knowledge;

public record KnowledgeDocument(String path, String content, String source, double score) {}
