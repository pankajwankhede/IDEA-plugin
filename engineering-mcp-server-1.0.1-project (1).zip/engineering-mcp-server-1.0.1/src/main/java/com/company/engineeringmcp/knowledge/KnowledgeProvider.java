package com.company.engineeringmcp.knowledge;

import java.util.List;
import java.util.Optional;

public interface KnowledgeProvider {
    List<KnowledgeDocument> search(String query, int maxResults);
    Optional<KnowledgeDocument> getByPath(String path);
    String sourceName();
}
