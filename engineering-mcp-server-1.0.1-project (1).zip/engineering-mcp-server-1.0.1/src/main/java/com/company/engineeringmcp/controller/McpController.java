package com.company.engineeringmcp.controller;

import com.company.engineeringmcp.mcp.McpToolRegistry;
import com.company.engineeringmcp.model.McpRequest;
import com.company.engineeringmcp.model.McpResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class McpController {
    private final McpToolRegistry tools;
    private final ObjectMapper mapper;

    public McpController(McpToolRegistry tools, ObjectMapper mapper) {
        this.tools = tools;
        this.mapper = mapper;
    }

    @PostMapping(value = "/mcp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public McpResponse handle(@RequestBody McpRequest req) {
        if (req == null || req.method() == null) {
            return McpResponse.error(req == null ? null : req.id(), -32600, "Invalid Request");
        }

        return switch (req.method()) {
            case "initialize" -> McpResponse.success(req.id(), initializeResult());
            case "tools/list" -> {
                ObjectNode result = mapper.createObjectNode();
                result.set("tools", tools.listTools());
                yield McpResponse.success(req.id(), result);
            }
            case "tools/call" -> handleToolCall(req);
            default -> McpResponse.error(req.id(), -32601, "Method not found: " + req.method());
        };
    }

    private McpResponse handleToolCall(McpRequest req) {
        JsonNode p = req.params();
        if (p == null || p.path("name").asText().isBlank()) {
            return McpResponse.error(req.id(), -32602, "Missing tool name");
        }
        return McpResponse.success(req.id(), tools.call(p.path("name").asText(), p.path("arguments")));
    }

    private JsonNode initializeResult() {
        ObjectNode result = mapper.createObjectNode();
        result.put("protocolVersion", "2025-06-18");
        result.putObject("capabilities").putObject("tools");
        result.putObject("serverInfo")
                .put("name", "engineering-mcp-server")
                .put("version", "1.0.0");
        return result;
    }
}
