rootProject.name = "engineering-mcp-server"
