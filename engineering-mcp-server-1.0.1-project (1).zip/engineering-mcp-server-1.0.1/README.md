# Engineering MCP Server 1.0.0

Standalone MCP server for the Engineering AI IntelliJ plugin.

## Baseline
- Java 21
- Spring Boot 4.1.0
- Gradle Kotlin DSL
- MCP JSON-RPC endpoint: `POST /mcp`
- Centralized Bitbucket knowledge repo: `xyzagent`

## Tools included
- `search_shared_docs`
- `get_prompt`
- `get_service_context`

The IntelliJ plugin only needs the MCP URL, for example:

```text
https://engineering-mcp.company.com/mcp
```

Bitbucket configuration and credentials stay on this server.

## Bitbucket repository example

```text
xyzagent/
├── prompts/
│   ├── system-prompt.md
│   └── investigation.md
├── knowledge/
│   ├── architecture/
│   └── troubleshooting/
├── services/
│   └── bc-login.md
└── service-catalog/
    └── bc-login.yml
```

## Configure
Update `src/main/resources/application.yml`:

```yaml
engineering-mcp:
  knowledge:
    bitbucket:
      base-url: https://bitbucket.company.com
      project: ENGINEERING
      repository: xyzagent
      branch: main
      token-env: BITBUCKET_TOKEN
```

Set the token outside source control:

```bash
export BITBUCKET_TOKEN=...
```

If your enterprise Bitbucket uses Basic auth, OAuth, mTLS, SSO gateway headers, or a different REST path, adapt `BitbucketKnowledgeProvider`.

## Run

```bash
./gradlew bootRun
```

If no Gradle wrapper exists yet:

```bash
gradle wrapper
./gradlew bootRun
```

## Build

```bash
./gradlew clean build
```

The JAR will be under `build/libs/`.

## Quick MCP examples

Initialize:

```json
{
  "jsonrpc":"2.0",
  "id":1,
  "method":"initialize",
  "params":{}
}
```

List tools:

```json
{
  "jsonrpc":"2.0",
  "id":2,
  "method":"tools/list",
  "params":{}
}
```

Search docs:

```json
{
  "jsonrpc":"2.0",
  "id":3,
  "method":"tools/call",
  "params":{
    "name":"search_shared_docs",
    "arguments":{"query":"bc-login null pointer qa"}
  }
}
```

## Recommended production additions
- Bitbucket content cache + stale fallback
- enterprise auth / mTLS
- request correlation IDs
- Splunk / New Relic / PCF tools
- service-catalog indexing
- rate limiting
- audit logging
- circuit breaker / timeout policies
- structured knowledge ranking or vector search for large repositories

## Integration enable/disable switches (v1.0.1)

The MCP server can independently enable or disable Splunk, New Relic, PCF, Oracle, SQL Server, and Jenkins.

```yaml
engineering-mcp:
  integrations:
    splunk:
      enabled: true
    new-relic:
      enabled: false
    pcf:
      enabled: true
    oracle:
      enabled: false
    sql-server:
      enabled: false
    jenkins:
      enabled: true
```

Behavior:

- `enabled: true` → the integration's MCP tool is returned by `tools/list`.
- `enabled: false` → the tool is not advertised and direct calls are rejected.
- No IntelliJ plugin rebuild is required. Change the MCP server configuration and restart/redeploy the server.
- Credentials are referenced by environment-variable names; secrets are not stored in `application.yml`.

Starter tool names:

| Integration | MCP tool |
| --- | --- |
| Splunk | `search_splunk` |
| New Relic | `search_new_relic` |
| PCF | `get_pcf_app_status` |
| Oracle | `query_oracle` |
| SQL Server | `query_sql_server` |
| Jenkins | `get_jenkins_build` |

The enable/disable and dynamic tool-advertising layer is implemented. The concrete enterprise API/JDBC adapters for these six tools remain extension points in this starter project and should be wired to your organization's endpoints and authentication mechanisms.
