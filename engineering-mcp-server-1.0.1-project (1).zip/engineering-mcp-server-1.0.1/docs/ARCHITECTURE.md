# Architecture

```text
IntelliJ Plugin
      |
      v
LLM Gateway (optional)
      |
      v
Engineering MCP Server
      |
      +-- Bitbucket xyzagent
      +-- Splunk (future)
      +-- New Relic (future)
      +-- PCF (future)
      +-- Database (future)
```

The plugin should not receive Bitbucket credentials. The MCP server owns enterprise integrations and exposes only MCP tools.
