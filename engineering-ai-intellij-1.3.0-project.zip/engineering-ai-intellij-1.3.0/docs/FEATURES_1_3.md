# Engineering AI IntelliJ 1.3.0

## UI modes

The plugin now has four tabs:

- **AI Chat** — natural-language LLM experience. The LLM can automatically choose tools returned by MCP `tools/list`.
- **MCP Tools** — no-LLM/direct MCP mode. Select a tool, edit its generated JSON arguments, and run `tools/call`.
- **Knowledge Base** — browse/search centralized agents, skills, instructions, scripts and shared docs through MCP.
- **History** — current-session prompt/source history.

## Local source selection

AI Chat supports:

- Selected Code
- Current File
- Choose File...
- Choose Folder...

The IntelliJ plugin reads local source content and sends the content as context. The MCP server does not read the developer's local disk.

Folder collection is bounded by plugin settings and ignores common generated folders such as `.git`, `build`, `target`, `node_modules`, `out` and `dist`.

## Dynamic integration visibility

The plugin does **not** need hardcoded frontend enable/disable flags for Splunk, New Relic, PCF, Oracle, SQL Server or Jenkins.

It calls MCP `tools/list` and infers capabilities from the tools actually returned. Only enabled/available sources are rendered in the plugin header. Disabled server integrations stay hidden.

Example current state:

```text
Available: [Knowledge Base]
```

Later, if the MCP server enables more tools:

```text
Available: [Knowledge Base] [Splunk] [New Relic] [PCF] [Jenkins]
```

No plugin rebuild is required for those server-side enable/disable changes as long as the tool contracts remain compatible.

## LLM ON

```text
Local selected/current/chosen source
          +
Natural-language prompt
          ↓
LLM Gateway
          ↓
MCP tools/list
          ↓
LLM selects available MCP tools when useful
          ↓
Final answer
```

## LLM OFF / Direct MCP

```text
Refresh MCP Tools
      ↓
tools/list
      ↓
Select MCP tool
      ↓
Fill JSON arguments
      ↓
(optionally attach Selected Code / Current File / Chosen File / Chosen Folder
 when the tool inputSchema supports code/context/source/content)
      ↓
tools/call
      ↓
Raw/formatted MCP result
```

This lets future tools such as `review_local_code` receive local IntelliJ source without an LLM. The MCP server never reads the developer machine directly; the plugin injects the selected source content into the tool arguments only when the schema declares a compatible field.

AI Chat is disabled when LLM is OFF; users are directed to the MCP Tools tab.

## Knowledge Base tool conventions

If the MCP server exposes them, the Knowledge Base tab uses:

```text
list_agents / get_agent
list_skills / get_skill
list_instructions / get_instruction
list_scripts / get_script
search_shared_docs
```

The plugin connects only to the MCP server. Bitbucket repository URL, credentials, caching and access policy stay server-side.
