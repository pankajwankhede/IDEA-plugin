# MCP Shared Knowledge Contract

The IntelliJ plugin does not access Bitbucket directly. It discovers tools dynamically through MCP `tools/list`.

Recommended knowledge tools:

```text
search_shared_docs
list_agents
get_agent
list_skills
get_skill
list_instructions
get_instruction
list_scripts
get_script
get_service_context
```

The plugin's Knowledge Base tab only enables operations whose tools are actually returned by `tools/list`.

Example `get_skill` tool schema:

```json
{
  "name": "get_skill",
  "description": "Read a named shared engineering skill",
  "inputSchema": {
    "type": "object",
    "properties": {
      "name": { "type": "string" }
    },
    "required": ["name"]
  }
}
```

Operational integrations such as Splunk, New Relic, PCF, Oracle, SQL Server and Jenkins follow the same rule: if their tools are not returned by `tools/list`, the plugin treats those integrations as unavailable and hides them from the enabled-source summary.
