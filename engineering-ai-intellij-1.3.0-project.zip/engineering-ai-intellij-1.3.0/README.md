# Engineering AI IntelliJ Plugin 1.3.0

Java 21 IntelliJ Platform plugin for enterprise engineering assistance through an optional LLM gateway and an external MCP server.

## Architecture

```text
IntelliJ Plugin
   |
   +-- local selected/current/chosen source context
   |
   +-- LLM Gateway (optional)
   |
   +-- engineering-mcp-server
           |
           +-- centralized Bitbucket knowledge
           +-- Splunk (optional)
           +-- New Relic (optional)
           +-- PCF (optional)
           +-- Oracle (optional)
           +-- SQL Server (optional)
           +-- Jenkins (optional)
```

The plugin never stores Bitbucket or operational-system credentials.

## What's new in 1.3.0

- AI Chat, MCP Tools, Knowledge Base and History tabs.
- LLM ON = natural-language chat + automatic MCP tool use.
- LLM OFF / DIRECT_MCP = manual MCP tool selection; no fake natural-language orchestration.
- Local source selector: Selected Code / Current File / Choose File / Choose Folder.
- Dynamic MCP tool dropdown from `tools/list`.
- Dynamic integration visibility inferred from `tools/list`; disabled server integrations stay hidden.
- Knowledge Base browser for agents, skills, instructions, scripts and shared docs when the matching tools exist.
- Better MCP HTTP/JSON-RPC error messages.
- Java 21 baseline.
- MCP initialize protocol set to `2025-03-26` for the current server contract.

See `docs/FEATURES_1_3.md`.

## Configure

In IntelliJ:

```text
Settings -> Engineering AI
```

Local development example:

```text
Mode: AUTO
Enable LLM gateway: true
LLM Gateway URL: http://localhost:8081/v1/chat/completions
MCP Server URL: http://localhost:8080/mcp
```

For no-LLM operation:

```text
Mode: DIRECT_MCP
Enable LLM: false
MCP Server URL: http://localhost:8080/mcp
```

Then use:

```text
Engineering AI -> MCP Tools -> Refresh MCP Tools
```

## Build

Set Project SDK and Gradle JVM to Java 21.

```bat
gradlew.bat runIde
```

for the development sandbox, or:

```bat
gradlew.bat clean buildPlugin
```

for the installable plugin ZIP under:

```text
build/distributions/
```

## Central knowledge

The plugin uses a generic display label such as:

```text
Bitbucket company-ai-agent
```

The real repository details are configured only in `engineering-mcp-server`.
