package com.company.engineeringai.context;

import com.company.engineeringai.settings.EngineeringAiSettings;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

public final class IdeContextProvider {
    public enum SourceScope { SELECTED_CODE, CURRENT_FILE, CHOOSE_FILE, CHOOSE_FOLDER }

    private static final Set<String> ALLOWED_EXTENSIONS = Set.of(
            "java","kt","kts","xml","yml","yaml","properties","gradle","groovy","js","ts","tsx","jsx","json","md","sql"
    );
    private static final Set<String> IGNORED_DIRS = Set.of(".git",".idea","build","target","node_modules","out","dist");

    private IdeContextProvider() {}

    /** Backward-compatible default context used by editor action. */
    public static String collect(Project project) {
        EngineeringAiSettings.StateData s = EngineeringAiSettings.getInstance().getState();
        if (s == null) return "";
        Editor editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
        if (editor == null) return "";
        String selected = editor.getSelectionModel().getSelectedText();
        if (s.includeSelectedCode && selected != null && !selected.isBlank()) {
            return collectSelectedCode(project);
        }
        return s.includeCurrentFile ? collectCurrentFile(project) : "";
    }

    public static String collectSelectedCode(Project project) {
        Editor editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
        if (editor == null) return "No active editor.";
        String selected = editor.getSelectionModel().getSelectedText();
        if (selected == null || selected.isBlank()) return "No code is selected in the active editor.";
        VirtualFile file = FileDocumentManager.getInstance().getFile(editor.getDocument());
        return header("SELECTED_CODE", file == null ? "unknown" : file.getPath(), selected);
    }

    public static String collectCurrentFile(Project project) {
        Editor editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
        if (editor == null) return "No active editor.";
        VirtualFile file = FileDocumentManager.getInstance().getFile(editor.getDocument());
        String text = editor.getDocument().getText();
        return header("CURRENT_FILE", file == null ? "unknown" : file.getPath(), truncate(text));
    }

    public static String collectFile(Path path) throws IOException {
        if (path == null) return "No file selected.";
        String text = Files.readString(path, StandardCharsets.UTF_8);
        return header("CHOSEN_FILE", path.toAbsolutePath().toString(), truncate(text));
    }

    public static String collectFolder(Path root) throws IOException {
        if (root == null) return "No folder selected.";
        var s = EngineeringAiSettings.getInstance().getState();
        int maxFiles = s == null ? 50 : Math.max(1, s.maxFolderFiles);
        List<Path> files = new ArrayList<>();
        try (Stream<Path> walk = Files.walk(root)) {
            walk.filter(Files::isRegularFile)
                    .filter(IdeContextProvider::isAllowed)
                    .filter(p -> !containsIgnoredDir(root, p))
                    .limit(maxFiles)
                    .forEach(files::add);
        }
        StringBuilder out = new StringBuilder();
        out.append("### CHOSEN_FOLDER: ").append(root.toAbsolutePath()).append("\n");
        out.append("### FILE_COUNT: ").append(files.size()).append(" (max ").append(maxFiles).append(")\n\n");
        for (Path p : files) {
            try {
                String text = Files.readString(p, StandardCharsets.UTF_8);
                out.append("\n--- FILE: ").append(root.relativize(p)).append(" ---\n").append(truncate(text)).append("\n");
            } catch (Exception ex) {
                out.append("\n--- FILE: ").append(root.relativize(p)).append(" ---\n[unreadable: ").append(ex.getMessage()).append("]\n");
            }
        }
        return out.toString();
    }

    private static String header(String kind, String path, String text) {
        return "### " + kind + ": " + path + "\n" + text;
    }

    private static String truncate(String text) {
        var s = EngineeringAiSettings.getInstance().getState();
        int max = s == null ? 120000 : Math.max(1000, s.maxFileChars);
        if (text == null) return "";
        return text.length() > max ? text.substring(0, max) + "\n...[truncated]" : text;
    }

    private static boolean isAllowed(Path p) {
        String name = p.getFileName().toString();
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length()-1) return false;
        return ALLOWED_EXTENSIONS.contains(name.substring(dot+1).toLowerCase(Locale.ROOT));
    }

    private static boolean containsIgnoredDir(Path root, Path p) {
        Path rel = root.relativize(p);
        for (Path part : rel) if (IGNORED_DIRS.contains(part.toString())) return true;
        return false;
    }
}
