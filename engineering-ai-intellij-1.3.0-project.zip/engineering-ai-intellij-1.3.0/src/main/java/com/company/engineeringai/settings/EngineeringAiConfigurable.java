package com.company.engineeringai.settings;

import com.intellij.openapi.options.Configurable;
import com.intellij.ui.components.*;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.Nullable;

import javax.swing.*;
import java.awt.*;

public final class EngineeringAiConfigurable implements Configurable {
    private JPanel panel;
    private JComboBox<String> mode;
    private JBCheckBox llmEnabled;
    private JBTextField llmUrl, llmModel, llmTokenEnv, maxToolRounds;
    private JBTextField mcpUrl, centralKnowledgeLabel, maxFolderFiles, maxFileChars;
    private JBCheckBox useCentralKnowledge, includeCurrentFile, includeSelectedCode;

    @Override public @Nls String getDisplayName() { return "Engineering AI"; }

    @Override
    public @Nullable JComponent createComponent() {
        panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 6, 5, 6); c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1;

        mode = new JComboBox<>(new String[]{"AUTO", "LLM_GATEWAY", "DIRECT_MCP"});
        llmEnabled = new JBCheckBox("Enable LLM gateway");
        llmUrl = new JBTextField(); llmModel = new JBTextField(); llmTokenEnv = new JBTextField(); maxToolRounds = new JBTextField();
        mcpUrl = new JBTextField(); centralKnowledgeLabel = new JBTextField();
        useCentralKnowledge = new JBCheckBox("Use centralized knowledge through MCP");
        includeCurrentFile = new JBCheckBox("Allow current-file context");
        includeSelectedCode = new JBCheckBox("Allow selected-code context");
        maxFolderFiles = new JBTextField(); maxFileChars = new JBTextField();

        int row = 0;
        addSection("AI orchestration", row++, c);
        addRow("Mode", mode, row++, c);
        c.gridx=0; c.gridy=row++; c.gridwidth=2; panel.add(llmEnabled,c);
        addRow("LLM Gateway URL", llmUrl, row++, c);
        addRow("LLM model", llmModel, row++, c);
        addRow("LLM token env variable", llmTokenEnv, row++, c);
        addRow("Max MCP tool rounds", maxToolRounds, row++, c);

        addSection("MCP", row++, c);
        addRow("MCP server URL", mcpUrl, row++, c);
        GridBagConstraints note=(GridBagConstraints)c.clone(); note.gridx=0; note.gridy=row++; note.gridwidth=2;
        panel.add(new JBLabel("<html><small>The plugin discovers enabled integrations from MCP <b>tools/list</b>. Disabled server integrations are hidden automatically.</small></html>"), note);

        addSection("Central shared knowledge", row++, c);
        c.gridx=0; c.gridy=row++; c.gridwidth=2; panel.add(useCentralKnowledge,c);
        addRow("Knowledge source label", centralKnowledgeLabel, row++, c);

        addSection("IDE source context", row++, c);
        c.gridx=0; c.gridy=row++; c.gridwidth=2; panel.add(includeCurrentFile,c);
        c.gridy=row++; panel.add(includeSelectedCode,c);
        addRow("Max files for folder source", maxFolderFiles, row++, c);
        addRow("Max characters per file", maxFileChars, row++, c);

        c.gridx=0; c.gridy=row; c.gridwidth=2; c.weighty=1; c.fill=GridBagConstraints.BOTH; panel.add(Box.createVerticalGlue(),c);

        llmEnabled.addActionListener(e -> refreshLlmFieldState());
        mode.addActionListener(e -> refreshLlmFieldState());
        reset();
        return panel;
    }

    private void refreshLlmFieldState() {
        boolean direct = "DIRECT_MCP".equals(String.valueOf(mode.getSelectedItem()));
        boolean enabled = llmEnabled.isSelected() && !direct;
        llmEnabled.setEnabled(!direct);
        llmUrl.setEnabled(enabled); llmModel.setEnabled(enabled); llmTokenEnv.setEnabled(enabled); maxToolRounds.setEnabled(enabled);
    }

    private void addSection(String text, int row, GridBagConstraints base) {
        GridBagConstraints x=(GridBagConstraints)base.clone(); x.gridx=0; x.gridy=row; x.gridwidth=2;
        panel.add(new JBLabel("<html><b>"+text+"</b></html>"),x);
    }
    private void addRow(String label, JComponent field, int row, GridBagConstraints base) {
        GridBagConstraints l=(GridBagConstraints)base.clone(); l.gridx=0; l.gridy=row; l.weightx=0; l.gridwidth=1; panel.add(new JBLabel(label),l);
        GridBagConstraints f=(GridBagConstraints)base.clone(); f.gridx=1; f.gridy=row; f.weightx=1; f.gridwidth=1; panel.add(field,f);
    }

    @Override public boolean isModified() {
        var s=EngineeringAiSettings.getInstance().getState(); if(s==null)return true;
        return !String.valueOf(mode.getSelectedItem()).equals(s.mode)
                || llmEnabled.isSelected()!=s.llmEnabled
                || !llmUrl.getText().equals(s.llmUrl) || !llmModel.getText().equals(s.llmModel)
                || !llmTokenEnv.getText().equals(s.llmTokenEnv) || !maxToolRounds.getText().equals(String.valueOf(s.maxToolRounds))
                || !mcpUrl.getText().equals(s.mcpUrl)
                || useCentralKnowledge.isSelected()!=s.useCentralKnowledge
                || !centralKnowledgeLabel.getText().equals(s.centralKnowledgeLabel)
                || includeCurrentFile.isSelected()!=s.includeCurrentFile
                || includeSelectedCode.isSelected()!=s.includeSelectedCode
                || !maxFolderFiles.getText().equals(String.valueOf(s.maxFolderFiles))
                || !maxFileChars.getText().equals(String.valueOf(s.maxFileChars));
    }

    @Override public void apply() {
        var s=EngineeringAiSettings.getInstance().getState(); if(s==null)return;
        s.mode=String.valueOf(mode.getSelectedItem()); s.llmEnabled=llmEnabled.isSelected();
        s.llmUrl=llmUrl.getText().trim(); s.llmModel=llmModel.getText().trim(); s.llmTokenEnv=llmTokenEnv.getText().trim();
        s.maxToolRounds=parseInt(maxToolRounds.getText(),6); s.mcpUrl=mcpUrl.getText().trim();
        s.useCentralKnowledge=useCentralKnowledge.isSelected(); s.centralKnowledgeLabel=centralKnowledgeLabel.getText().trim();
        s.includeCurrentFile=includeCurrentFile.isSelected(); s.includeSelectedCode=includeSelectedCode.isSelected();
        s.maxFolderFiles=parseInt(maxFolderFiles.getText(),50); s.maxFileChars=parseInt(maxFileChars.getText(),120000);
    }

    @Override public void reset() {
        var s=EngineeringAiSettings.getInstance().getState(); if(s==null||mcpUrl==null)return;
        mode.setSelectedItem(s.mode); llmEnabled.setSelected(s.llmEnabled); llmUrl.setText(s.llmUrl); llmModel.setText(s.llmModel);
        llmTokenEnv.setText(s.llmTokenEnv); maxToolRounds.setText(String.valueOf(s.maxToolRounds)); mcpUrl.setText(s.mcpUrl);
        useCentralKnowledge.setSelected(s.useCentralKnowledge); centralKnowledgeLabel.setText(s.centralKnowledgeLabel);
        includeCurrentFile.setSelected(s.includeCurrentFile); includeSelectedCode.setSelected(s.includeSelectedCode);
        maxFolderFiles.setText(String.valueOf(s.maxFolderFiles)); maxFileChars.setText(String.valueOf(s.maxFileChars)); refreshLlmFieldState();
    }

    @Override public void disposeUIResources() { panel=null; }
    private int parseInt(String value,int fallback){try{return Integer.parseInt(value.trim());}catch(Exception ignored){return fallback;}}
}
