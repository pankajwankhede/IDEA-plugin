package com.company.engineeringai.llm;

import com.company.engineeringai.settings.EngineeringAiSettings;
import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;

/** Client for an OpenAI-compatible enterprise Chat Completions gateway. */
public final class LlmGatewayClient {
    private final HttpClient client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    private final Gson gson=new Gson();

    public JsonObject chat(JsonArray messages, JsonArray tools) throws Exception {
        var s=EngineeringAiSettings.getInstance().getState();
        if(s==null||s.llmUrl==null||s.llmUrl.isBlank())throw new IllegalStateException("Configure LLM Gateway URL in Settings > Engineering AI.");
        JsonObject body=new JsonObject(); body.addProperty("model",s.llmModel); body.add("messages",messages);
        if(tools!=null&&!tools.isEmpty()){body.add("tools",tools);body.addProperty("tool_choice","auto");}

        HttpRequest.Builder b=HttpRequest.newBuilder().uri(URI.create(s.llmUrl)).timeout(Duration.ofSeconds(120))
                .header("Content-Type","application/json").POST(HttpRequest.BodyPublishers.ofString(gson.toJson(body)));
        if(s.llmTokenEnv!=null&&!s.llmTokenEnv.isBlank()){
            String token=System.getenv(s.llmTokenEnv);
            if(token!=null&&!token.isBlank())b.header("Authorization","Bearer "+token);
        }
        HttpResponse<String> r=client.send(b.build(),HttpResponse.BodyHandlers.ofString());
        if(r.statusCode()<200||r.statusCode()>=300)throw new IllegalStateException("LLM Gateway HTTP "+r.statusCode()+": "+r.body());
        JsonObject root=JsonParser.parseString(r.body()).getAsJsonObject();
        if(root.has("error"))throw new IllegalStateException("LLM Gateway error: "+root.get("error"));
        JsonArray choices=root.getAsJsonArray("choices"); if(choices==null||choices.isEmpty())throw new IllegalStateException("LLM Gateway returned no choices.");
        return choices.get(0).getAsJsonObject().getAsJsonObject("message");
    }
}
