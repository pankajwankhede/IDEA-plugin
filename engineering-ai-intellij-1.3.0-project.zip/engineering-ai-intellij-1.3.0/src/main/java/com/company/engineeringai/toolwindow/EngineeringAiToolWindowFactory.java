package com.company.engineeringai.toolwindow;

import com.company.engineeringai.context.IdeContextProvider;
import com.company.engineeringai.mcp.McpCapabilities;
import com.company.engineeringai.mcp.McpClient;
import com.company.engineeringai.orchestrator.AiOrchestrator;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.google.gson.*;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowFactory;
import com.intellij.ui.components.*;
import com.intellij.ui.content.Content;
import com.intellij.ui.content.ContentFactory;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.*;
import java.nio.file.Path;
import java.util.*;
import java.util.List;

/**
 * Engineering AI 1.3.0 UI.
 * - AI Chat (LLM ON): natural-language prompt + local source selection + automatic MCP tools.
 * - MCP Tools: manual/no-LLM tools/list + tools/call.
 * - Knowledge Base: browse centralized agents/skills/instructions/scripts through MCP.
 * - History: current-session prompt/result history.
 * Enabled integrations are inferred from MCP tools/list; disabled integrations are not shown.
 */
public final class EngineeringAiToolWindowFactory implements ToolWindowFactory {
    private final McpClient mcp = new McpClient();
    private JsonArray currentTools = new JsonArray();
    private final Map<String, JsonObject> toolsByName = new LinkedHashMap<>();

    private JPanel integrationsPanel;
    private JLabel llmStatus;
    private JButton sendChat;
    private JComboBox<String> sourceScope;
    private JBTextField sourcePath;
    private Path chosenPath;
    private JBTextArea chatPrompt;
    private JBTextArea chatOutput;

    private JComboBox<String> toolCombo;
    private JBTextArea toolDescription;
    private JBTextArea toolArgs;
    private JBTextArea toolOutput;
    private JBCheckBox attachMcpSource;
    private JComboBox<String> mcpSourceScope;
    private JBTextField mcpSourcePath;
    private Path mcpChosenPath;
    private Project currentProject;

    private JComboBox<String> kbCategory;
    private JBTextField kbName;
    private JBTextArea kbOutput;

    private DefaultListModel<String> historyModel;
    private JBTextArea historyDetail;
    private final List<String> historyDetails = new ArrayList<>();

    @Override
    public void createToolWindowContent(@NotNull Project project, @NotNull ToolWindow toolWindow) {
        currentProject = project;
        JPanel root = new JPanel(new BorderLayout(6, 6));
        root.add(buildHeader(), BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("AI Chat", buildAiChat(project));
        tabs.addTab("MCP Tools", buildMcpTools());
        tabs.addTab("Knowledge Base", buildKnowledgeBase());
        tabs.addTab("History", buildHistory());
        root.add(tabs, BorderLayout.CENTER);

        refreshLlmUi();
        refreshToolsAsync();

        Content content = ContentFactory.getInstance().createContent(root, "", false);
        toolWindow.getContentManager().addContent(content);
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout(8, 4));
        JPanel title = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        title.add(new JBLabel("<html><b>Engineering AI 1.3.0</b></html>"));
        llmStatus = new JBLabel();
        title.add(llmStatus);
        header.add(title, BorderLayout.WEST);

        integrationsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 2));
        integrationsPanel.add(new JBLabel("MCP: discovering..."));
        header.add(integrationsPanel, BorderLayout.EAST);
        return header;
    }

    private JComponent buildAiChat(Project project) {
        JPanel panel = new JPanel(new BorderLayout(6, 6));
        JPanel controls = new JPanel();
        controls.setLayout(new BoxLayout(controls, BoxLayout.Y_AXIS));

        JPanel sourceRow = new JPanel(new BorderLayout(5, 5));
        sourceScope = new JComboBox<>(new String[]{"Selected Code", "Current File", "Choose File...", "Choose Folder..."});
        sourcePath = new JBTextField(); sourcePath.setEditable(false);
        JButton choose = new JButton("Browse");
        sourceRow.add(new JBLabel("Source: "), BorderLayout.WEST);
        sourceRow.add(sourceScope, BorderLayout.CENTER);
        sourceRow.add(choose, BorderLayout.EAST);
        controls.add(sourceRow);
        controls.add(sourcePath);

        chatPrompt = new JBTextArea(5, 40); chatPrompt.setLineWrap(true); chatPrompt.setWrapStyleWord(true);
        chatPrompt.setText("Review this code for security vulnerabilities and suggest improvements.");
        JPanel promptPanel = new JPanel(new BorderLayout(4,4));
        promptPanel.add(new JBLabel("Prompt (natural language):"), BorderLayout.NORTH);
        promptPanel.add(new JBScrollPane(chatPrompt), BorderLayout.CENTER);
        controls.add(promptPanel);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        sendChat = new JButton("Send to AI (LLM + MCP)");
        JButton security = new JButton("Security Review");
        JButton explain = new JButton("Explain Code");
        JButton tests = new JButton("Generate Test Ideas");
        actions.add(sendChat); actions.add(security); actions.add(explain); actions.add(tests);
        controls.add(actions);

        chatOutput = outputArea();
        panel.add(controls, BorderLayout.NORTH);
        panel.add(new JBScrollPane(chatOutput), BorderLayout.CENTER);

        sourceScope.addActionListener(e -> {
            String scope = String.valueOf(sourceScope.getSelectedItem());
            boolean external = scope.startsWith("Choose ");
            choose.setEnabled(external);
            if (!external) { chosenPath = null; sourcePath.setText(scope); }
        });
        choose.setEnabled(false);
        choose.addActionListener(e -> chooseSource());
        security.addActionListener(e -> chatPrompt.setText("Review this code for security vulnerabilities. Check authentication, authorization, input validation, secrets, injection risks, insecure configuration, and OWASP Top 10 issues. Give prioritized findings and fixes."));
        explain.addActionListener(e -> chatPrompt.setText("Explain this code, its responsibilities, important flows, dependencies, and any risky or confusing areas."));
        tests.addActionListener(e -> chatPrompt.setText("Review this code and suggest high-value unit and integration test cases, including edge cases and failure scenarios."));
        sendChat.addActionListener(e -> runAiChat(project));
        return panel;
    }

    private JComponent buildMcpTools() {
        JPanel panel = new JPanel(new BorderLayout(5,5));
        JPanel top = new JPanel(new BorderLayout(5,5));
        toolCombo = new JComboBox<>();
        JButton refresh = new JButton("Refresh MCP Tools");
        top.add(new JBLabel("MCP Tool: "), BorderLayout.WEST); top.add(toolCombo, BorderLayout.CENTER); top.add(refresh, BorderLayout.EAST);

        toolDescription = outputArea(); toolDescription.setRows(3);
        JPanel north = new JPanel(); north.setLayout(new BoxLayout(north, BoxLayout.Y_AXIS)); north.add(top); north.add(new JBScrollPane(toolDescription));

        JPanel sourceRow = new JPanel(new BorderLayout(5,5));
        attachMcpSource = new JBCheckBox("Attach local source when tool schema supports code/context", false);
        mcpSourceScope = new JComboBox<>(new String[]{"Selected Code", "Current File", "Choose File...", "Choose Folder..."});
        mcpSourcePath = new JBTextField(); mcpSourcePath.setEditable(false);
        JButton browseSource = new JButton("Browse"); browseSource.setEnabled(false);
        JPanel chooser = new JPanel(new BorderLayout(5,5)); chooser.add(mcpSourceScope, BorderLayout.WEST); chooser.add(mcpSourcePath, BorderLayout.CENTER); chooser.add(browseSource, BorderLayout.EAST);
        sourceRow.add(attachMcpSource, BorderLayout.NORTH); sourceRow.add(chooser, BorderLayout.CENTER);
        north.add(sourceRow);
        panel.add(north, BorderLayout.NORTH);

        mcpSourceScope.addActionListener(e -> {
            String scope = String.valueOf(mcpSourceScope.getSelectedItem());
            boolean external = scope.startsWith("Choose "); browseSource.setEnabled(external);
            if (!external) { mcpChosenPath = null; mcpSourcePath.setText(scope); }
        });
        browseSource.addActionListener(e -> chooseMcpSource());

        toolArgs = new JBTextArea(8,40); toolArgs.setText("{}");
        toolOutput = outputArea();
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                titled("MCP arguments (JSON) — generated from inputSchema", new JBScrollPane(toolArgs)),
                titled("MCP Tool Result", new JBScrollPane(toolOutput)));
        split.setResizeWeight(.35);
        panel.add(split, BorderLayout.CENTER);

        JButton run = new JButton("Run MCP Tool"); panel.add(run, BorderLayout.SOUTH);
        refresh.addActionListener(e -> refreshToolsAsync());
        toolCombo.addActionListener(e -> onToolSelected());
        run.addActionListener(e -> runSelectedTool());
        return panel;
    }

    private JComponent buildKnowledgeBase() {
        JPanel panel = new JPanel(new BorderLayout(5,5));
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        kbCategory = new JComboBox<>(new String[]{"Agents", "Skills", "Instructions", "Scripts", "Shared Docs Search"});
        kbName = new JBTextField(18);
        JButton list = new JButton("List");
        JButton load = new JButton("Load / Search");
        top.add(new JBLabel("Category:")); top.add(kbCategory); top.add(new JBLabel("Name / Query:")); top.add(kbName); top.add(list); top.add(load);
        panel.add(top, BorderLayout.NORTH);
        kbOutput = outputArea();
        kbOutput.setText("Knowledge Base content is loaded through MCP. The plugin never connects to Bitbucket directly.");
        panel.add(new JBScrollPane(kbOutput), BorderLayout.CENTER);
        list.addActionListener(e -> runKnowledgeList());
        load.addActionListener(e -> runKnowledgeGet());
        return panel;
    }

    private JComponent buildHistory() {
        JPanel panel = new JPanel(new BorderLayout(5,5));
        historyModel = new DefaultListModel<>();
        JList<String> list = new JList<>(historyModel);
        historyDetail = outputArea();
        list.addListSelectionListener(e -> {
            int i = list.getSelectedIndex();
            if (i >= 0 && i < historyDetails.size()) historyDetail.setText(historyDetails.get(i));
        });
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JBScrollPane(list), new JBScrollPane(historyDetail));
        split.setResizeWeight(.35); panel.add(split, BorderLayout.CENTER);
        return panel;
    }

    private void refreshToolsAsync() {
        runBackground(null, () -> {
            JsonArray tools = mcp.listTools();
            ApplicationManager.getApplication().invokeLater(() -> applyTools(tools));
            return null;
        });
    }

    private void applyTools(JsonArray tools) {
        currentTools = tools == null ? new JsonArray() : tools;
        toolsByName.clear();
        if (toolCombo != null) toolCombo.removeAllItems();
        for (JsonElement e : currentTools) {
            if (!e.isJsonObject()) continue;
            JsonObject t = e.getAsJsonObject();
            if (!t.has("name")) continue;
            String name = t.get("name").getAsString();
            toolsByName.put(name, t);
            if (toolCombo != null) toolCombo.addItem(name);
        }
        McpCapabilities caps = new McpCapabilities(currentTools);
        rebuildEnabledSources(caps);
        onToolSelected();
    }

    /** Hide disabled integrations: only enabled capabilities are rendered. */
    private void rebuildEnabledSources(McpCapabilities caps) {
        if (integrationsPanel == null) return;
        integrationsPanel.removeAll();
        List<String> enabled = caps.enabledSources();
        if (enabled.isEmpty()) integrationsPanel.add(new JBLabel("MCP connected • no categorized tools"));
        else {
            integrationsPanel.add(new JBLabel("Available: "));
            for (String source : enabled) integrationsPanel.add(new JBLabel("[" + source + "]"));
        }
        integrationsPanel.revalidate(); integrationsPanel.repaint();
    }

    private void onToolSelected() {
        if (toolCombo == null || toolDescription == null || toolArgs == null) return;
        String name = (String) toolCombo.getSelectedItem();
        JsonObject tool = name == null ? null : toolsByName.get(name);
        if (tool == null) { toolDescription.setText("No MCP tool selected."); toolArgs.setText("{}"); return; }
        String description = tool.has("description") ? tool.get("description").getAsString() : "";
        toolDescription.setText(name + "\n\n" + description);
        toolArgs.setText(mcp.pretty(mcp.buildArgumentTemplate(tool)));
    }

    private void runSelectedTool() {
        String name = (String) toolCombo.getSelectedItem();
        if (name == null) { toolOutput.setText("Select an MCP tool first."); return; }
        try {
            JsonObject args = mcp.parseArguments(toolArgs.getText());
            if (attachMcpSource != null && attachMcpSource.isSelected()) attachLocalSourceIfSupported(name, args);
            toolOutput.setText("Running " + name + "...");
            runBackground(toolOutput, () -> mcp.callToolAsText(name, args));
        } catch (Exception ex) { toolOutput.setText(errorText(ex)); }
    }


    private void chooseMcpSource() {
        String scope = String.valueOf(mcpSourceScope.getSelectedItem());
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(scope.startsWith("Choose Folder") ? JFileChooser.DIRECTORIES_ONLY : JFileChooser.FILES_ONLY);
        if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            mcpChosenPath = chooser.getSelectedFile().toPath();
            mcpSourcePath.setText(mcpChosenPath.toAbsolutePath().toString());
        }
    }

    private void attachLocalSourceIfSupported(String toolName, JsonObject args) throws Exception {
        JsonObject tool = toolsByName.get(toolName);
        if (tool == null || !tool.has("inputSchema") || !tool.get("inputSchema").isJsonObject()) return;
        JsonObject schema = tool.getAsJsonObject("inputSchema");
        JsonObject props = schema.has("properties") && schema.get("properties").isJsonObject() ? schema.getAsJsonObject("properties") : new JsonObject();
        boolean accepts = props.has("code") || props.has("context") || props.has("source") || props.has("content");
        if (!accepts) return;
        String context = collectMcpSource();
        if (props.has("code") && missingOrBlank(args, "code")) args.addProperty("code", context);
        else if (props.has("context") && missingOrBlank(args, "context")) args.addProperty("context", context);
        else if (props.has("source") && missingOrBlank(args, "source")) args.addProperty("source", context);
        else if (props.has("content") && missingOrBlank(args, "content")) args.addProperty("content", context);
        if (props.has("scope") && !args.has("scope")) args.addProperty("scope", String.valueOf(mcpSourceScope.getSelectedItem()));
        if (props.has("language") && !args.has("language")) args.addProperty("language", "auto");
    }

    private boolean missingOrBlank(JsonObject args, String key) {
        return !args.has(key) || args.get(key).isJsonNull() || (args.get(key).isJsonPrimitive() && args.get(key).getAsString().isBlank());
    }

    private String collectMcpSource() throws Exception {
        String scope = String.valueOf(mcpSourceScope.getSelectedItem());
        return switch (scope) {
            case "Selected Code" -> IdeContextProvider.collectSelectedCode(currentProject);
            case "Current File" -> IdeContextProvider.collectCurrentFile(currentProject);
            case "Choose File..." -> IdeContextProvider.collectFile(mcpChosenPath);
            case "Choose Folder..." -> IdeContextProvider.collectFolder(mcpChosenPath);
            default -> IdeContextProvider.collect(currentProject);
        };
    }

    private void runKnowledgeList() {
        String category = String.valueOf(kbCategory.getSelectedItem());
        String tool = switch (category) {
            case "Agents" -> "list_agents";
            case "Skills" -> "list_skills";
            case "Instructions" -> "list_instructions";
            case "Scripts" -> "list_scripts";
            default -> "search_shared_docs";
        };
        if (!toolsByName.containsKey(tool)) { kbOutput.setText("This capability is not enabled by the MCP server: " + tool); return; }
        JsonObject args = new JsonObject();
        if ("search_shared_docs".equals(tool)) args.addProperty("query", kbName.getText().trim());
        runBackground(kbOutput, () -> mcp.callToolAsText(tool, args));
    }

    private void runKnowledgeGet() {
        String category = String.valueOf(kbCategory.getSelectedItem());
        String tool = switch (category) {
            case "Agents" -> "get_agent";
            case "Skills" -> "get_skill";
            case "Instructions" -> "get_instruction";
            case "Scripts" -> "get_script";
            default -> "search_shared_docs";
        };
        if (!toolsByName.containsKey(tool)) { kbOutput.setText("This capability is not enabled by the MCP server: " + tool); return; }
        String value = kbName.getText().trim();
        JsonObject args = new JsonObject();
        if ("search_shared_docs".equals(tool)) args.addProperty("query", value); else args.addProperty("name", value);
        runBackground(kbOutput, () -> mcp.callToolAsText(tool, args));
    }

    private void runAiChat(Project project) {
        refreshLlmUi();
        var s = EngineeringAiSettings.getInstance().getState();
        if (s == null || !s.llmEnabled || "DIRECT_MCP".equalsIgnoreCase(s.mode)) {
            chatOutput.setText("LLM is disabled. Use the MCP Tools tab for direct/manual MCP calls, or enable LLM in Settings > Engineering AI.");
            return;
        }
        String q = chatPrompt.getText().trim();
        if (q.isEmpty()) { chatOutput.setText("Enter a prompt first."); return; }
        String context;
        try { context = collectSelectedSource(project); }
        catch (Exception ex) { chatOutput.setText(errorText(ex)); return; }
        chatOutput.setText("Engineering AI is analyzing the selected local source and available MCP knowledge/tools...");
        runBackground(chatOutput, () -> new AiOrchestrator().ask(q, context));
        addHistory(q, context);
    }

    private String collectSelectedSource(Project project) throws Exception {
        String scope = String.valueOf(sourceScope.getSelectedItem());
        return switch (scope) {
            case "Selected Code" -> IdeContextProvider.collectSelectedCode(project);
            case "Current File" -> IdeContextProvider.collectCurrentFile(project);
            case "Choose File..." -> IdeContextProvider.collectFile(chosenPath);
            case "Choose Folder..." -> IdeContextProvider.collectFolder(chosenPath);
            default -> IdeContextProvider.collect(project);
        };
    }

    private void chooseSource() {
        String scope = String.valueOf(sourceScope.getSelectedItem());
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(scope.startsWith("Choose Folder") ? JFileChooser.DIRECTORIES_ONLY : JFileChooser.FILES_ONLY);
        if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            chosenPath = chooser.getSelectedFile().toPath();
            sourcePath.setText(chosenPath.toAbsolutePath().toString());
        }
    }

    private void refreshLlmUi() {
        if (llmStatus == null) return;
        var s = EngineeringAiSettings.getInstance().getState();
        boolean on = s != null && s.llmEnabled && !"DIRECT_MCP".equalsIgnoreCase(s.mode);
        llmStatus.setText("LLM: " + (on ? "ON" : "OFF") + (s == null ? "" : " • Mode: " + s.mode));
        if (sendChat != null) sendChat.setEnabled(on);
    }

    private void addHistory(String prompt, String context) {
        if (historyModel == null) return;
        String label = prompt.length() > 70 ? prompt.substring(0, 70) + "..." : prompt;
        historyModel.add(0, label);
        String detail = "PROMPT\n" + prompt + "\n\nSOURCE CONTEXT PREVIEW\n" + (context.length() > 8000 ? context.substring(0,8000)+"\n...[truncated]" : context);
        historyDetails.add(0, detail);
    }

    private JBTextArea outputArea() {
        JBTextArea a = new JBTextArea(); a.setEditable(false); a.setLineWrap(true); a.setWrapStyleWord(true); return a;
    }

    private JComponent titled(String title, JComponent c) {
        JPanel p = new JPanel(new BorderLayout()); p.add(new JBLabel(title), BorderLayout.NORTH); p.add(c, BorderLayout.CENTER); return p;
    }

    private void runBackground(JBTextArea output, ThrowingSupplier supplier) {
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            String result = null;
            try { result = supplier.get(); }
            catch (Exception ex) { result = errorText(ex); }
            if (output != null && result != null) {
                String finalResult = result;
                ApplicationManager.getApplication().invokeLater(() -> output.setText(finalResult));
            }
        });
    }

    private String errorText(Exception ex) {
        String message = ex.getMessage();
        if (message == null || message.isBlank()) message = ex.getClass().getName();
        return "ERROR\n\nException: " + ex.getClass().getName() + "\n\n" + message;
    }

    @FunctionalInterface private interface ThrowingSupplier { String get() throws Exception; }
}
