package com.company.engineeringai.mcp;

import com.google.gson.*;
import java.util.*;

/** Capability view inferred from authoritative MCP tools/list. */
public final class McpCapabilities {
    private final Set<String> toolNames;

    public McpCapabilities(JsonArray tools) {
        Set<String> names = new LinkedHashSet<>();
        if (tools != null) {
            for (JsonElement e : tools) {
                if (e.isJsonObject() && e.getAsJsonObject().has("name")) names.add(e.getAsJsonObject().get("name").getAsString());
            }
        }
        this.toolNames = Collections.unmodifiableSet(names);
    }

    public Set<String> toolNames() { return toolNames; }
    public boolean has(String tool) { return toolNames.contains(tool); }
    public boolean knowledge() { return any("search_shared_docs","get_prompt","get_service_context","list_agents","get_agent","list_skills","get_skill","list_instructions","get_instruction","list_scripts","get_script"); }
    public boolean splunk() { return prefix("splunk") || any("search_splunk"); }
    public boolean newRelic() { return prefix("new_relic") || prefix("newrelic") || any("search_new_relic"); }
    public boolean pcf() { return prefix("pcf") || any("get_pcf_app_status"); }
    public boolean oracle() { return prefix("oracle") || any("query_oracle"); }
    public boolean sqlServer() { return prefix("sql_server") || prefix("sqlserver") || any("query_sql_server"); }
    public boolean jenkins() { return prefix("jenkins") || any("get_jenkins_build"); }

    public List<String> enabledSources() {
        List<String> out = new ArrayList<>();
        if (knowledge()) out.add("Knowledge Base");
        if (splunk()) out.add("Splunk");
        if (newRelic()) out.add("New Relic");
        if (pcf()) out.add("PCF");
        if (oracle()) out.add("Oracle");
        if (sqlServer()) out.add("SQL Server");
        if (jenkins()) out.add("Jenkins");
        return out;
    }

    private boolean any(String... names) { for (String n : names) if (toolNames.contains(n)) return true; return false; }
    private boolean prefix(String prefix) { for (String n : toolNames) if (n.startsWith(prefix)) return true; return false; }
}
