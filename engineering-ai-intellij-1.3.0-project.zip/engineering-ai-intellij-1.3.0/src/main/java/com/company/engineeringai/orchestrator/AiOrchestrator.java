package com.company.engineeringai.orchestrator;

import com.company.engineeringai.llm.LlmGatewayClient;
import com.company.engineeringai.mcp.McpClient;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.google.gson.*;

/** Copilot-style loop: IDE context -> LLM -> optional MCP tools -> centralized knowledge/live tools -> LLM final response. */
public final class AiOrchestrator {
    private final Gson gson=new GsonBuilder().setPrettyPrinting().create();
    private final McpClient mcp=new McpClient();
    private final LlmGatewayClient llm=new LlmGatewayClient();

    public String ask(String query,String context) throws Exception {
        var s=EngineeringAiSettings.getInstance().getState();
        if(s==null)throw new IllegalStateException("Engineering AI settings unavailable.");

        String mode = s.mode == null ? "AUTO" : s.mode.trim().toUpperCase();
        boolean llmConfigured = s.llmEnabled && s.llmUrl != null && !s.llmUrl.isBlank();

        if("DIRECT_MCP".equals(mode) || !s.llmEnabled) {
            throw new IllegalStateException("AI Chat requires the LLM. LLM is disabled; use the MCP Tools tab for direct MCP calls.");
        }

        if("LLM_GATEWAY".equals(mode)) {
            if(!llmConfigured) throw new IllegalStateException("LLM_GATEWAY mode is selected but the LLM gateway is disabled or not configured.");
            return askViaLlm(query, context, s);
        }

        // AUTO: use the LLM when enabled/configured. MCP remains optional on the LLM path.
        if(llmConfigured) return askViaLlm(query, context, s);
        throw new IllegalStateException("AUTO mode has no configured LLM. Enable/configure the LLM or use the MCP Tools tab.");
    }

    private String askViaLlm(String query, String context, EngineeringAiSettings.StateData s) throws Exception {
        JsonArray mcpTools = new JsonArray();
        String mcpStatus = "available";
        try {
            mcpTools = mcp.listTools();
        } catch (Exception ex) {
            // MCP is optional on the LLM path. Continue with IDE context only.
            mcpStatus = "unavailable: " + safe(ex.getMessage());
        }

        JsonArray llmTools=toLlmTools(mcpTools);
        JsonArray messages=new JsonArray();
        messages.add(msg("system",systemPrompt(s, mcpStatus)));
        messages.add(msg("user",buildUserMessage(query,context)));

        int rounds=Math.max(1,Math.min(s.maxToolRounds,12));
        for(int i=0;i<rounds;i++){
            JsonObject assistant=llm.chat(messages,llmTools);
            messages.add(assistant.deepCopy());
            JsonArray calls=assistant.has("tool_calls")&&assistant.get("tool_calls").isJsonArray()?assistant.getAsJsonArray("tool_calls"):null;
            if(calls==null||calls.isEmpty())return contentOf(assistant);

            for(JsonElement el:calls){
                JsonObject call=el.getAsJsonObject(); JsonObject fn=call.getAsJsonObject("function");
                String name=fn.get("name").getAsString(); String callId=call.has("id")?call.get("id").getAsString():name;
                JsonObject args=parseArgs(fn.has("arguments")?fn.get("arguments"):null);
                JsonObject result;
                try{result=mcp.callTool(name,args);}catch(Exception ex){
                    result=new JsonObject();
                    result.addProperty("error","MCP tool unavailable: "+safe(ex.getMessage()));
                    result.addProperty("tool",name);
                }
                JsonObject toolMsg=new JsonObject(); toolMsg.addProperty("role","tool"); toolMsg.addProperty("tool_call_id",callId); toolMsg.addProperty("content",gson.toJson(result));
                messages.add(toolMsg);
            }
        }
        JsonObject finalMessage=llm.chat(messages,new JsonArray());
        return contentOf(finalMessage);
    }

    private JsonArray toLlmTools(JsonArray mcpTools){
        JsonArray out=new JsonArray();
        for(JsonElement e:mcpTools){
            JsonObject mt=e.getAsJsonObject(); if(!mt.has("name"))continue;
            JsonObject fn=new JsonObject(); fn.addProperty("name",mt.get("name").getAsString());
            fn.addProperty("description",mt.has("description")?mt.get("description").getAsString():"MCP tool");
            fn.add("parameters",mt.has("inputSchema")?mt.get("inputSchema").deepCopy():emptyObjectSchema());
            JsonObject wrapper=new JsonObject();wrapper.addProperty("type","function");wrapper.add("function",fn);out.add(wrapper);
        }
        return out;
    }
    private JsonObject emptyObjectSchema(){JsonObject o=new JsonObject();o.addProperty("type","object");o.add("properties",new JsonObject());return o;}
    private JsonObject msg(String role,String content){JsonObject m=new JsonObject();m.addProperty("role",role);m.addProperty("content",content);return m;}
    private JsonObject parseArgs(JsonElement e){
        if(e==null||e.isJsonNull())return new JsonObject();
        if(e.isJsonObject())return e.getAsJsonObject();
        try{return JsonParser.parseString(e.getAsString()).getAsJsonObject();}catch(Exception ignored){return new JsonObject();}
    }
    private String contentOf(JsonObject m){
        if(!m.has("content")||m.get("content").isJsonNull())return "LLM returned no final text response.";
        if(m.get("content").isJsonPrimitive())return m.get("content").getAsString();
        return gson.toJson(m.get("content"));
    }
    private String buildUserMessage(String q,String c){return "QUESTION:\n"+q+"\n\nLOCAL IDE CONTEXT:\n"+(c==null||c.isBlank()?"(none)":c);}
    private String systemPrompt(EngineeringAiSettings.StateData s, String mcpStatus){
        String source = (s.centralKnowledgeLabel==null || s.centralKnowledgeLabel.isBlank()) ? "central shared knowledge repository" : s.centralKnowledgeLabel;
        String hints = "tools/list (dynamic discovery)";
        return """
You are Engineering AI inside IntelliJ IDEA. Help the developer understand and troubleshoot the current project.

The developer's current IDE code is supplied directly in the user message. Shared Markdown files and prompts are NOT stored locally in each application repo. They are centrally managed behind the MCP server, typically in the shared knowledge source: %s.

When centralized knowledge is enabled and MCP knowledge tools are available, use them to retrieve only the relevant shared documentation/prompt/service context. Expected knowledge-tool names may resemble: %s. Tool discovery is authoritative; do not invent a tool that was not provided.

MCP status for this request: %s.

Rules:
- MCP is optional. If MCP is unavailable, continue using the IDE code/context and clearly say when live or centralized evidence could not be verified.
- Never invent Bitbucket Markdown content, live logs, metrics, database results, or MCP results.
- Prefer centralized shared knowledge tools for architecture, runbooks, service catalog, common prompts and troubleshooting standards.
- Prefer live read-only MCP tools for logs, traces, platform health and dependency evidence when the question needs current operational data.
- Distinguish evidence from IDE code, centralized shared knowledge, and live MCP systems in the final answer when relevant.
- Do not expose secrets, credentials, hidden authorization values, or raw access tokens.
""".formatted(source, hints, mcpStatus);
    }
    private String safe(String s){return s==null||s.isBlank()?"unknown error":s;}
}
