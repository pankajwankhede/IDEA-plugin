package com.company.engineeringai.settings;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.Service;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Service(Service.Level.APP)
@State(name = "EngineeringAiSettings", storages = @Storage("engineering-ai.xml"))
public final class EngineeringAiSettings implements PersistentStateComponent<EngineeringAiSettings.StateData> {
    public static final class StateData {
        /** AUTO = use LLM when enabled/configured; LLM_GATEWAY = require LLM; DIRECT_MCP = no LLM chat. */
        public String mode = "AUTO";
        public boolean llmEnabled = true;
        public String llmUrl = "http://localhost:8081/v1/chat/completions";
        public String llmModel = "enterprise-model";
        public String llmTokenEnv = "ENGINEERING_AI_LLM_TOKEN";
        public int maxToolRounds = 6;

        public String mcpUrl = "http://localhost:8080/mcp";

        /** Display-only label. Bitbucket credentials and repository settings remain on MCP server. */
        public boolean useCentralKnowledge = true;
        public String centralKnowledgeLabel = "Bitbucket company-ai-agent";

        public boolean includeCurrentFile = true;
        public boolean includeSelectedCode = true;
        public int maxFolderFiles = 50;
        public int maxFileChars = 120000;
    }

    private StateData state = new StateData();

    public static EngineeringAiSettings getInstance() {
        return ApplicationManager.getApplication().getService(EngineeringAiSettings.class);
    }

    @Override
    public @Nullable StateData getState() { return state; }

    @Override
    public void loadState(@NotNull StateData state) { this.state = state; }
}
