# Engineering AI IntelliJ Plugin 1.2.2

A Copilot-style internal IntelliJ plugin using **IDE code context + Enterprise LLM Gateway + optional MCP tools + centralized Bitbucket knowledge**.

## What changed in 1.2.2

Added configurable LLM enable/disable behavior and three orchestration modes:

```text
AUTO         -> use LLM when enabled/configured; fall back to direct MCP if the LLM call fails
LLM_GATEWAY  -> use the LLM path; MCP remains an optional tool source
DIRECT_MCP   -> skip the LLM completely and call MCP directly
```

When **Enable LLM gateway** is unchecked, the plugin never calls the LLM and routes requests directly to MCP.

## Previous 1.2.1 baseline

**Java 21 is now the required project toolchain.** The IntelliJ plugin itself does not use Spring Boot. If you add or deploy a separate Spring Boot MCP/backend service for this solution, standardize that backend on **Spring Boot 4.1.0**.

Local `.md` files are no longer required in each application repository. Shared Markdown files, prompts, runbooks and service documentation can be stored once in a central Bitbucket repository such as `xyzagent` and exposed to the LLM through MCP tools.

```text
Developer / IntelliJ
       |
       | question + current/selected code
       v
Engineering AI Plugin
       |
       v
Enterprise LLM Gateway
       |
       | tool selection
       v
MCP Server
   |             |             |            |
   v             v             v            v
Bitbucket      Splunk       New Relic       PCF
xyzagent
   |
   +-- prompts/*.md
   +-- knowledge/**/*.md
   +-- service-catalog/*
```

The IntelliJ plugin does **not** receive Bitbucket credentials and does not need to know the Bitbucket URL. The MCP server owns repository access, caching, indexing and access policy.

## Recommended MCP knowledge tools

The plugin performs `tools/list` and dynamically gives all returned MCP schemas to the LLM. For centralized knowledge, expose tools such as:

```text
search_shared_docs
get_shared_context
get_prompt
get_service_context
```

See `docs/MCP_SHARED_KNOWLEDGE_CONTRACT.md` for recommended request/response contracts.

## Example centralized repo

```text
xyzagent/
├── prompts/
│   ├── system-prompt.md
│   ├── investigation.md
│   └── code-review.md
├── knowledge/
│   ├── architecture/
│   ├── services/
│   └── troubleshooting/
└── service-catalog/
```

## Example flow

Developer opens `bc-login` and asks:

```text
Why is this NullPointerException happening in QA?
```

Engineering AI can:

1. Send the current/selected IntelliJ code to the LLM.
2. Discover MCP tools.
3. Let the LLM call `get_service_context(service=bc-login, environment=qa)`.
4. Let MCP retrieve relevant `.md` content from the central `xyzagent` repository.
5. Optionally let the LLM call live Splunk/New Relic/PCF tools.
6. Send all MCP evidence back to the LLM for the final answer.

## Resilience / fallback

MCP is optional on the LLM path. `AUTO` additionally falls back to direct MCP if the LLM gateway itself fails.

```text
LLM + IDE + MCP + xyzagent knowledge  -> full experience
LLM + IDE, MCP unavailable            -> code-only AI analysis
LLM + IDE + MCP, Bitbucket unavailable-> live tools + MCP cache if server supports it
```

The plugin never invents centralized documentation or live MCP results when those sources are unavailable.

## IntelliJ settings

Open **Settings -> Engineering AI**.

Example:

```text
Mode: AUTO
Enable LLM gateway: enabled
LLM Gateway URL: https://engineering-ai.company.com/v1/chat/completions
LLM model: enterprise-model
LLM token env variable: ENGINEERING_AI_LLM_TOKEN
MCP server URL: https://engineering-mcp.company.com/mcp
Use centralized knowledge through MCP: enabled
Knowledge source label: Bitbucket xyzagent
Knowledge tool hints: search_shared_docs,get_shared_context,get_prompt,get_service_context
```

`Knowledge tool hints` only help the system prompt describe expected capabilities. Tool discovery (`tools/list`) remains authoritative.

## LLM enable/disable behavior

Open **Settings -> Engineering AI**.

- **Enable LLM gateway = ON** + **AUTO**: prefer LLM; if that request fails, retry through direct MCP.
- **Enable LLM gateway = ON** + **LLM_GATEWAY**: always use LLM orchestration. MCP tool discovery is best-effort.
- **Enable LLM gateway = ON** + **DIRECT_MCP**: skip LLM.
- **Enable LLM gateway = OFF**: skip LLM regardless of AUTO/LLM settings and use MCP directly.

The LLM URL/model/token fields are disabled in the settings UI when LLM is disabled or `DIRECT_MCP` is selected.

## MCP server configuration example

An example server-side configuration is included at:

```text
examples/mcp-server-config/xyzagent-knowledge.yml
```

This is intentionally not loaded by the IntelliJ plugin. Put equivalent settings into your MCP server/config service.

## LLM Gateway

v1.2 uses an OpenAI-compatible Chat Completions contract:

```text
POST /v1/chat/completions
```

with `messages`, `tools` and assistant `tool_calls`.

## Authentication

The plugin does not persist the LLM bearer token. Configure the environment variable named under `LLM token env variable` before IntelliJ starts.

Bitbucket authentication belongs only to the MCP server. For production use, prefer your organization's approved OAuth/service identity/mTLS/secret-management method instead of static credentials.


## Java and Spring Boot baseline

```text
IntelliJ plugin
  Java: 21
  Spring Boot: not used

MCP / backend service (if maintained as a Spring Boot application)
  Java: 21
  Spring Boot: 4.1.0
```

Do not add Spring Boot to the IntelliJ plugin just to call the MCP server; the plugin should stay a normal IntelliJ Platform plugin.

## Import into IntelliJ

1. Extract `engineering-ai-intellij-1.2.2-project.zip`.
2. IntelliJ -> **File -> Open**.
3. Select `engineering-ai-intellij-1.2.1`.
4. Open as a Gradle project.
5. Use **JDK 21** (the Gradle Java toolchain is pinned to Java 21).

## Run

With Gradle 9.1+:

```bash
gradle runIde
```

## Build installable plugin

```bash
gradle buildPlugin
```

The ZIP is generated under `build/distributions/`.

## Project structure

```text
src/main/java/com/company/engineeringai/
├── actions/
├── context/
│   └── IdeContextProvider.java
├── llm/
│   └── LlmGatewayClient.java
├── mcp/
│   └── McpClient.java
├── orchestrator/
│   └── AiOrchestrator.java
├── settings/
└── toolwindow/

docs/
└── MCP_SHARED_KNOWLEDGE_CONTRACT.md

examples/mcp-server-config/
└── xyzagent-knowledge.yml
```

## Production hardening

Add your approved SSO/OAuth/mTLS, MCP authorization, audit logging, sensitive-data redaction, destructive-tool confirmation, central policy enforcement and Bitbucket cache/version controls before broad enterprise rollout.
