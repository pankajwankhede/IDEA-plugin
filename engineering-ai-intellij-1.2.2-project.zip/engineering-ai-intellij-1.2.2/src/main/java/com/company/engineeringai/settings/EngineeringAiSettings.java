package com.company.engineeringai.settings;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@State(name = "EngineeringAiSettings", storages = @Storage("engineering-ai.xml"))
public final class EngineeringAiSettings implements PersistentStateComponent<EngineeringAiSettings.StateData> {
    public static final class StateData {
        /** AUTO = prefer LLM when enabled/configured, otherwise MCP; LLM_GATEWAY = force LLM path; DIRECT_MCP = skip LLM. */
        public String mode = "AUTO";
        /** Master switch. When false the plugin never calls the LLM gateway. */
        public boolean llmEnabled = true;

        // Generic OpenAI-compatible enterprise LLM gateway settings.
        public String llmUrl = "http://localhost:8081/v1/chat/completions";
        public String llmModel = "enterprise-model";
        /** Name of an environment variable containing the bearer token. Token itself is never persisted. */
        public String llmTokenEnv = "ENGINEERING_AI_LLM_TOKEN";
        public int maxToolRounds = 6;

        // MCP settings.
        public String mcpUrl = "http://localhost:8080/mcp";
        public String mcpToolName = "engineering_ask";

        // Centralized shared knowledge. The plugin does NOT connect to Bitbucket directly.
        // The MCP server owns Bitbucket credentials, repo URL, caching and access policy.
        public boolean useCentralKnowledge = true;
        public String centralKnowledgeLabel = "Bitbucket xyzagent";
        public String knowledgeToolHints = "search_shared_docs,get_shared_context,get_prompt,get_service_context";

        // IDE context settings.
        public boolean includeCurrentFile = true;
        public boolean includeSelectedCode = true;
    }

    private StateData state = new StateData();

    public static EngineeringAiSettings getInstance() {
        return ApplicationManager.getApplication().getService(EngineeringAiSettings.class);
    }

    @Override
    public @Nullable StateData getState() { return state; }

    @Override
    public void loadState(@NotNull StateData state) { this.state = state; }
}
