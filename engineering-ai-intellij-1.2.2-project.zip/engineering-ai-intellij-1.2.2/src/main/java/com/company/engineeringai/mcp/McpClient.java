package com.company.engineeringai.mcp;

import com.company.engineeringai.settings.EngineeringAiSettings;
import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;

public final class McpClient {
    private final HttpClient client=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    private final Gson gson=new GsonBuilder().setPrettyPrinting().create();
    private String sessionId;
    private boolean initialized;

    public JsonArray listTools() throws Exception {
        ensureInitialized();
        JsonObject response=parseJsonRpc(sendRpc("tools/list",new JsonObject(),true));
        JsonObject result=response.getAsJsonObject("result");
        return result!=null && result.has("tools") ? result.getAsJsonArray("tools") : new JsonArray();
    }

    public String initializeAndListTools() throws Exception { return gson.toJson(listTools()); }

    public JsonObject callTool(String name, JsonObject args) throws Exception {
        ensureInitialized();
        JsonObject params=new JsonObject(); params.addProperty("name",name); params.add("arguments",args==null?new JsonObject():args);
        return parseJsonRpc(sendRpc("tools/call",params,true));
    }

    public String callAskTool(String query,String context) throws Exception {
        var s=EngineeringAiSettings.getInstance().getState();
        if(s==null||s.mcpToolName==null||s.mcpToolName.isBlank()) throw new IllegalStateException("Configure the MCP tool name in Settings > Engineering AI.");
        JsonObject args=new JsonObject(); args.addProperty("query",query); args.addProperty("context",context);
        return gson.toJson(callTool(s.mcpToolName,args));
    }

    private void ensureInitialized() throws Exception {
        if(initialized)return;
        JsonObject params=new JsonObject(); params.addProperty("protocolVersion","2025-06-18"); params.add("capabilities",new JsonObject());
        JsonObject info=new JsonObject(); info.addProperty("name","engineering-ai-intellij"); info.addProperty("version","1.2.0"); params.add("clientInfo",info);
        sendRpc("initialize",params,true);
        // MCP initialized notification has no id and no response requirement.
        sendNotification("notifications/initialized",new JsonObject());
        initialized=true;
    }

    private String sendRpc(String method,JsonObject params,boolean hasId) throws Exception {
        var s=EngineeringAiSettings.getInstance().getState();
        if(s==null||s.mcpUrl==null||s.mcpUrl.isBlank()) throw new IllegalStateException("Configure MCP server URL in Settings > Engineering AI.");
        JsonObject body=new JsonObject(); body.addProperty("jsonrpc","2.0"); if(hasId)body.addProperty("id",UUID.randomUUID().toString()); body.addProperty("method",method); body.add("params",params);
        HttpRequest.Builder b=HttpRequest.newBuilder().uri(URI.create(s.mcpUrl)).timeout(Duration.ofSeconds(90))
                .header("Content-Type","application/json").header("Accept","application/json, text/event-stream")
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(body)));
        if(sessionId!=null&&!sessionId.isBlank())b.header("Mcp-Session-Id",sessionId);
        HttpResponse<String> r=client.send(b.build(),HttpResponse.BodyHandlers.ofString()); r.headers().firstValue("Mcp-Session-Id").ifPresent(v->sessionId=v);
        if(r.statusCode()<200||r.statusCode()>=300)throw new IllegalStateException("MCP HTTP "+r.statusCode()+": "+r.body());
        return extractJson(r.body());
    }

    private void sendNotification(String method,JsonObject params) throws Exception {
        var s=EngineeringAiSettings.getInstance().getState();
        if(s==null||s.mcpUrl==null||s.mcpUrl.isBlank())return;
        JsonObject body=new JsonObject(); body.addProperty("jsonrpc","2.0"); body.addProperty("method",method); body.add("params",params);
        HttpRequest.Builder b=HttpRequest.newBuilder().uri(URI.create(s.mcpUrl)).timeout(Duration.ofSeconds(30))
                .header("Content-Type","application/json").header("Accept","application/json, text/event-stream")
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(body)));
        if(sessionId!=null&&!sessionId.isBlank())b.header("Mcp-Session-Id",sessionId);
        HttpResponse<String> r=client.send(b.build(),HttpResponse.BodyHandlers.ofString());
        if(r.statusCode()<200||r.statusCode()>=300)throw new IllegalStateException("MCP notification HTTP "+r.statusCode()+": "+r.body());
    }

    private JsonObject parseJsonRpc(String raw){ JsonElement e=JsonParser.parseString(raw); if(!e.isJsonObject())throw new IllegalStateException("Invalid MCP JSON-RPC response"); JsonObject o=e.getAsJsonObject(); if(o.has("error"))throw new IllegalStateException("MCP error: "+o.get("error")); return o; }

    /** Supports plain JSON and the common single/multi-event SSE response shape. */
    private String extractJson(String body){
        String t=body==null?"":body.trim(); if(t.startsWith("{"))return t;
        StringBuilder data=new StringBuilder();
        for(String line:t.split("\\R")){ if(line.startsWith("data:")){String v=line.substring(5).trim(); if(!v.equals("[DONE]"))data.append(v);}}
        if(data.length()==0)throw new IllegalStateException("MCP response did not contain JSON: "+t);
        return data.toString();
    }
}
