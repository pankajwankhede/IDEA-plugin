package com.company.engineeringai.toolwindow;

import com.company.engineeringai.context.IdeContextProvider;
import com.company.engineeringai.mcp.McpClient;
import com.company.engineeringai.orchestrator.AiOrchestrator;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.*;
import com.intellij.ui.components.*;
import com.intellij.ui.content.*;
import org.jetbrains.annotations.NotNull;
import javax.swing.*;
import java.awt.*;

public final class EngineeringAiToolWindowFactory implements ToolWindowFactory {
    @Override public void createToolWindowContent(@NotNull Project project,@NotNull ToolWindow toolWindow){
        JPanel root=new JPanel(new BorderLayout(8,8));
        JBTextArea output=new JBTextArea();output.setEditable(false);output.setLineWrap(true);output.setWrapStyleWord(true);
        output.setText("Engineering AI 1.2.2\n\nCentral-knowledge mode: IDE code -> LLM Gateway -> MCP -> shared Bitbucket knowledge/live tools. No local .md files are required in each application repo.");
        JBTextArea input=new JBTextArea(4,40);input.setLineWrap(true);input.setWrapStyleWord(true);
        JButton ask=new JButton("Ask Engineering AI"); JButton listTools=new JButton("List MCP Tools"); JButton preview=new JButton("Preview IDE Context");
        JLabel modeLabel=new JLabel(); refreshMode(modeLabel);
        JPanel buttons=new JPanel(new FlowLayout(FlowLayout.LEFT));buttons.add(ask);buttons.add(listTools);buttons.add(preview);buttons.add(modeLabel);
        JPanel bottom=new JPanel(new BorderLayout(4,4));bottom.add(new JBScrollPane(input),BorderLayout.CENTER);bottom.add(buttons,BorderLayout.SOUTH);
        root.add(new JBScrollPane(output),BorderLayout.CENTER);root.add(bottom,BorderLayout.SOUTH);

        preview.addActionListener(e->{String c=collect(project);output.setText(c.isBlank()?"No IDE context found. Open a source file or select code.":c);});
        listTools.addActionListener(e->runBackground(output,"Connecting to MCP...",()->new McpClient().initializeAndListTools()));
        ask.addActionListener(e->{String q=input.getText().trim();if(q.isEmpty()){output.setText("Enter a question first.");return;}refreshMode(modeLabel);String c=collect(project);runBackground(output,"Engineering AI is analyzing IDE context and available centralized MCP knowledge/tools...",()->new AiOrchestrator().ask(q,c));});
        Content content=ContentFactory.getInstance().createContent(root,"",false);toolWindow.getContentManager().addContent(content);
    }
    private String collect(Project p){return IdeContextProvider.collect(p);}
    private void refreshMode(JLabel l){var s=EngineeringAiSettings.getInstance().getState();l.setText(s==null?"Mode: ?":"Mode: "+s.mode+" | LLM: "+(s.llmEnabled?"ON":"OFF"));}
    private void runBackground(JBTextArea output,String loading,ThrowingSupplier supplier){output.setText(loading);ApplicationManager.getApplication().executeOnPooledThread(()->{String r;try{r=supplier.get();}catch(Exception ex){r="ERROR\n\n"+ex.getMessage();}String f=r;ApplicationManager.getApplication().invokeLater(()->output.setText(f));});}
    @FunctionalInterface private interface ThrowingSupplier{String get()throws Exception;}
}
