# MCP Shared Knowledge Contract

Engineering AI 1.2.0 assumes shared `.md` files and prompts can live in one centrally managed Bitbucket repository such as `xyzagent`.

The IntelliJ plugin does **not** connect to Bitbucket directly. The MCP server owns:

- Bitbucket repository URL/workspace/project
- authentication and authorization
- branch selection
- caching/refresh
- Markdown parsing/indexing
- access controls/audit

## Recommended MCP tools

The plugin discovers tools through standard MCP `tools/list`, so exact names are configurable on the server. Recommended contracts are below.

### `search_shared_docs`

Search relevant Markdown knowledge without returning the entire repo.

Input example:

```json
{
  "query": "bc-login null pointer QA authentication",
  "service": "bc-login",
  "environment": "qa",
  "limit": 5
}
```

Recommended output:

```json
{
  "results": [
    {
      "path": "knowledge/services/bc-login.md",
      "section": "Known failure modes",
      "content": "...relevant excerpt...",
      "commit": "abc123"
    }
  ]
}
```

### `get_service_context`

Input:

```json
{
  "service": "bc-login",
  "environment": "qa"
}
```

Returns service ownership, dependencies, observability mappings, runbooks and relevant shared documentation.

### `get_prompt`

Input:

```json
{
  "name": "investigation"
}
```

Returns the centrally managed prompt body plus source/version metadata.

### `get_shared_context`

Use for a compact common context bundle when your MCP server already performs retrieval/ranking.

## Recommended xyzagent repository layout

```text
xyzagent/
├── prompts/
│   ├── system-prompt.md
│   ├── investigation.md
│   └── code-review.md
├── knowledge/
│   ├── architecture/
│   ├── services/
│   └── troubleshooting/
└── service-catalog/
```

## Important behavior

- Return only relevant chunks, not every `.md` file.
- Include source path and commit/version metadata where possible.
- Do not send Bitbucket access tokens to the IntelliJ plugin or LLM.
- If Bitbucket is unavailable, MCP may serve last-known-good cached content and mark it as cached/stale.
- If MCP is unavailable, Engineering AI 1.2.0 falls back to LLM + IDE code context.
