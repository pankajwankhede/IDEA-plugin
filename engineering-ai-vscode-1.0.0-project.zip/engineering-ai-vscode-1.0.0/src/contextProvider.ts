import * as vscode from 'vscode';
import { EngineeringAiConfig } from './config';

export function collectIdeContext(config: EngineeringAiConfig): string {
  const editor = vscode.window.activeTextEditor;
  if (!editor) return 'No active editor context.';

  const parts: string[] = [];
  const doc = editor.document;

  parts.push(`Language: ${doc.languageId}`);
  parts.push(`File: ${doc.uri.fsPath}`);

  if (config.includeSelection && !editor.selection.isEmpty) {
    parts.push('Selected code:\n' + doc.getText(editor.selection));
  }

  if (config.includeCurrentFile) {
    const text = doc.getText();
    const max = 18000;
    parts.push('Current file:\n' + (text.length > max ? text.slice(0, max) + '\n...[truncated]' : text));
  }

  return parts.join('\n\n');
}
