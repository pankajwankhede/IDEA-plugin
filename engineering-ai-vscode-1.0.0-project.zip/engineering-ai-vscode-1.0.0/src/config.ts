import * as vscode from 'vscode';

export type Mode = 'AUTO' | 'LLM_GATEWAY' | 'DIRECT_MCP';

export interface EngineeringAiConfig {
  mode: Mode;
  llmEnabled: boolean;
  llmBaseUrl: string;
  llmModel: string;
  llmTokenEnv: string;
  mcpBaseUrl: string;
  includeCurrentFile: boolean;
  includeSelection: boolean;
}

export function getConfig(): EngineeringAiConfig {
  const c = vscode.workspace.getConfiguration('engineeringAi');
  return {
    mode: c.get<Mode>('mode', 'AUTO'),
    llmEnabled: c.get<boolean>('llm.enabled', true),
    llmBaseUrl: c.get<string>('llm.baseUrl', ''),
    llmModel: c.get<string>('llm.model', 'enterprise-model'),
    llmTokenEnv: c.get<string>('llm.tokenEnv', 'ENGINEERING_AI_LLM_TOKEN'),
    mcpBaseUrl: c.get<string>('mcp.baseUrl', 'http://localhost:8080/mcp'),
    includeCurrentFile: c.get<boolean>('context.includeCurrentFile', true),
    includeSelection: c.get<boolean>('context.includeSelection', true)
  };
}
