export interface McpTool {
  name: string;
  description?: string;
  inputSchema?: unknown;
}

export class McpClient {
  constructor(private readonly baseUrl: string) {}

  private async rpc(method: string, params?: unknown): Promise<any> {
    const response = await fetch(this.baseUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: Date.now(),
        method,
        params: params ?? {}
      })
    });

    if (!response.ok) {
      throw new Error(`MCP HTTP ${response.status}`);
    }

    const json: any = await response.json();
    if (json.error) {
      throw new Error(json.error.message ?? 'MCP error');
    }
    return json.result;
  }

  async initialize(): Promise<any> {
    return this.rpc('initialize', {
      protocolVersion: '2025-03-26',
      capabilities: {},
      clientInfo: {
        name: 'engineering-ai-vscode',
        version: '1.0.0'
      }
    });
  }

  async listTools(): Promise<McpTool[]> {
    const result = await this.rpc('tools/list', {});
    return result?.tools ?? [];
  }

  async callTool(name: string, args: Record<string, unknown>): Promise<any> {
    return this.rpc('tools/call', {
      name,
      arguments: args
    });
  }

  async directAsk(question: string, context: string): Promise<string> {
    const tools = await this.listTools();
    const askTool = tools.find(t => t.name === 'engineering_ask') ?? tools[0];
    if (!askTool) throw new Error('MCP server returned no tools.');

    const result = await this.callTool(askTool.name, { question, context });
    return stringifyMcpContent(result);
  }
}

export function stringifyMcpContent(result: any): string {
  if (Array.isArray(result?.content)) {
    return result.content.map((x: any) => x.text ?? JSON.stringify(x)).join('\n');
  }
  return typeof result === 'string' ? result : JSON.stringify(result, null, 2);
}
