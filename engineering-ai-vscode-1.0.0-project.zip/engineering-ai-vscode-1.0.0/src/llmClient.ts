import { McpClient, McpTool, stringifyMcpContent } from './mcpClient';

interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string | null;
  tool_call_id?: string;
  tool_calls?: any[];
}

export class LlmGatewayClient {
  constructor(
    private readonly baseUrl: string,
    private readonly model: string,
    private readonly tokenEnv: string
  ) {}

  private get token(): string | undefined {
    return process.env[this.tokenEnv];
  }

  async ask(question: string, context: string, mcp?: McpClient): Promise<string> {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content:
          'You are an enterprise engineering assistant. Use IDE code context directly. ' +
          'Use MCP tools when live enterprise data or centralized shared knowledge is needed. ' +
          'If a tool or source is unavailable, say so and never invent results.'
      },
      {
        role: 'user',
        content: `Question:\n${question}\n\nIDE Context:\n${context}`
      }
    ];

    let tools: any[] | undefined;
    if (mcp) {
      try {
        const mcpTools = await mcp.listTools();
        tools = mcpTools.map(toOpenAiTool);
      } catch {
        tools = undefined;
      }
    }

    for (let round = 0; round < 4; round++) {
      const response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(this.token ? { Authorization: `Bearer ${this.token}` } : {})
        },
        body: JSON.stringify({
          model: this.model,
          messages,
          ...(tools && tools.length ? { tools, tool_choice: 'auto' } : {})
        })
      });

      if (!response.ok) {
        throw new Error(`LLM HTTP ${response.status}`);
      }

      const json: any = await response.json();
      const msg = json?.choices?.[0]?.message;
      if (!msg) throw new Error('LLM gateway returned no message.');

      const calls = msg.tool_calls ?? [];
      if (!calls.length || !mcp) {
        return msg.content ?? '';
      }

      messages.push({
        role: 'assistant',
        content: msg.content ?? null,
        tool_calls: calls
      });

      for (const call of calls) {
        const name = call?.function?.name;
        let args: Record<string, unknown> = {};
        try {
          args = JSON.parse(call?.function?.arguments ?? '{}');
        } catch {
          args = {};
        }

        try {
          const result = await mcp.callTool(name, args);
          messages.push({
            role: 'tool',
            tool_call_id: call.id,
            content: stringifyMcpContent(result)
          });
        } catch (e: any) {
          messages.push({
            role: 'tool',
            tool_call_id: call.id,
            content: `MCP tool unavailable or failed: ${e?.message ?? e}`
          });
        }
      }
    }

    return 'Maximum MCP tool rounds reached.';
  }
}

function toOpenAiTool(tool: McpTool): any {
  return {
    type: 'function',
    function: {
      name: tool.name,
      description: tool.description ?? '',
      parameters: tool.inputSchema ?? { type: 'object', properties: {} }
    }
  };
}
