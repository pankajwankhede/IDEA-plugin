import * as vscode from 'vscode';
import { getConfig } from './config';
import { collectIdeContext } from './contextProvider';
import { AiOrchestrator } from './orchestrator';
import { ChatViewProvider } from './chatViewProvider';

async function askQuestion(question: string): Promise<string> {
  const config = getConfig();
  const context = collectIdeContext(config);
  return new AiOrchestrator(config).ask(question, context);
}

export function activate(context: vscode.ExtensionContext): void {
  const provider = new ChatViewProvider(context.extensionUri, askQuestion);
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(ChatViewProvider.viewType, provider)
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('engineeringAi.ask', async () => {
      const question = await vscode.window.showInputBox({
        prompt: 'Ask Engineering AI'
      });
      if (!question) return;

      await vscode.window.withProgress(
        {
          location: vscode.ProgressLocation.Notification,
          title: 'Engineering AI'
        },
        async () => {
          try {
            const answer = await askQuestion(question);
            const doc = await vscode.workspace.openTextDocument({
              content: answer,
              language: 'markdown'
            });
            await vscode.window.showTextDocument(doc, { preview: true });
          } catch (e: any) {
            vscode.window.showErrorMessage(e?.message ?? String(e));
          }
        }
      );
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('engineeringAi.askSelection', async () => {
      const editor = vscode.window.activeTextEditor;
      const selection = editor?.selection;
      const selected = editor && selection && !selection.isEmpty
        ? editor.document.getText(selection)
        : '';

      const question = await vscode.window.showInputBox({
        prompt: selected ? 'Ask about selected code' : 'Ask Engineering AI'
      });
      if (!question) return;

      try {
        const answer = await askQuestion(question);
        const doc = await vscode.workspace.openTextDocument({
          content: answer,
          language: 'markdown'
        });
        await vscode.window.showTextDocument(doc, { preview: true });
      } catch (e: any) {
        vscode.window.showErrorMessage(e?.message ?? String(e));
      }
    })
  );
}

export function deactivate(): void {}
