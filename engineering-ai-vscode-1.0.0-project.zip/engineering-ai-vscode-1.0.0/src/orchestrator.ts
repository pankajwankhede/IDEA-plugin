import { EngineeringAiConfig } from './config';
import { LlmGatewayClient } from './llmClient';
import { McpClient } from './mcpClient';

export class AiOrchestrator {
  constructor(private readonly config: EngineeringAiConfig) {}

  async ask(question: string, context: string): Promise<string> {
    const mcp = new McpClient(this.config.mcpBaseUrl);

    if (this.config.mode === 'DIRECT_MCP' || !this.config.llmEnabled) {
      return mcp.directAsk(question, context);
    }

    const llm = new LlmGatewayClient(
      this.config.llmBaseUrl,
      this.config.llmModel,
      this.config.llmTokenEnv
    );

    if (this.config.mode === 'LLM_GATEWAY') {
      return llm.ask(question, context, mcp);
    }

    // AUTO
    try {
      if (!this.config.llmBaseUrl) throw new Error('LLM URL not configured');
      return await llm.ask(question, context, mcp);
    } catch (llmError: any) {
      try {
        return await mcp.directAsk(question, context);
      } catch (mcpError: any) {
        throw new Error(
          `LLM unavailable (${llmError?.message ?? llmError}) and MCP unavailable (${mcpError?.message ?? mcpError}).`
        );
      }
    }
  }
}
