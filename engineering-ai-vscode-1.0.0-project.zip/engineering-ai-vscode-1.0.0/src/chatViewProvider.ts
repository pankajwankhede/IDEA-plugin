import * as vscode from 'vscode';

export class ChatViewProvider implements vscode.WebviewViewProvider {
  public static readonly viewType = 'engineeringAi.chatView';

  constructor(
    private readonly extensionUri: vscode.Uri,
    private readonly onAsk: (question: string) => Promise<string>
  ) {}

  resolveWebviewView(webviewView: vscode.WebviewView): void {
    webviewView.webview.options = { enableScripts: true };
    webviewView.webview.html = this.html();

    webviewView.webview.onDidReceiveMessage(async message => {
      if (message?.type !== 'ask') return;
      webviewView.webview.postMessage({ type: 'status', text: 'Working...' });
      try {
        const answer = await this.onAsk(message.question);
        webviewView.webview.postMessage({ type: 'answer', text: answer });
      } catch (e: any) {
        webviewView.webview.postMessage({ type: 'answer', text: `Error: ${e?.message ?? e}` });
      } finally {
        webviewView.webview.postMessage({ type: 'status', text: '' });
      }
    });
  }

  private html(): string {
    return `<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<style>
body{font-family:var(--vscode-font-family);padding:10px}
textarea{width:100%;min-height:100px;box-sizing:border-box}
button{margin-top:8px}
pre{white-space:pre-wrap;word-wrap:break-word}
</style>
</head>
<body>
<h3>Engineering AI</h3>
<textarea id="q" placeholder="Ask about your code, shared knowledge, logs, dependencies..."></textarea>
<br/>
<button id="ask">Ask</button>
<div id="status"></div>
<pre id="answer"></pre>
<script>
const vscode = acquireVsCodeApi();
document.getElementById('ask').onclick = () => {
  const question = document.getElementById('q').value;
  vscode.postMessage({type:'ask', question});
};
window.addEventListener('message', e => {
  if(e.data.type==='answer') document.getElementById('answer').textContent=e.data.text;
  if(e.data.type==='status') document.getElementById('status').textContent=e.data.text;
});
</script>
</body>
</html>`;
  }
}
