# Architecture

```text
VS Code Extension
      |
      +-- Current File
      +-- Selected Code
      +-- Developer Question
      |
      v
LLM Gateway (optional)
      |
      v
engineering-mcp-server
      |
      +-- Bitbucket xyzagent
      +-- Splunk
      +-- New Relic
      +-- PCF
      +-- Oracle
      +-- SQL Server
      +-- Jenkins
```

The VS Code extension does not hold Bitbucket or enterprise-system credentials.
Those remain in `engineering-mcp-server`.
