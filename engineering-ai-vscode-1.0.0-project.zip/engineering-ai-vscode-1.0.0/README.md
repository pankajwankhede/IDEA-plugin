# Engineering AI VS Code Extension 1.0.0

This extension is the VS Code companion to the IntelliJ Engineering AI plugin.

## Architecture

VS Code -> LLM Gateway -> MCP Server -> Bitbucket `xyzagent` + enterprise tools

The MCP server remains separate. The VS Code extension only needs the MCP endpoint and optional LLM gateway settings.

## Features

- Ask Engineering AI from the Command Palette.
- Ask about selected code from the editor context menu.
- Includes current-file and selected-code context.
- Supports AUTO, LLM_GATEWAY, and DIRECT_MCP modes.
- Supports LLM enable/disable.
- Discovers MCP tools dynamically using `tools/list`.
- Calls MCP tools using `tools/call`.
- Uses centralized Bitbucket knowledge through the MCP server; the extension does not read the `xyzagent` repo directly.

## Configure

Open VS Code Settings and search for **Engineering AI**.

Example:

```json
{
  "engineeringAi.mode": "AUTO",
  "engineeringAi.llm.enabled": true,
  "engineeringAi.llm.baseUrl": "https://engineering-ai.company.com/v1/chat/completions",
  "engineeringAi.llm.model": "enterprise-model",
  "engineeringAi.llm.tokenEnv": "ENGINEERING_AI_LLM_TOKEN",
  "engineeringAi.mcp.baseUrl": "https://engineering-mcp.company.com/mcp"
}
```

## Development

```bash
npm install
npm run compile
```

Press **F5** in VS Code to launch an Extension Development Host.

## Build VSIX

Install the VS Code extension packaging CLI:

```bash
npm install -g @vscode/vsce
```

Then:

```bash
vsce package
```

This produces a `.vsix` file that can be installed with:

```bash
code --install-extension engineering-ai-vscode-1.0.0.vsix
```
