# Engineering AI 1.4.0 — Implemented Feature Map

## Header
- LLM ON/OFF toggle
- Mode status
- Settings shortcut
- Dynamic enabled-source display

## AI Chat
- Selected Code
- Current File
- Choose File
- Choose Folder
- Natural-language prompt
- Review type
- Framework
- Use MCP Knowledge Base
- Send to AI (LLM + MCP)
- Response tabs

## Direct MCP
- Refresh MCP Tools
- Dynamic tools/list
- Tool descriptions
- JSON templates from inputSchema
- Optional local source injection
- Run tool
- Result panel

## Knowledge Base
- Hidden when MCP knowledge is unavailable
- Agents list/get
- Skills list/get
- Instructions list/get
- Scripts list/get
- Shared docs search

## History
- Persisted application-level history
- Maximum 50 entries
- AI Chat, MCP tools, and shared-doc searches

## Capability mapping

`tools/list` is the source of truth. No additional MCP endpoint is required for feature visibility.

- Knowledge: `search_shared_docs`, `get_prompt`, `get_service_context`, `list/get agents`, `list/get skills`, `list/get instructions`, `list/get scripts`
- Splunk: `splunk*` or `search_splunk`
- New Relic: `new_relic*`, `newrelic*`, or `search_new_relic`
- PCF: `pcf*` or `get_pcf_app_status`
- Oracle: `oracle*` or `query_oracle`
- SQL Server: `sql_server*`, `sqlserver*`, or `query_sql_server`
- Jenkins: `jenkins*` or `get_jenkins_build`
