# Implementation Notes

This project implements the discussed design in IntelliJ Swing components rather than embedding a web UI.

The reference mockups are visual targets; actual sizing adapts to the IntelliJ Tool Window width and current IDE theme.

## No MCP server UI changes required

Feature visibility is inferred from `tools/list`. The plugin does not require a separate `get_capabilities` endpoint.

## LLM OFF

- Header toggle switches state to `DIRECT_MCP`.
- AI Chat is disabled.
- MCP Tools remains fully operational.
- Knowledge Base remains operational when knowledge tools exist.

## LLM ON

- Header toggle switches mode to `AUTO`.
- AI Chat accepts natural-language prompts.
- Local source context is included based on Selected Code / Current File / Choose File / Choose Folder.
- The LLM receives the authoritative MCP tool definitions and may call them automatically.

## Local folder safety

Folder context honors settings limits:
- maximum files
- maximum characters per file
- ignored folders such as `.git`, `.idea`, `build`, `target`, `node_modules`, `out`, and `dist`
