package com.company.engineeringai.toolwindow;

import com.company.engineeringai.context.IdeContextProvider;
import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;

import javax.swing.*;
import java.awt.*;
import java.nio.file.Path;
import java.util.EnumMap;
import java.util.Map;

public final class SourceSelectorPanel extends JPanel {
    public enum SourceChoice {
        SELECTED_CODE("Selected Code"),
        CURRENT_FILE("Current File"),
        CHOOSE_FILE("Choose File..."),
        CHOOSE_FOLDER("Choose Folder...");

        private final String label;
        SourceChoice(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    private final Project project;
    private final Map<SourceChoice, JToggleButton> buttons = new EnumMap<>(SourceChoice.class);
    private final JTextField pathField = new JTextField();
    private final JButton browseButton = new JButton("Browse...");
    private SourceChoice choice = SourceChoice.CURRENT_FILE;
    private Path selectedPath;

    public SourceSelectorPanel(Project project) {
        super(new BorderLayout(8, 6));
        this.project = project;
        setOpaque(false);
        pathField.setEditable(false);

        JPanel choices = new JPanel(new GridLayout(1, 4, 6, 0));
        choices.setOpaque(false);
        ButtonGroup group = new ButtonGroup();
        for (SourceChoice c : SourceChoice.values()) {
            JToggleButton button = new JToggleButton(c.toString());
            buttons.put(c, button);
            group.add(button);
            choices.add(button);
            button.addActionListener(e -> {
                choice = c;
                selectedPath = null;
                refreshForChoice();
                if (c == SourceChoice.CHOOSE_FILE || c == SourceChoice.CHOOSE_FOLDER) choosePath();
            });
        }
        buttons.get(SourceChoice.CURRENT_FILE).setSelected(true);

        JPanel pathRow = new JPanel(new BorderLayout(8, 0));
        pathRow.setOpaque(false);
        pathRow.add(pathField, BorderLayout.CENTER);
        pathRow.add(browseButton, BorderLayout.EAST);
        browseButton.addActionListener(e -> choosePath());

        add(choices, BorderLayout.NORTH);
        add(pathRow, BorderLayout.CENTER);
        refreshForChoice();
    }

    public void setChoice(SourceChoice choice) {
        this.choice = choice == null ? SourceChoice.CURRENT_FILE : choice;
        JToggleButton button = buttons.get(this.choice);
        if (button != null) button.setSelected(true);
        selectedPath = null;
        refreshForChoice();
    }

    public SourceChoice choice() { return choice; }

    public String describeSource() {
        return switch (choice) {
            case SELECTED_CODE -> "Selected code in active editor";
            case CURRENT_FILE -> "Current file in active editor";
            case CHOOSE_FILE -> selectedPath == null ? "No file selected" : selectedPath.toString();
            case CHOOSE_FOLDER -> selectedPath == null ? "No folder selected" : selectedPath.toString();
        };
    }

    public String collectContext() throws Exception {
        return switch (choice) {
            case SELECTED_CODE -> IdeContextProvider.collectSelectedCode(project);
            case CURRENT_FILE -> IdeContextProvider.collectCurrentFile(project);
            case CHOOSE_FILE -> {
                if (selectedPath == null) throw new IllegalStateException("Choose a file first.");
                yield IdeContextProvider.collectFile(selectedPath);
            }
            case CHOOSE_FOLDER -> {
                if (selectedPath == null) throw new IllegalStateException("Choose a folder first.");
                yield IdeContextProvider.collectFolder(selectedPath);
            }
        };
    }

    private void refreshForChoice() {
        boolean browse = choice == SourceChoice.CHOOSE_FILE || choice == SourceChoice.CHOOSE_FOLDER;
        browseButton.setVisible(browse);
        if (!browse) {
            pathField.setText(choice == SourceChoice.SELECTED_CODE ? "Uses highlighted editor selection" : "Uses the active editor file");
        } else {
            pathField.setText(selectedPath == null ? (choice == SourceChoice.CHOOSE_FILE ? "Select a local file" : "Select a local folder") : selectedPath.toString());
        }
        revalidate();
        repaint();
    }

    private void choosePath() {
        FileChooserDescriptor descriptor = choice == SourceChoice.CHOOSE_FOLDER
                ? FileChooserDescriptorFactory.createSingleFolderDescriptor()
                : FileChooserDescriptorFactory.createSingleFileDescriptor();
        descriptor.setTitle(choice == SourceChoice.CHOOSE_FOLDER ? "Choose Source Folder" : "Choose Source File");
        VirtualFile file = FileChooser.chooseFile(descriptor, project, null);
        if (file != null) selectedPath = Path.of(file.getPath());
        refreshForChoice();
    }
}
