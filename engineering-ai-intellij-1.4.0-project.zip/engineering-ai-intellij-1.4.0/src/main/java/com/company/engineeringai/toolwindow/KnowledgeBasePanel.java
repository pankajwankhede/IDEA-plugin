package com.company.engineeringai.toolwindow;

import com.company.engineeringai.mcp.McpCapabilities;
import com.company.engineeringai.mcp.McpClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.intellij.openapi.project.Project;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

public final class KnowledgeBasePanel extends JPanel {
    private enum Category {
        AGENTS("Agents", "list_agents", "get_agent"),
        SKILLS("Skills", "list_skills", "get_skill"),
        INSTRUCTIONS("Instructions", "list_instructions", "get_instruction"),
        SCRIPTS("Scripts", "list_scripts", "get_script"),
        SHARED_DOCS("Shared Docs", null, "search_shared_docs");

        final String label;
        final String listTool;
        final String getTool;
        Category(String label, String listTool, String getTool) {
            this.label = label;
            this.listTool = listTool;
            this.getTool = getTool;
        }
        @Override public String toString() { return label; }
    }

    private final McpClient mcp = new McpClient();
    private final JList<Category> categories = new JList<>(Category.values());
    private final DefaultListModel<String> itemModel = new DefaultListModel<>();
    private final JList<String> items = new JList<>(itemModel);
    private final JTextArea content = UiSupport.textArea(24, false);
    private final JTextField search = new JTextField();
    private final JButton refresh = new JButton("Refresh Knowledge");
    private final JButton useInChat = new JButton("Copy to Clipboard");
    private final JLabel status = UiSupport.muted("Knowledge Base not loaded");
    private final Consumer<McpCapabilities> capabilitiesConsumer;
    private final Set<String> availableTools = new LinkedHashSet<>();

    public KnowledgeBasePanel(Project project, Consumer<McpCapabilities> capabilitiesConsumer) {
        super(new BorderLayout(8, 8));
        this.capabilitiesConsumer = capabilitiesConsumer;
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel header = UiSupport.card();
        header.add(UiSupport.title("Knowledge Base"), BorderLayout.WEST);
        JPanel controls = new JPanel(new BorderLayout(8, 0));
        controls.setOpaque(false);
        search.setToolTipText("Search centralized engineering knowledge");
        controls.add(search, BorderLayout.CENTER);
        controls.add(refresh, BorderLayout.EAST);
        header.add(controls, BorderLayout.CENTER);
        add(header, BorderLayout.NORTH);

        categories.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        categories.setSelectedIndex(0);
        items.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel leftCard = UiSupport.card();
        leftCard.add(UiSupport.title("Browse"), BorderLayout.NORTH);
        leftCard.add(UiSupport.scroll(categories), BorderLayout.CENTER);

        JPanel middleCard = UiSupport.card();
        middleCard.add(UiSupport.title("Items"), BorderLayout.NORTH);
        middleCard.add(UiSupport.scroll(items), BorderLayout.CENTER);
        middleCard.add(status, BorderLayout.SOUTH);

        JPanel rightCard = UiSupport.card();
        rightCard.add(UiSupport.title("Content"), BorderLayout.NORTH);
        rightCard.add(UiSupport.scroll(content), BorderLayout.CENTER);
        rightCard.add(useInChat, BorderLayout.SOUTH);

        JSplitPane leftSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftCard, middleCard);
        leftSplit.setResizeWeight(0.35);
        leftSplit.setBorder(BorderFactory.createEmptyBorder());
        JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftSplit, rightCard);
        mainSplit.setResizeWeight(0.52);
        mainSplit.setBorder(BorderFactory.createEmptyBorder());
        add(mainSplit, BorderLayout.CENTER);

        refresh.addActionListener(e -> loadToolsThenCategory());
        search.addActionListener(e -> searchSharedDocs());
        categories.addListSelectionListener(this::categoryChanged);
        items.addListSelectionListener(this::itemChanged);
        useInChat.addActionListener(e -> {
            content.selectAll();
            content.copy();
            content.select(0, 0);
            status.setText("Content copied to clipboard");
        });

        loadToolsThenCategory();
    }

    public void setCapabilities(McpCapabilities capabilities) {
        // The authoritative list is already loaded by this panel. This method exists for symmetry with other panels.
    }

    private void loadToolsThenCategory() {
        refresh.setEnabled(false);
        status.setText("Discovering knowledge tools...");
        SwingWorker<JsonArray, Void> worker = new SwingWorker<>() {
            @Override protected JsonArray doInBackground() throws Exception { return mcp.listTools(); }
            @Override protected void done() {
                try {
                    JsonArray tools = get();
                    availableTools.clear();
                    for (JsonElement e : tools) if (e.isJsonObject() && e.getAsJsonObject().has("name")) availableTools.add(e.getAsJsonObject().get("name").getAsString());
                    McpCapabilities caps = new McpCapabilities(tools);
                    if (capabilitiesConsumer != null) capabilitiesConsumer.accept(caps);
                    status.setText(caps.knowledge() ? "Centralized knowledge available" : "Knowledge tools are not enabled on MCP server");
                    loadCategory();
                } catch (Exception ex) {
                    content.setText("Unable to load Knowledge Base.\n\n" + UiSupport.safe(ex));
                    status.setText("MCP unavailable");
                } finally {
                    refresh.setEnabled(true);
                }
            }
        };
        worker.execute();
    }

    private void categoryChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) loadCategory();
    }

    private void loadCategory() {
        Category category = categories.getSelectedValue();
        if (category == null) return;
        itemModel.clear();
        content.setText("");
        if (category == Category.SHARED_DOCS) {
            itemModel.addElement("Search shared documentation using the search box above");
            status.setText(availableTools.contains("search_shared_docs") ? "Type a query and press Enter" : "search_shared_docs is not available");
            return;
        }
        if (category.listTool == null || !availableTools.contains(category.listTool)) {
            status.setText(category.listTool + " is not exposed by MCP server");
            return;
        }
        status.setText("Loading " + category.label.toLowerCase() + "...");
        SwingWorker<String, Void> worker = new SwingWorker<>() {
            @Override protected String doInBackground() throws Exception { return mcp.callToolAsText(category.listTool, new JsonObject()); }
            @Override protected void done() {
                try {
                    List<String> names = parseNames(get());
                    for (String name : names) itemModel.addElement(name);
                    status.setText(names.isEmpty() ? "No items returned by " + category.listTool : names.size() + " items");
                    if (!names.isEmpty()) items.setSelectedIndex(0);
                } catch (Exception ex) {
                    status.setText("Failed: " + UiSupport.safe(ex));
                    content.setText("Unable to list " + category.label + ".\n\n" + UiSupport.safe(ex));
                }
            }
        };
        worker.execute();
    }

    private void itemChanged(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        Category category = categories.getSelectedValue();
        String item = items.getSelectedValue();
        if (category == null || item == null || category == Category.SHARED_DOCS) return;
        if (category.getTool == null || !availableTools.contains(category.getTool)) {
            content.setText("The MCP server exposes " + category.listTool + " but not " + category.getTool + ".\n\nSelected item: " + item);
            return;
        }
        status.setText("Loading " + item + "...");
        SwingWorker<String, Void> worker = new SwingWorker<>() {
            @Override protected String doInBackground() throws Exception {
                JsonObject args = new JsonObject();
                args.addProperty("name", normalizeName(item));
                return mcp.callToolAsText(category.getTool, args);
            }
            @Override protected void done() {
                try {
                    String text = get();
                    content.setText(text);
                    content.setCaretPosition(0);
                    status.setText("Loaded " + item);
                } catch (Exception ex) {
                    content.setText("Unable to load " + item + ".\n\n" + UiSupport.safe(ex));
                    status.setText("Failed");
                }
            }
        };
        worker.execute();
    }

    private void searchSharedDocs() {
        String query = search.getText() == null ? "" : search.getText().trim();
        if (query.isBlank()) return;
        if (!availableTools.contains("search_shared_docs")) {
            content.setText("search_shared_docs is not available on the MCP server.");
            return;
        }
        categories.setSelectedValue(Category.SHARED_DOCS, true);
        status.setText("Searching shared docs...");
        SwingWorker<String, Void> worker = new SwingWorker<>() {
            @Override protected String doInBackground() throws Exception {
                JsonObject args = new JsonObject();
                args.addProperty("query", query);
                return mcp.callToolAsText("search_shared_docs", args);
            }
            @Override protected void done() {
                try {
                    String result = get();
                    content.setText(result);
                    content.setCaretPosition(0);
                    status.setText("Search completed");
                    EngineeringAiHistoryService.getInstance().add(new EngineeringAiHistoryService.HistoryEntry(
                            "Knowledge Base", "Search: " + query, query, "Central shared knowledge", result));
                } catch (Exception ex) {
                    content.setText("Search failed.\n\n" + UiSupport.safe(ex));
                    status.setText("Failed");
                }
            }
        };
        worker.execute();
    }

    private static String normalizeName(String item) {
        String value = item.trim();
        if (value.startsWith("-") || value.startsWith("*")) value = value.substring(1).trim();
        return value;
    }

    private static List<String> parseNames(String raw) {
        Set<String> out = new LinkedHashSet<>();
        if (raw == null || raw.isBlank()) return new ArrayList<>();
        String text = raw.trim();
        try {
            JsonElement parsed = JsonParser.parseString(text);
            collectJsonStrings(parsed, out);
        } catch (Exception ignored) {
            for (String line : text.split("\\R")) {
                String value = line.trim();
                if (value.isBlank()) continue;
                value = value.replaceFirst("^[\\-*•\\d.\\)\\s]+", "").trim();
                if (value.startsWith("{") || value.startsWith("[") || value.equalsIgnoreCase("content")) continue;
                if (value.length() <= 160) out.add(value);
            }
        }
        return new ArrayList<>(out);
    }

    private static void collectJsonStrings(JsonElement element, Set<String> out) {
        if (element == null || element.isJsonNull()) return;
        if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
            String s = element.getAsString().trim();
            if (!s.isBlank() && s.length() <= 160) out.add(s);
            return;
        }
        if (element.isJsonArray()) {
            for (JsonElement child : element.getAsJsonArray()) collectJsonStrings(child, out);
            return;
        }
        if (element.isJsonObject()) {
            JsonObject obj = element.getAsJsonObject();
            for (String key : new String[]{"name", "path", "file", "title"}) if (obj.has(key)) collectJsonStrings(obj.get(key), out);
            if (out.isEmpty()) for (String key : obj.keySet()) collectJsonStrings(obj.get(key), out);
        }
    }
}
