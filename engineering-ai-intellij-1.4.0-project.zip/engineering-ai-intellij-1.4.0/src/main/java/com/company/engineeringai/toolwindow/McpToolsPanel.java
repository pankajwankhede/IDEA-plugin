package com.company.engineeringai.toolwindow;

import com.company.engineeringai.mcp.McpCapabilities;
import com.company.engineeringai.mcp.McpClient;
import com.google.gson.*;
import com.intellij.openapi.project.Project;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

public final class McpToolsPanel extends JPanel {
    private final Project project;
    private final McpClient mcp = new McpClient();
    private final JComboBox<String> toolCombo = new JComboBox<>();
    private final JButton refreshButton = new JButton("Refresh MCP Tools");
    private final JTextArea toolDescription = UiSupport.textArea(3, false);
    private final JTextArea argumentsArea = UiSupport.textArea(10, true);
    private final JTextArea resultArea = UiSupport.textArea(18, false);
    private final JCheckBox attachLocal = new JCheckBox("Attach local source when tool schema supports code/context", true);
    private final SourceSelectorPanel sourceSelector;
    private final JButton runButton = new JButton("Run MCP Tool");
    private final JLabel status = UiSupport.muted("Not connected");
    private final Map<String, JsonObject> tools = new LinkedHashMap<>();
    private final Consumer<McpCapabilities> capabilitiesConsumer;

    public McpToolsPanel(Project project, Consumer<McpCapabilities> capabilitiesConsumer) {
        super(new BorderLayout(0, 8));
        this.project = project;
        this.capabilitiesConsumer = capabilitiesConsumer;
        this.sourceSelector = new SourceSelectorPanel(project);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel selectorCard = UiSupport.card();
        selectorCard.add(UiSupport.section("1", "Select MCP Tool"), BorderLayout.NORTH);
        JPanel selectorRow = new JPanel(new BorderLayout(8, 0));
        selectorRow.setOpaque(false);
        selectorRow.add(toolCombo, BorderLayout.CENTER);
        selectorRow.add(refreshButton, BorderLayout.EAST);
        selectorCard.add(selectorRow, BorderLayout.CENTER);
        selectorCard.add(UiSupport.scroll(toolDescription), BorderLayout.SOUTH);

        JPanel sourceCard = UiSupport.card();
        sourceCard.add(UiSupport.section("2", "Optional Local Source"), BorderLayout.NORTH);
        JPanel sourceBody = new JPanel(new BorderLayout(4, 4));
        sourceBody.setOpaque(false);
        sourceBody.add(attachLocal, BorderLayout.NORTH);
        sourceBody.add(sourceSelector, BorderLayout.CENTER);
        sourceCard.add(sourceBody, BorderLayout.CENTER);

        JPanel argsCard = UiSupport.card();
        argsCard.add(UiSupport.section("3", "MCP Arguments (JSON) — generated from inputSchema"), BorderLayout.NORTH);
        argsCard.add(UiSupport.scroll(argumentsArea), BorderLayout.CENTER);
        JPanel runRow = new JPanel(new BorderLayout(8, 0));
        runRow.setOpaque(false);
        runRow.add(runButton, BorderLayout.CENTER);
        runRow.add(status, BorderLayout.SOUTH);
        argsCard.add(runRow, BorderLayout.SOUTH);

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setOpaque(false);
        top.add(selectorCard);
        top.add(Box.createVerticalStrut(8));
        top.add(sourceCard);
        top.add(Box.createVerticalStrut(8));
        top.add(argsCard);

        JPanel resultCard = UiSupport.card();
        resultCard.add(UiSupport.title("MCP Tool Result"), BorderLayout.NORTH);
        resultCard.add(UiSupport.scroll(resultArea), BorderLayout.CENTER);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, UiSupport.scroll(top), resultCard);
        split.setResizeWeight(0.58);
        split.setBorder(BorderFactory.createEmptyBorder());
        add(split, BorderLayout.CENTER);

        refreshButton.addActionListener(e -> refreshTools());
        toolCombo.addActionListener(e -> selectedToolChanged());
        runButton.addActionListener(e -> runTool());
        refreshTools();
    }

    public void refreshTools() {
        refreshButton.setEnabled(false);
        runButton.setEnabled(false);
        status.setText("Loading tools...");
        SwingWorker<JsonArray, Void> worker = new SwingWorker<>() {
            @Override protected JsonArray doInBackground() throws Exception { return mcp.listTools(); }
            @Override protected void done() {
                try {
                    JsonArray array = get();
                    tools.clear();
                    toolCombo.removeAllItems();
                    for (JsonElement element : array) {
                        if (!element.isJsonObject()) continue;
                        JsonObject tool = element.getAsJsonObject();
                        if (!tool.has("name")) continue;
                        String name = tool.get("name").getAsString();
                        tools.put(name, tool);
                        toolCombo.addItem(name);
                    }
                    McpCapabilities capabilities = new McpCapabilities(array);
                    if (capabilitiesConsumer != null) capabilitiesConsumer.accept(capabilities);
                    status.setText(tools.isEmpty() ? "Connected, but no tools were returned" : tools.size() + " MCP tools available");
                    runButton.setEnabled(!tools.isEmpty());
                    if (!tools.isEmpty()) toolCombo.setSelectedIndex(0);
                    selectedToolChanged();
                } catch (Exception ex) {
                    resultArea.setText("ERROR loading MCP tools\n\n" + UiSupport.safe(ex));
                    status.setText("MCP unavailable");
                    if (capabilitiesConsumer != null) capabilitiesConsumer.accept(new McpCapabilities(new JsonArray()));
                } finally {
                    refreshButton.setEnabled(true);
                }
            }
        };
        worker.execute();
    }

    private void selectedToolChanged() {
        String name = (String) toolCombo.getSelectedItem();
        JsonObject tool = name == null ? null : tools.get(name);
        if (tool == null) {
            toolDescription.setText("");
            argumentsArea.setText("{}");
            return;
        }
        String description = tool.has("description") && !tool.get("description").isJsonNull()
                ? tool.get("description").getAsString() : "No description supplied by MCP server.";
        toolDescription.setText(name + "\n\n" + description);
        argumentsArea.setText(mcp.pretty(mcp.buildArgumentTemplate(tool)));
        attachLocal.setEnabled(findContextField(tool) != null);
        if (!attachLocal.isEnabled()) attachLocal.setSelected(false);
    }

    private void runTool() {
        String name = (String) toolCombo.getSelectedItem();
        JsonObject tool = name == null ? null : tools.get(name);
        if (name == null || tool == null) return;
        runButton.setEnabled(false);
        status.setText("Running " + name + "...");
        resultArea.setText("");

        SwingWorker<String, Void> worker = new SwingWorker<>() {
            private String sourceDescription = "";
            @Override protected String doInBackground() throws Exception {
                JsonObject args = mcp.parseArguments(argumentsArea.getText());
                String contextField = findContextField(tool);
                if (attachLocal.isSelected() && contextField != null) {
                    String context = sourceSelector.collectContext();
                    sourceDescription = sourceSelector.describeSource();
                    args.addProperty(contextField, context);
                }
                return mcp.callToolAsText(name, args);
            }
            @Override protected void done() {
                try {
                    String result = get();
                    resultArea.setText(result);
                    status.setText("Completed");
                    EngineeringAiHistoryService.getInstance().add(new EngineeringAiHistoryService.HistoryEntry(
                            "Direct MCP", name, argumentsArea.getText(), sourceDescription, result));
                } catch (Exception ex) {
                    resultArea.setText("MCP tool failed\n\nException: " + ex.getClass().getName() + "\n\n" + UiSupport.safe(ex));
                    status.setText("Failed");
                } finally {
                    runButton.setEnabled(true);
                }
            }
        };
        worker.execute();
    }

    private static String findContextField(JsonObject tool) {
        if (tool == null || !tool.has("inputSchema") || !tool.get("inputSchema").isJsonObject()) return null;
        JsonObject schema = tool.getAsJsonObject("inputSchema");
        if (!schema.has("properties") || !schema.get("properties").isJsonObject()) return null;
        JsonObject props = schema.getAsJsonObject("properties");
        for (String preferred : new String[]{"code", "context", "source", "content", "localContext", "fileContent"}) {
            if (props.has(preferred)) return preferred;
        }
        return null;
    }
}
