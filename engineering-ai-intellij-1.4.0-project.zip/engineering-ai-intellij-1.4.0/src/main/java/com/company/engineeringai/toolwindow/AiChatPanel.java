package com.company.engineeringai.toolwindow;

import com.company.engineeringai.mcp.McpCapabilities;
import com.company.engineeringai.orchestrator.AiOrchestrator;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.intellij.openapi.project.Project;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public final class AiChatPanel extends JPanel {
    private final Project project;
    private final AiOrchestrator orchestrator = new AiOrchestrator();
    private final SourceSelectorPanel sourceSelector;
    private final JTextArea promptArea = UiSupport.textArea(5, true);
    private final JComboBox<String> reviewType = new JComboBox<>(new String[]{"General", "Security Review", "Code Review", "Debug & Fix", "Performance", "Refactor", "Unit Tests"});
    private final JComboBox<String> framework = new JComboBox<>(new String[]{"Auto Detect", "Spring Boot", "Java", "Kotlin", "SQL", "Frontend"});
    private final JCheckBox useKnowledge = new JCheckBox("Use MCP Knowledge Base", true);
    private final JButton sendButton = new JButton("Send to AI (LLM + MCP)");
    private final JLabel llmDisabled = new JLabel("LLM is OFF. Enable it from the header to use natural-language AI Chat.");
    private final JTextArea responseArea = UiSupport.textArea(18, false);
    private final JTextArea findingsArea = UiSupport.textArea(18, false);
    private final JTextArea suggestionsArea = UiSupport.textArea(18, false);
    private final JTextArea relatedArea = UiSupport.textArea(18, false);
    private final JLabel status = UiSupport.muted("Ready");
    private McpCapabilities capabilities;

    public AiChatPanel(Project project) {
        super(new BorderLayout(0, 10));
        this.project = project;
        this.sourceSelector = new SourceSelectorPanel(project);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setOpaque(false);

        JPanel sourceCard = UiSupport.card();
        sourceCard.add(UiSupport.section("1", "Select Source (what code to analyze?)"), BorderLayout.NORTH);
        sourceCard.add(sourceSelector, BorderLayout.CENTER);
        form.add(sourceCard);
        form.add(Box.createVerticalStrut(8));

        JPanel promptCard = UiSupport.card();
        promptCard.add(UiSupport.section("2", "Your Prompt (Natural language)"), BorderLayout.NORTH);
        promptArea.setText("Review this code for security vulnerabilities and suggest production-ready improvements.");
        promptCard.add(UiSupport.scroll(promptArea), BorderLayout.CENTER);
        JPanel promptSouth = new JPanel();
        promptSouth.setLayout(new BoxLayout(promptSouth, BoxLayout.Y_AXIS));
        promptSouth.setOpaque(false);
        JPanel promptOptions = UiSupport.row(new JLabel("Review:"), reviewType, new JLabel("Framework:"), framework, useKnowledge);
        promptSouth.add(promptOptions);
        JButton explain = new JButton("Explain Code");
        JButton findIssues = new JButton("Find Issues");
        JButton refactor = new JButton("Refactor");
        JButton tests = new JButton("Generate Tests");
        explain.addActionListener(e -> { reviewType.setSelectedItem("General"); promptArea.setText("Explain the selected code clearly, including its responsibilities, data flow, dependencies, and important edge cases."); });
        findIssues.addActionListener(e -> { reviewType.setSelectedItem("Security Review"); promptArea.setText("Review this code for security vulnerabilities, correctness issues, risky patterns, and production-readiness problems. Provide prioritized fixes."); });
        refactor.addActionListener(e -> { reviewType.setSelectedItem("Refactor"); promptArea.setText("Refactor this code for readability, maintainability, testability, and clean design while preserving behavior."); });
        tests.addActionListener(e -> { reviewType.setSelectedItem("Unit Tests"); promptArea.setText("Generate a focused unit-test plan for this code, including important success, failure, boundary, and security cases."); });
        promptSouth.add(UiSupport.row(new JLabel("Quick Actions:"), explain, findIssues, refactor, tests));
        promptCard.add(promptSouth, BorderLayout.SOUTH);
        form.add(promptCard);
        form.add(Box.createVerticalStrut(8));

        JPanel actionsCard = UiSupport.card();
        JPanel actions = new JPanel(new BorderLayout(8, 0));
        actions.setOpaque(false);
        actions.add(sendButton, BorderLayout.CENTER);
        actions.add(status, BorderLayout.SOUTH);
        actionsCard.add(UiSupport.section("3", "Analyze"), BorderLayout.NORTH);
        actionsCard.add(actions, BorderLayout.CENTER);
        form.add(actionsCard);
        form.add(Box.createVerticalStrut(6));
        llmDisabled.setHorizontalAlignment(SwingConstants.CENTER);
        form.add(llmDisabled);

        JTabbedPane resultTabs = new JTabbedPane();
        resultTabs.addTab("AI Response", UiSupport.scroll(responseArea));
        resultTabs.addTab("Findings", UiSupport.scroll(findingsArea));
        resultTabs.addTab("Suggestions", UiSupport.scroll(suggestionsArea));
        resultTabs.addTab("Related Docs", UiSupport.scroll(relatedArea));

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, UiSupport.scroll(form), resultTabs);
        split.setResizeWeight(0.52);
        split.setBorder(BorderFactory.createEmptyBorder());
        add(split, BorderLayout.CENTER);

        sendButton.addActionListener(e -> runAsk());
        refreshLlmState();
    }

    public void setCapabilities(McpCapabilities capabilities) {
        this.capabilities = capabilities;
        useKnowledge.setVisible(capabilities != null && capabilities.knowledge());
    }

    public void refreshLlmState() {
        var s = EngineeringAiSettings.getInstance().getState();
        boolean enabled = s != null && s.llmEnabled;
        sendButton.setEnabled(enabled);
        promptArea.setEnabled(enabled);
        llmDisabled.setVisible(!enabled);
        if (!enabled) status.setText("LLM disabled — use MCP Tools for direct calls.");
        else status.setText("Ready");
    }

    private void runAsk() {
        String prompt = promptArea.getText() == null ? "" : promptArea.getText().trim();
        if (prompt.isBlank()) {
            JOptionPane.showMessageDialog(this, "Enter a prompt first.", "Engineering AI", JOptionPane.WARNING_MESSAGE);
            return;
        }
        sendButton.setEnabled(false);
        status.setText("Collecting local context and analyzing...");
        responseArea.setText("");
        findingsArea.setText("");
        suggestionsArea.setText("");
        relatedArea.setText("");

        SwingWorker<String, Void> worker = new SwingWorker<>() {
            private String sourceDescription;
            @Override
            protected String doInBackground() throws Exception {
                String context = sourceSelector.collectContext();
                sourceDescription = sourceSelector.describeSource();
                String enrichedPrompt = buildPrompt(prompt);
                return orchestrator.ask(enrichedPrompt, context);
            }

            @Override
            protected void done() {
                try {
                    String result = get();
                    responseArea.setText(result);
                    findingsArea.setText(extractLines(result, List.of("issue", "risk", "vulnerab", "finding", "high", "medium", "low")));
                    suggestionsArea.setText(extractLines(result, List.of("recommend", "suggest", "improve", "should", "fix", "use ")));
                    relatedArea.setText(capabilities != null && capabilities.knowledge()
                            ? "MCP Knowledge Base was available to the LLM. Relevant shared docs/tools may have been used automatically.\n\nEnabled MCP sources: " + String.join(", ", capabilities.enabledSources())
                            : "No centralized MCP Knowledge Base was available for this request.");
                    EngineeringAiHistoryService.getInstance().add(new EngineeringAiHistoryService.HistoryEntry(
                            "AI Chat", summarize(prompt), prompt, sourceDescription, result));
                    status.setText("Completed");
                } catch (Exception ex) {
                    responseArea.setText("AI request failed:\n\n" + UiSupport.safe(ex));
                    status.setText("Failed");
                } finally {
                    refreshLlmState();
                }
            }
        };
        worker.execute();
    }

    private String buildPrompt(String prompt) {
        StringBuilder out = new StringBuilder(prompt);
        Object review = reviewType.getSelectedItem();
        Object fw = framework.getSelectedItem();
        out.append("\n\nReview type: ").append(review == null ? "General" : review);
        out.append("\nFramework: ").append(fw == null ? "Auto Detect" : fw);
        if (useKnowledge.isSelected()) out.append("\nUse relevant centralized MCP knowledge and engineering standards when available.");
        return out.toString();
    }

    private static String summarize(String prompt) {
        String p = prompt.replaceAll("\\s+", " ").trim();
        return p.length() > 70 ? p.substring(0, 70) + "…" : p;
    }

    private static String extractLines(String result, List<String> terms) {
        if (result == null || result.isBlank()) return "No structured items detected. See AI Response for the full result.";
        List<String> matches = new ArrayList<>();
        for (String line : result.split("\\R")) {
            String lower = line.toLowerCase();
            for (String term : terms) {
                if (lower.contains(term)) {
                    matches.add(line);
                    break;
                }
            }
        }
        if (matches.isEmpty()) return "No structured items detected. See AI Response for the full result.";
        return String.join("\n", matches);
    }
}
