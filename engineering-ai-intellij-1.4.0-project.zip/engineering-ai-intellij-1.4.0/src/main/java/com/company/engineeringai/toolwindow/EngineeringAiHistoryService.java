package com.company.engineeringai.toolwindow;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.Service;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service(Service.Level.APP)
@State(name = "EngineeringAiHistory", storages = @Storage("engineering-ai-history.xml"))
public final class EngineeringAiHistoryService implements PersistentStateComponent<EngineeringAiHistoryService.StateData> {
    public static final class HistoryEntry {
        public String timestamp = "";
        public String mode = "";
        public String title = "";
        public String prompt = "";
        public String source = "";
        public String result = "";

        public HistoryEntry() {}

        public HistoryEntry(String mode, String title, String prompt, String source, String result) {
            this.timestamp = Instant.now().toString();
            this.mode = mode == null ? "" : mode;
            this.title = title == null ? "" : title;
            this.prompt = prompt == null ? "" : prompt;
            this.source = source == null ? "" : source;
            this.result = result == null ? "" : result;
        }
    }

    public static final class StateData {
        public List<HistoryEntry> entries = new ArrayList<>();
    }

    private StateData state = new StateData();

    public static EngineeringAiHistoryService getInstance() {
        return ApplicationManager.getApplication().getService(EngineeringAiHistoryService.class);
    }

    public synchronized void add(HistoryEntry entry) {
        if (entry == null) return;
        state.entries.add(0, entry);
        while (state.entries.size() > 50) state.entries.remove(state.entries.size() - 1);
    }

    public synchronized List<HistoryEntry> entries() {
        return Collections.unmodifiableList(new ArrayList<>(state.entries));
    }

    public synchronized void clear() {
        state.entries.clear();
    }

    @Override
    public @Nullable StateData getState() {
        return state;
    }

    @Override
    public void loadState(@NotNull StateData state) {
        this.state = state;
        if (this.state.entries == null) this.state.entries = new ArrayList<>();
    }
}
