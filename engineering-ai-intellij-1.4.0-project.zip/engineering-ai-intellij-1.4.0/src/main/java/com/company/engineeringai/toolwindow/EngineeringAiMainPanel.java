package com.company.engineeringai.toolwindow;

import com.company.engineeringai.mcp.McpCapabilities;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.intellij.openapi.options.ShowSettingsUtil;
import com.intellij.openapi.project.Project;

import javax.swing.*;
import java.awt.*;

public final class EngineeringAiMainPanel extends JPanel {
    private final Project project;
    private final JCheckBox llmToggle = new JCheckBox("LLM ON");
    private final JLabel modeLabel = UiSupport.muted("");
    private final IntegrationStatusPanel integrationStatus = new IntegrationStatusPanel();
    private final JTabbedPane tabs = new JTabbedPane();
    private final AiChatPanel aiChatPanel;
    private final McpToolsPanel mcpToolsPanel;
    private final KnowledgeBasePanel knowledgeBasePanel;
    private final HistoryPanel historyPanel = new HistoryPanel();
    private McpCapabilities capabilities = new McpCapabilities(new com.google.gson.JsonArray());
    private int knowledgeTabIndex = -1;

    public EngineeringAiMainPanel(Project project) {
        super(new BorderLayout(0, 8));
        this.project = project;
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        aiChatPanel = new AiChatPanel(project);
        mcpToolsPanel = new McpToolsPanel(project, this::setCapabilities);
        knowledgeBasePanel = new KnowledgeBasePanel(project, this::setCapabilities);

        add(buildHeader(), BorderLayout.NORTH);

        tabs.addTab("AI Chat", aiChatPanel);
        tabs.addTab("MCP Tools", mcpToolsPanel);
        tabs.addTab("Knowledge Base", knowledgeBasePanel);
        knowledgeTabIndex = 2;
        tabs.addTab("History", historyPanel);
        tabs.addChangeListener(e -> {
            if (tabs.getSelectedComponent() == historyPanel) historyPanel.reload();
        });
        add(tabs, BorderLayout.CENTER);

        refreshHeaderFromSettings();
        setCapabilities(capabilities);
    }

    private JComponent buildHeader() {
        JPanel outer = UiSupport.card();
        JPanel top = new JPanel(new BorderLayout(8, 0));
        top.setOpaque(false);
        JPanel title = new JPanel();
        title.setLayout(new BoxLayout(title, BoxLayout.Y_AXIS));
        title.setOpaque(false);
        title.add(UiSupport.title("Engineering AI 1.4.0"));
        title.add(modeLabel);
        top.add(title, BorderLayout.WEST);

        JButton settings = new JButton("Settings");
        settings.addActionListener(e -> ShowSettingsUtil.getInstance().showSettingsDialog(project, "Engineering AI"));
        llmToggle.addActionListener(e -> toggleLlm());
        top.add(UiSupport.row(llmToggle, settings), BorderLayout.EAST);

        outer.add(top, BorderLayout.NORTH);
        outer.add(integrationStatus, BorderLayout.SOUTH);
        return outer;
    }

    private void toggleLlm() {
        var s = EngineeringAiSettings.getInstance().getState();
        if (s == null) return;
        s.llmEnabled = llmToggle.isSelected();
        s.mode = s.llmEnabled ? "AUTO" : "DIRECT_MCP";
        refreshHeaderFromSettings();
        aiChatPanel.refreshLlmState();
        if (s.llmEnabled) tabs.setSelectedComponent(aiChatPanel);
        else tabs.setSelectedComponent(mcpToolsPanel);
    }

    private void refreshHeaderFromSettings() {
        var s = EngineeringAiSettings.getInstance().getState();
        boolean llm = s != null && s.llmEnabled;
        llmToggle.setSelected(llm);
        llmToggle.setText(llm ? "LLM ON" : "LLM OFF");
        String mode = s == null || s.mode == null ? "AUTO" : s.mode;
        modeLabel.setText("Mode: " + mode + (llm ? "  •  Natural-language AI + MCP" : "  •  Direct MCP only"));
    }

    public void setCapabilities(McpCapabilities capabilities) {
        this.capabilities = capabilities == null ? new McpCapabilities(new com.google.gson.JsonArray()) : capabilities;
        integrationStatus.update(this.capabilities);
        aiChatPanel.setCapabilities(this.capabilities);
        knowledgeBasePanel.setCapabilities(this.capabilities);
        updateKnowledgeTabVisibility();
    }

    private void updateKnowledgeTabVisibility() {
        boolean available = capabilities.knowledge();
        int index = indexOfComponent(knowledgeBasePanel);
        if (available && index < 0) {
            int historyIndex = indexOfComponent(historyPanel);
            tabs.insertTab("Knowledge Base", null, knowledgeBasePanel, "Browse shared agents, skills, instructions and docs", Math.max(0, historyIndex));
            knowledgeTabIndex = indexOfComponent(knowledgeBasePanel);
        } else if (!available && index >= 0) {
            if (tabs.getSelectedComponent() == knowledgeBasePanel) tabs.setSelectedComponent(mcpToolsPanel);
            tabs.remove(knowledgeBasePanel);
            knowledgeTabIndex = -1;
        }
    }

    private int indexOfComponent(Component component) {
        for (int i = 0; i < tabs.getTabCount(); i++) if (tabs.getComponentAt(i) == component) return i;
        return -1;
    }
}
