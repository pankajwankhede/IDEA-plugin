package com.company.engineeringai.toolwindow;

import com.company.engineeringai.mcp.McpCapabilities;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public final class IntegrationStatusPanel extends JPanel {
    private final Map<String, JLabel> labels = new LinkedHashMap<>();

    public IntegrationStatusPanel() {
        super(new FlowLayout(FlowLayout.LEFT, 8, 0));
        setOpaque(false);
        add(UiSupport.muted("Available:"));
        for (String name : new String[]{"Knowledge", "Splunk", "New Relic", "PCF", "Oracle", "SQL Server", "Jenkins"}) {
            JLabel label = new JLabel(name);
            label.setVisible(false);
            labels.put(name, label);
            add(label);
        }
        JLabel none = UiSupport.muted("MCP not checked");
        none.setName("none");
        labels.put("__none", none);
        add(none);
    }

    public void update(McpCapabilities capabilities) {
        boolean any = false;
        any |= show("Knowledge", capabilities != null && capabilities.knowledge());
        any |= show("Splunk", capabilities != null && capabilities.splunk());
        any |= show("New Relic", capabilities != null && capabilities.newRelic());
        any |= show("PCF", capabilities != null && capabilities.pcf());
        any |= show("Oracle", capabilities != null && capabilities.oracle());
        any |= show("SQL Server", capabilities != null && capabilities.sqlServer());
        any |= show("Jenkins", capabilities != null && capabilities.jenkins());
        labels.get("__none").setVisible(!any);
        revalidate();
        repaint();
    }

    private boolean show(String name, boolean visible) {
        JLabel label = labels.get(name);
        if (label != null) label.setVisible(visible);
        return visible;
    }
}
