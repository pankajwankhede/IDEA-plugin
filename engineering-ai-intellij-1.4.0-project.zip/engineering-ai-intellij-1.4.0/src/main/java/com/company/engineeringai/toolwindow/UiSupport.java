package com.company.engineeringai.toolwindow;

import com.intellij.ui.JBColor;
import com.intellij.util.ui.JBUI;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

final class UiSupport {
    private UiSupport() {}

    static JPanel card(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBorder(cardBorder());
        panel.setOpaque(true);
        return panel;
    }

    static JPanel card() {
        return card(new BorderLayout(8, 8));
    }

    static Border cardBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(JBColor.border(), 1),
                JBUI.Borders.empty(10)
        );
    }

    static JLabel title(String text) {
        JLabel label = new JLabel(text);
        Font base = label.getFont();
        label.setFont(base.deriveFont(Font.BOLD, base.getSize2D() + 2f));
        return label;
    }

    static JLabel section(String number, String text) {
        JLabel label = new JLabel(number + ".  " + text);
        Font base = label.getFont();
        label.setFont(base.deriveFont(Font.BOLD));
        return label;
    }

    static JLabel muted(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(JBColor.GRAY);
        return label;
    }

    static JScrollPane scroll(Component component) {
        JScrollPane scroll = new JScrollPane(component);
        scroll.setBorder(JBUI.Borders.empty());
        return scroll;
    }

    static JTextArea textArea(int rows, boolean editable) {
        JTextArea area = new JTextArea(rows, 30);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(editable);
        area.setBorder(JBUI.Borders.empty(6));
        return area;
    }

    static JPanel row(Component... components) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        panel.setOpaque(false);
        for (Component c : components) panel.add(c);
        return panel;
    }

    static String safe(Throwable t) {
        if (t == null) return "Unknown error";
        String message = t.getMessage();
        return message == null || message.isBlank() ? t.getClass().getName() : message;
    }
}
