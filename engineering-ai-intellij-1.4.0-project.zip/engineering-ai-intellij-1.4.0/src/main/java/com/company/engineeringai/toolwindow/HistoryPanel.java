package com.company.engineeringai.toolwindow;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import java.awt.*;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public final class HistoryPanel extends JPanel {
    private final DefaultListModel<EngineeringAiHistoryService.HistoryEntry> model = new DefaultListModel<>();
    private final JList<EngineeringAiHistoryService.HistoryEntry> list = new JList<>(model);
    private final JTextArea details = UiSupport.textArea(24, false);
    private final JButton refresh = new JButton("Refresh");
    private final JButton clear = new JButton("Clear History");
    private final JButton copy = new JButton("Copy Result");

    public HistoryPanel() {
        super(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                EngineeringAiHistoryService.HistoryEntry entry = (EngineeringAiHistoryService.HistoryEntry) value;
                String when = entry.timestamp;
                try {
                    when = DateTimeFormatter.ofPattern("MMM d, HH:mm")
                            .withZone(ZoneId.systemDefault())
                            .format(Instant.parse(entry.timestamp));
                } catch (Exception ignored) {}
                return super.getListCellRendererComponent(list, entry.title + "   •   " + entry.mode + "   •   " + when, index, isSelected, cellHasFocus);
            }
        });

        JPanel header = UiSupport.card();
        header.add(UiSupport.title("History"), BorderLayout.WEST);
        header.add(UiSupport.row(refresh, clear), BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        JPanel listCard = UiSupport.card();
        listCard.add(UiSupport.title("Previous prompts and tool runs"), BorderLayout.NORTH);
        listCard.add(UiSupport.scroll(list), BorderLayout.CENTER);

        JPanel detailCard = UiSupport.card();
        detailCard.add(UiSupport.title("Details"), BorderLayout.NORTH);
        detailCard.add(UiSupport.scroll(details), BorderLayout.CENTER);
        detailCard.add(copy, BorderLayout.SOUTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, listCard, detailCard);
        split.setResizeWeight(0.38);
        split.setBorder(BorderFactory.createEmptyBorder());
        add(split, BorderLayout.CENTER);

        refresh.addActionListener(e -> reload());
        clear.addActionListener(e -> {
            EngineeringAiHistoryService.getInstance().clear();
            reload();
        });
        copy.addActionListener(e -> {
            details.selectAll();
            details.copy();
            details.select(0, 0);
        });
        list.addListSelectionListener(this::selectionChanged);
        reload();
    }

    public void reload() {
        model.clear();
        for (EngineeringAiHistoryService.HistoryEntry entry : EngineeringAiHistoryService.getInstance().entries()) model.addElement(entry);
        if (!model.isEmpty()) list.setSelectedIndex(0);
        else details.setText("No history yet. AI Chat, Direct MCP, and Knowledge Base searches will appear here.");
    }

    private void selectionChanged(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        EngineeringAiHistoryService.HistoryEntry entry = list.getSelectedValue();
        if (entry == null) return;
        details.setText("TITLE\n" + entry.title + "\n\nMODE\n" + entry.mode + "\n\nSOURCE\n" + entry.source + "\n\nPROMPT / ARGUMENTS\n" + entry.prompt + "\n\nRESULT\n" + entry.result);
        details.setCaretPosition(0);
    }
}
