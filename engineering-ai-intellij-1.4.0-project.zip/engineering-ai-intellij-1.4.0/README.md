# Engineering AI IntelliJ Plugin 1.4.0

A full IntelliJ IDEA plugin implementation for an internal Engineering AI experience with two operating modes:

- **LLM ON** — natural-language AI Chat with local IDE context and automatic MCP tool use.
- **LLM OFF** — Direct MCP mode with manual tool selection and JSON arguments; no LLM required.

The plugin talks only to your configured **engineering MCP server**. Bitbucket credentials, Splunk credentials, New Relic credentials, database credentials, Jenkins credentials, and integration enable/disable state stay on the MCP server.

## Implemented UI

The 1.4.0 tool window now contains the full discussed design:

### AI Chat

- Header LLM ON/OFF toggle
- Selected Code
- Current File
- Choose File
- Choose Folder
- Natural-language prompt box
- Review type selector
- Framework selector
- Optional centralized MCP Knowledge Base use
- LLM + MCP orchestration
- AI Response / Findings / Suggestions / Related Docs result tabs
- Persistent history entry

### MCP Tools

- Dynamic `initialize -> tools/list`
- Only tools exposed by the MCP server appear
- Tool description from MCP metadata
- JSON argument template generated from `inputSchema`
- Optional Selected Code / Current File / Choose File / Choose Folder context attachment
- Automatic code/context injection only when the selected tool schema exposes a suitable field
- MCP tool result panel
- Better HTTP / protocol errors

### Knowledge Base

Displayed only when knowledge tools are returned by `tools/list`.

- Agents
- Skills
- Instructions
- Scripts
- Shared Docs search
- `list_*` discovery
- `get_*` content loading
- Centralized Bitbucket content remains behind MCP; the plugin does not connect to Bitbucket directly

### History

- AI Chat requests
- Direct MCP calls
- Knowledge Base searches
- Prompt/arguments
- Source context description
- Result
- Persistent last 50 entries

### Dynamic capability visibility

The plugin derives capabilities from authoritative MCP `tools/list`.

Examples:

- knowledge tools -> Knowledge Base shown
- Splunk tools -> Splunk reported as available
- New Relic tools -> New Relic reported as available
- PCF tools -> PCF reported as available
- Oracle / SQL Server tools -> database capability reported as available
- Jenkins tools -> Jenkins reported as available

Unavailable integrations are not added as separate UI features. With a Bitbucket-only MCP server, the plugin remains uncluttered and shows Knowledge only.

## Project requirements

- Java 21
- IntelliJ IDEA 2025.2.5 target
- IntelliJ Platform Gradle Plugin 2.18.1
- Gradle 9.1 wrapper task configuration

## Import

1. Extract the ZIP.
2. Open the project folder in IntelliJ IDEA.
3. Set **Project SDK = Java 21**.
4. Set **Gradle JVM = Java 21**.
5. Let Gradle sync.

For development:

```bat
gradlew.bat clean runIde
```

If you do not have wrapper scripts generated yet, run the `wrapper` Gradle task once from IntelliJ or your installed Gradle.

For installable plugin ZIP:

```bat
gradlew.bat clean buildPlugin
```

Output:

```text
build/distributions/
```

## Current recommended configuration

For a Bitbucket-knowledge-only MCP server and no approved LLM gateway yet:

```text
LLM OFF
Mode: DIRECT_MCP
MCP URL: http://localhost:8080/mcp
```

When an approved enterprise LLM endpoint becomes available, toggle **LLM ON** and configure the gateway in **Settings -> Engineering AI**.

## Security

Do not store Bitbucket tokens, Splunk tokens, New Relic API keys, DB passwords, Jenkins tokens, or other backend credentials in this plugin.

The plugin only needs:

- MCP server URL
- optional LLM gateway URL/model/token-env name

## Reference UI images

See `docs/images/` for the visual designs that guided the 1.4.0 implementation.
