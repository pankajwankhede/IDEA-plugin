# Engineering AI 1.6.0 — React/JCEF implementation

This version replaces the large Swing form UI with a React presentation layer hosted inside IntelliJ's JCEF browser.

## Runtime architecture

```text
IntelliJ Tool Window
  -> JBCefBrowser
     -> bundled React UI (no external CDN)
        -> JBCefJSQuery JSON bridge
           -> Java plugin services
              -> IDE context / selected code / files / folders
              -> MCP initialize / tools/list / tools/call
              -> optional LLM gateway
              -> history and settings
```

## Four complete tabs

1. **AI Chat (LLM)** — source selection, natural language prompt, review/framework/rules options, MCP knowledge toggle, AI results, findings summary, context sidebar and helpful prompts.
2. **MCP Tools** — dynamic tools/list discovery, manual JSON arguments, local source attachment, direct tools/call execution, result and summary panes. Works with LLM OFF.
3. **Knowledge Base** — Agents, Skills, Instructions and Scripts loaded live from the MCP server using list_* and get_* tools; centralized search through search_shared_docs.
4. **History** — persisted AI Chat and Direct MCP runs, source context and integration status.

## Dynamic integrations

The UI derives availability from MCP `tools/list`. Unavailable integrations do not need to be configured on the plugin side. Current Bitbucket-only environments show Knowledge; Splunk/New Relic/PCF/Oracle/SQL Server/Jenkins appear when matching tools are exposed by the MCP server.

## Local source choices

- Selected Code
- Current File
- Choose File
- Choose Folder

The Java bridge reads source content using IntelliJ/project APIs and passes context to the LLM or to an MCP tool only when that tool's inputSchema supports code/context/source/content.

## LLM ON/OFF

- OFF -> DIRECT_MCP, manual MCP execution remains available.
- ON -> AUTO/LLM gateway path. A configured enterprise LLM endpoint is required for AI Chat execution.

## Build

Java 21 and IntelliJ IDEA 2025.2.5 are targeted. The compiled React runtime resources are committed under `src/main/resources/web`, so `buildPlugin` does not require Node.js. Node is only needed when editing `ui/src/App.tsx` and rebuilding `app.js`.

```bash
cd ui
npm install
npm run build
```

Then:

```bash
./gradlew clean runIde
./gradlew clean buildPlugin
```

On Windows use `gradlew.bat` when a wrapper is present, or invoke the configured Gradle distribution from IntelliJ.

## JCEF requirement

Run the sandbox IDE with JetBrains Runtime/JBR that includes JCEF. If JCEF is unavailable, the plugin shows a fallback message instead of failing startup.
