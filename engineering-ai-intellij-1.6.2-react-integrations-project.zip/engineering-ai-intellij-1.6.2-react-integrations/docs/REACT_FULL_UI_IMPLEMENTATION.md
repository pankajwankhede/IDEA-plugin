# React Full UI Implementation — 1.6.0

## Implemented UI parity

The real tool window now uses the same four-page information architecture as the approved reference designs:

- AI Chat (LLM)
- MCP Tools
- Knowledge Base
- History

The layout includes the branded header, LLM toggle, model display, top navigation, code source selector, prompt/review controls, right-side context cards, MCP tool cards, selected-file preview, result summaries, severity badges, Direct MCP workflow, knowledge browser, and integration status.

## Java / React ownership

### React owns
- visual layout and styles
- all four modules
- tabs, cards, badges, panels and result rendering
- local UI state, search/filter controls

### Java owns
- IntelliJ editor/project APIs
- selected/current local source extraction
- file/folder selection
- MCP initialize/tools/list/tools/call
- LLM gateway calls and tool orchestration
- settings and history persistence
- dynamic integration/capability discovery

## Security boundary

The webview never reads the local filesystem directly and does not receive credentials. All privileged operations run on the Java plugin side through a narrow JSON command bridge.

## JCEF fallback

The plugin checks `JBCefApp.isSupported()`. If the IDE is launched with a runtime that does not contain JCEF, a fallback message is shown instead of a broken blank panel.
