# Engineering AI IntelliJ 1.6.1 – Approved Simplified React UI

This revision implements the approved simplified UI and removes the options marked for removal during UI review.

## Modules kept
- AI Chat (LLM)
- MCP Tools (Direct MCP)
- Knowledge Base

History is intentionally removed from the UI.

## Left navigation kept
- AI Chat (LLM)
- Analyze Code
- Explain Code
- Debug & Fix
- Code Review
- Security Scan
- MCP Tools
- Knowledge Base

Removed: Generate Code, Search Docs, Architecture Help, Refactor, Unit Test, Other Tools.

## AI Chat simplification
The right sidebar is removed. Template / Best Practices / Add Context controls are removed. The page keeps source selection, prompt, review options, MCP Knowledge Base checkbox, Send to AI, and the response area.

The remaining left-side engineering actions work as prompt presets and switch to AI Chat.

## MCP Tools simplification
MCP Tools keeps Current File and Choose Folder source options, JSON input, direct `tools/call`, How It Works, source preview, and direct MCP result. Removed extra source options and unrelated left navigation actions.

## Knowledge Base
The approved three-column browser is retained: category tree, item list, and live MCP-backed content detail. `Use in AI Chat` transfers the selected knowledge item into the AI Chat prompt.

## Backend
No MCP-server UI change is required. The plugin continues to use `initialize`, `tools/list`, and `tools/call` dynamically.
