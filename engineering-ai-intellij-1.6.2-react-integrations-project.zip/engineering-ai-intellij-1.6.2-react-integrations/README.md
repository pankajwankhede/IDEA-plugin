# Engineering AI IntelliJ Plugin 1.6.0 — React/JCEF Full UI

This project is the full React/JCEF implementation of the Engineering AI IntelliJ plugin UI discussed in the reference mockups.

## Architecture

```text
IntelliJ IDEA plugin (Java 21)
        |
        +-- JBCefBrowser
        |      |
        |      +-- React UI
        |             +-- AI Chat (LLM)
        |             +-- MCP Tools (LLM OFF / Direct MCP)
        |             +-- Knowledge Base
        |             +-- History
        |
        +-- JBCefJSQuery JSON bridge
               |
               +-- IDE context / selected code / current file
               +-- Choose File / Choose Folder
               +-- MCP initialize / tools/list / tools/call
               +-- optional enterprise LLM gateway
               +-- settings and persistent history
```

The React runtime is bundled into the plugin. It does not load React or JavaScript from an external CDN.

## 1. AI Chat (LLM ON)

Implemented to match the approved design:

- LLM ON/OFF header toggle
- active enterprise model indicator
- left engineering action navigation
- Analyze Code / Explain Code / Generate Code / Debug & Fix
- Code Review / Security Scan / Search Docs / Architecture Help
- Refactor / Unit Test / Other Tools
- Selected Code / Current File / Choose File / Choose Folder
- natural-language prompt box
- review type / framework / rules
- Use MCP Knowledge Base option
- LLM + MCP orchestration
- context card
- automatically available MCP tool card
- selected-files preview
- helpful prompts
- AI Response / Findings / Suggestions / Related Docs presentation
- result/severity summary

AI Chat requires an approved LLM gateway configured under **Settings -> Engineering AI**.

## 2. MCP Tools (LLM OFF / Direct MCP)

- `initialize -> tools/list`
- dynamic MCP tool dropdown
- Refresh MCP Tools
- description from MCP metadata
- Selected Code / Current File / Choose File / Choose Folder
- optional automatic source attachment when the tool `inputSchema` supports `code`, `context`, `source`, or `content`
- JSON argument template generated from `inputSchema`
- direct `tools/call`
- no LLM required
- raw MCP result
- summary / findings / files layout
- errors include useful HTTP/protocol information

## 3. Knowledge Base

The plugin does not connect to Bitbucket directly. Knowledge is obtained through the MCP server.

Supported categories:

- Agents
- Skills
- Instructions
- Scripts
- Shared Docs search

The UI uses MCP tools when available:

```text
list_agents / get_agent
list_skills / get_skill
list_instructions / get_instruction
list_scripts / get_script
search_shared_docs
```

It provides the three-column browser from the mockup: category tree, content list, and content/detail pane.

## 4. History

- AI Chat executions
- Direct MCP executions
- source/context used
- prompt or tool arguments
- result
- persistent recent history
- integration status summary

## Dynamic integration visibility

The plugin uses MCP `tools/list` as the authoritative capability source.

With your current Bitbucket-only MCP configuration you should see **Knowledge** available. Splunk, New Relic, PCF, Oracle, SQL Server and Jenkins remain unavailable/hidden until their MCP tools are enabled server-side.

No separate plugin-side credentials for those backend systems are required.

## Local source support

Source is read on the IntelliJ side:

```text
Selected Code
Current File
Choose File
Choose Folder
```

Folder scanning ignores `.git`, `.idea`, `build`, `target`, `node_modules`, `out`, and `dist` and is limited by plugin settings.

## LLM behavior

```text
LLM OFF -> DIRECT_MCP
LLM ON  -> AUTO / enterprise LLM gateway
```

The LLM client is OpenAI-compatible at the gateway contract level and supports tool calls. If your future corporate gateway uses a different contract, only the LLM adapter should need changing; the React UI and MCP layer remain the same.

## Requirements

- Java 21
- IntelliJ IDEA 2025.2.5 target
- IntelliJ Platform Gradle Plugin 2.18.1
- JBR/JCEF available in the sandbox/runtime

## Import and test

1. Extract the ZIP.
2. Open the project in IntelliJ IDEA.
3. Set **Project SDK = Java 21**.
4. Set **Gradle JVM = Java 21**.
5. Gradle sync.
6. Configure MCP URL under **Settings -> Engineering AI**.
7. Run the `runIde` Gradle task.

For plugin packaging, run `buildPlugin`. The installable plugin ZIP is generated under `build/distributions/`.

## React development

The already-compiled React assets are committed under:

```text
src/main/resources/web/
```

Therefore Java plugin builds do not require Node.js.

If you change the React source:

```bash
cd ui
npm install
npm run build
```

That compiles `ui/src/App.tsx` into the bundled runtime `app.js` and copies the CSS.

## Security

Do not put Bitbucket, Splunk, New Relic, database or Jenkins credentials in the IntelliJ plugin. Those remain on the MCP server. The plugin stores only MCP URL and optional LLM gateway configuration/token environment-variable name.

See `docs/REACT_JCEF_IMPLEMENTATION_1_6.md` and `docs/images/` for implementation/reference details.
