# Engineering AI React UI

`src/App.tsx` is the editable React/TypeScript UI. `npm run build` compiles it to the plugin runtime file at `../src/main/resources/web/app.js`.

The runtime is intentionally self-contained: React and ReactDOM UMD builds are packaged under `src/main/resources/web/vendor/`, so the installed plugin does not load UI libraries from the internet.
