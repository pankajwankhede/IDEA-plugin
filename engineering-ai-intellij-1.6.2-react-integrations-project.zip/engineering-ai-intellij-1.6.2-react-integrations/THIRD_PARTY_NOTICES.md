# Third-party notices

The plugin distribution includes React and ReactDOM runtime files for the embedded JCEF UI. React is distributed under the MIT License. Copyright Meta Platforms, Inc. and affiliates.

Gson is used by the Java plugin for JSON serialization and parsing and is declared as a Gradle dependency.
