plugins {
    java
    id("org.jetbrains.intellij.platform") version "2.18.1"
}

group = "com.company.engineeringai"
version = "1.6.2"

repositories {
    mavenCentral()
    intellijPlatform {
        defaultRepositories()
    }
}

dependencies {
    implementation("com.google.code.gson:gson:2.13.2")

    intellijPlatform {
        intellijIdeaCommunity("2025.2.5")
    }
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(21))
    }
}

intellijPlatform {
    pluginConfiguration {
        id = "com.company.engineeringai"
        name = "Engineering AI"
        version = project.version.toString()
        description = "Engineering AI for IntelliJ with a React/JCEF UI: AI Chat, Direct MCP, Knowledge Base, local source selection, dynamic MCP capability visibility, and centralized knowledge through an external MCP server."
        vendor {
            name = "Internal Engineering"
        }
        ideaVersion {
            sinceBuild = "252"
        }
    }
}

tasks {
    wrapper {
        gradleVersion = "9.1.0"
        distributionType = Wrapper.DistributionType.BIN
    }
}
