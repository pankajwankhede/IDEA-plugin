function Badge(props) { return React.createElement("span", { className: 'badge ' + (props.kind || '') }, props.children); }
function Step(props) { return React.createElement("div", { className: "section-title" },
    React.createElement("span", { className: 'step ' + (props.tone || 'blue') }, props.n),
    React.createElement("div", null,
        React.createElement("b", null, props.title),
        props.sub && React.createElement("span", { className: "sub" }, props.sub))); }
function Empty(props) { return React.createElement("div", { className: "empty" },
    React.createElement("div", { className: "empty-icon" }, "\u2726"),
    React.createElement("b", null, props.title),
    React.createElement("span", null, props.text)); }
function Spinner() { return React.createElement("div", { className: "spinner" }); }
class App extends React.Component {
    constructor() {
        super(...arguments);
        this.state = {
            boot: null, tab: 'ai', busy: false, error: '',
            sourceScope: 'CURRENT_FILE', sourceDisplay: '', sourceFiles: [], sourceContext: '',
            prompt: 'Review this Java code for security vulnerabilities and suggest best practices for Spring Boot. Also check for any OWASP Top 10 issues and give improvement suggestions.',
            reviewType: 'Security', framework: 'Spring Boot', rules: 'OWASP Top 10', useKnowledge: true, aiResult: null, activeAction: 'Code Review',
            selectedTool: '', toolArgs: '{}', mcpResult: null, integrationFilter: 'All',
            knowledgeCategory: 'skills', knowledge: { agents: [], skills: [], instructions: [], scripts: [] }, knowledgeRaw: {}, selectedKnowledge: null, knowledgeSearch: ''
        };
    }
    componentDidMount() { this.bootstrap(); }
    bridge(action, payload = {}) { return window.intellijBridge.request({ action, payload }); }
    async withBusy(fn) { this.setState({ busy: true, error: '' }); try {
        return await fn();
    }
    catch (e) {
        this.setState({ error: e.message || String(e) });
    }
    finally {
        this.setState({ busy: false });
    } }
    async bootstrap() {
        this.setState({ busy: true, error: '' });
        try {
            const boot = await this.bridge('bootstrap');
            const tools = (boot.mcp && boot.mcp.tools) || [];
            const first = tools[0] || null;
            this.setState({ boot, selectedTool: first ? first.name : '', toolArgs: first ? JSON.stringify(this.templateFor(first), null, 2) : '{}', sourceDisplay: boot.project.activeFilePath || '', busy: false }, async () => {
                if (boot.project.activeFilePath) {
                    try {
                        await this.selectSource('CURRENT_FILE');
                    }
                    catch (_) { }
                }
                if (boot.mcp && boot.mcp.capabilities && boot.mcp.capabilities.knowledge)
                    this.loadKnowledge('skills');
            });
        }
        catch (e) {
            this.setState({ busy: false, error: e.message || String(e) });
        }
    }
    tools() { return (this.state.boot && this.state.boot.mcp && this.state.boot.mcp.tools) || []; }
    detectIntegration(tool) {
        const n = ((tool && tool.name) || '').toLowerCase(), d = ((tool && tool.description) || '').toLowerCase(), x = n + ' ' + d;
        if (/splunk|search_logs|get_service_logs|get_error_summary|get_index_info/.test(x))
            return 'Splunk';
        if (/new[_ -]?relic|application_health|transactions|get_metrics|get_errors/.test(x))
            return 'New Relic';
        if (/\bpcf\b|cloud foundry|get_app_status|get_instances|get_recent_events|get_env_summary/.test(x))
            return 'PCF';
        if (/oracle/.test(x))
            return 'Oracle';
        if (/sql[_ -]?server|mssql/.test(x))
            return 'SQL Server';
        if (/jenkins|get_job_status|get_last_build|get_build_log|get_pipeline_status/.test(x))
            return 'Jenkins';
        if (/bitbucket|repository|pull_request|branch|shared_docs|get_prompt|get_service_context|agent|skill|instruction|script/.test(x))
            return 'Bitbucket';
        return 'Other';
    }
    integrationGroups() { const out = {}; this.tools().forEach((t) => { const k = this.detectIntegration(t); (out[k] || (out[k] = [])).push(t); }); return out; }
    visibleTools() { const f = this.state.integrationFilter; return f === 'All' ? this.tools() : this.tools().filter((t) => this.detectIntegration(t) === f); }
    enabledIntegrationNames() { const order = ['Bitbucket', 'Splunk', 'PCF', 'New Relic', 'Oracle', 'SQL Server', 'Jenkins', 'Other']; const g = this.integrationGroups(); return order.filter(x => (g[x] || []).length > 0); }
    selectedToolObj() { return this.tools().find((x) => x.name === this.state.selectedTool); }
    templateFor(tool) { const out = {}; const props = tool && tool.inputSchema && tool.inputSchema.properties || {}; Object.keys(props).forEach(k => { const t = props[k] && props[k].type || 'string'; out[k] = t === 'boolean' ? false : (t === 'integer' || t === 'number') ? 0 : t === 'array' ? [] : t === 'object' ? {} : ''; }); return out; }
    changeTool(name) { const t = this.tools().find((x) => x.name === name); this.setState({ selectedTool: name, toolArgs: JSON.stringify(this.templateFor(t), null, 2), mcpResult: null }); }
    changeIntegration(name) { const list = name === 'All' ? this.tools() : this.tools().filter((t) => this.detectIntegration(t) === name); const t = list[0]; this.setState({ integrationFilter: name, selectedTool: t ? t.name : '', toolArgs: t ? JSON.stringify(this.templateFor(t), null, 2) : '{}', mcpResult: null }); }
    async refreshTools() { await this.withBusy(async () => { const mcp = await this.bridge('refreshTools'); const boot = { ...this.state.boot, mcp }; const first = mcp.tools && mcp.tools[0]; this.setState({ boot, selectedTool: first ? first.name : '', toolArgs: first ? JSON.stringify(this.templateFor(first), null, 2) : '{}' }); }); }
    async toggleLlm() { await this.withBusy(async () => { const s = await this.bridge('toggleLlm', { enabled: !this.state.boot.settings.llmEnabled }); this.setState({ boot: { ...this.state.boot, settings: s } }); }); }
    async selectSource(scope) { await this.withBusy(async () => { const d = await this.bridge('selectSource', { scope }); this.setState({ sourceScope: scope, sourceDisplay: d.display || '', sourceFiles: d.files || [], sourceContext: d.context || '' }); }); }
    async askAi() { await this.withBusy(async () => { const r = await this.bridge('aiAsk', { prompt: this.state.prompt, scope: this.state.sourceScope, reviewType: this.state.reviewType, framework: this.state.framework, rules: this.state.rules, useKnowledge: this.state.useKnowledge }); this.setState({ aiResult: r }); }); }
    async runMcp() { await this.withBusy(async () => { let args = {}; try {
        args = JSON.parse(this.state.toolArgs || '{}');
    }
    catch (_) {
        throw new Error('MCP Input must be valid JSON.');
    } const r = await this.bridge('runMcpTool', { name: this.state.selectedTool, arguments: args, attachSource: true }); this.setState({ mcpResult: r }); }); }
    async loadKnowledge(category) { this.setState({ knowledgeCategory: category }); if (this.state.knowledge[category] && this.state.knowledge[category].length)
        return; await this.withBusy(async () => { const d = await this.bridge('knowledgeList', { category }); this.setState({ knowledge: { ...this.state.knowledge, [category]: d.items || [] }, knowledgeRaw: { ...this.state.knowledgeRaw, [category]: d.raw || '' } }); }); }
    async openKnowledge(category, name) { await this.withBusy(async () => { const d = await this.bridge('knowledgeGet', { category, name }); this.setState({ selectedKnowledge: d }); }); }
    async searchKnowledge() { if (!this.state.knowledgeSearch.trim())
        return; await this.withBusy(async () => { const d = await this.bridge('knowledgeSearch', { query: this.state.knowledgeSearch }); this.setState({ selectedKnowledge: { category: 'search', name: 'Search Results', content: d.content } }); }); }
    preset(action) {
        const p = {
            'Analyze Code': { prompt: 'Analyze this code and identify correctness, maintainability, security, and quality issues.', reviewType: 'Code Quality' },
            'Explain Code': { prompt: 'Explain this code clearly, including its flow, dependencies, important decisions, and possible risks.', reviewType: 'Code Quality' },
            'Debug & Fix': { prompt: 'Find likely bugs in this code, explain the root cause, and suggest a safe fix.', reviewType: 'Code Quality' },
            'Code Review': { prompt: 'Review this code for security vulnerabilities, code quality, maintainability, and best practices.', reviewType: 'Code Quality' },
            'Security Scan': { prompt: 'Review this code for security vulnerabilities. Check OWASP Top 10 risks and recommend remediations.', reviewType: 'Security' }
        };
        const x = p[action] || p['Code Review'];
        this.setState({ tab: 'ai', activeAction: action, prompt: x.prompt, reviewType: x.reviewType });
    }
    nav() {
        return React.createElement("aside", { className: "final-nav" },
            React.createElement("div", { className: "nav-brand" }, "\u2726"),
            React.createElement("button", { className: this.state.tab === 'ai' ? 'active' : '', onClick: () => this.setState({ tab: 'ai' }) },
                "\u25A3 ",
                React.createElement("span", null, "AI Chat (LLM)")),
            ['Analyze Code', 'Explain Code', 'Debug & Fix', 'Code Review', 'Security Scan'].map(x => React.createElement("button", { key: x, className: this.state.tab === 'ai' && this.state.activeAction === x ? 'active-soft' : '', onClick: () => this.preset(x) },
                this.actionIcon(x),
                " ",
                React.createElement("span", null, x))),
            React.createElement("div", { className: "nav-separator" }),
            React.createElement("button", { className: this.state.tab === 'mcp' ? 'active' : '', onClick: () => this.setState({ tab: 'mcp' }) },
                "\u2318 ",
                React.createElement("span", null, "MCP Tools")),
            React.createElement("button", { className: this.state.tab === 'kb' ? 'active' : '', onClick: () => this.setState({ tab: 'kb' }) },
                "\u25A4 ",
                React.createElement("span", null, "Knowledge Base")),
            React.createElement("div", { className: "nav-spacer" }),
            React.createElement("small", null,
                React.createElement("i", { className: "connected-dot" }),
                " Plugin Connected"),
            React.createElement("small", null, "v1.6.1"));
    }
    render() { const b = this.state.boot; if (!b)
        return React.createElement("div", { className: "boot-screen" },
            React.createElement(Spinner, null),
            React.createElement("b", null, "Loading Engineering AI\u2026"),
            this.state.error && React.createElement("span", { className: "error-text" }, this.state.error)); return React.createElement("div", { className: "app-shell final-shell" },
        this.renderHeader(),
        React.createElement("div", { className: "workspace" },
            this.nav(),
            React.createElement("div", { className: "workspace-body" },
                React.createElement("nav", { className: "top-tabs final-tabs" },
                    React.createElement("button", { className: this.state.tab === 'ai' ? 'active' : '', onClick: () => this.setState({ tab: 'ai' }) }, "AI Chat (LLM)"),
                    React.createElement("button", { className: this.state.tab === 'mcp' ? 'active' : '', onClick: () => this.setState({ tab: 'mcp' }) }, "MCP Tools"),
                    React.createElement("button", { className: this.state.tab === 'kb' ? 'active' : '', onClick: () => this.setState({ tab: 'kb' }) }, "Knowledge Base")),
                this.state.error && React.createElement("div", { className: "error-banner" },
                    React.createElement("b", null, "\u26A0"),
                    React.createElement("span", null, this.state.error),
                    React.createElement("button", { onClick: () => this.setState({ error: '' }) }, "\u00D7")),
                React.createElement("main", { className: "main-area" }, this.state.tab === 'ai' ? this.renderAi() : this.state.tab === 'mcp' ? this.renderMcp() : this.renderKnowledge()))),
        this.state.busy && React.createElement("div", { className: "busy-overlay" },
            React.createElement(Spinner, null),
            React.createElement("span", null, "Working\u2026"))); }
    renderHeader() { const s = this.state.boot.settings; return React.createElement("header", { className: "app-header final-header" },
        React.createElement("div", { className: "brand" },
            React.createElement("div", { className: "spark" }, "\u2726"),
            React.createElement("div", null,
                React.createElement("h1", null, "Engineering AI"),
                React.createElement("p", null, "Your AI assistant for secure, high-quality, production-ready code"))),
        React.createElement("div", { className: "header-actions" },
            React.createElement("button", { className: 'toggle ' + (s.llmEnabled ? 'on' : 'off'), onClick: () => this.toggleLlm() },
                React.createElement("span", null,
                    "LLM: ",
                    s.llmEnabled ? 'ON' : 'OFF'),
                React.createElement("i", null)),
            React.createElement("div", { className: "model-pill" },
                "Using: ",
                React.createElement("b", null, s.llmModel || 'Corporate LLM Gateway'),
                React.createElement("span", null, "\u2304")),
            React.createElement("button", { className: "icon-btn", onClick: () => this.bridge('openSettings') }, "\u2699"),
            React.createElement("button", { className: "icon-btn" }, "?"))); }
    sourceButtonsAi() { return React.createElement("div", { className: "source-buttons" },
        React.createElement("button", { className: this.state.sourceScope === 'SELECTED_CODE' ? 'active' : '', onClick: () => this.selectSource('SELECTED_CODE') }, "\u2317 Selected Code"),
        React.createElement("button", { className: this.state.sourceScope === 'CURRENT_FILE' ? 'active' : '', onClick: () => this.selectSource('CURRENT_FILE') }, "\u25A7 Current File"),
        React.createElement("button", { className: this.state.sourceScope === 'CHOOSE_FILE' ? 'active' : '', onClick: () => this.selectSource('CHOOSE_FILE') }, "\u25A7 Choose File\u2026"),
        React.createElement("button", { className: this.state.sourceScope === 'CHOOSE_FOLDER' ? 'active' : '', onClick: () => this.selectSource('CHOOSE_FOLDER') }, "\u25B1 Choose Folder\u2026")); }
    sourceButtonsMcp() { return React.createElement("div", { className: "source-buttons two" },
        React.createElement("button", { className: this.state.sourceScope === 'CURRENT_FILE' ? 'active' : '', onClick: () => this.selectSource('CURRENT_FILE') }, "\u25A7 Current File"),
        React.createElement("button", { className: this.state.sourceScope === 'CHOOSE_FOLDER' ? 'active' : '', onClick: () => this.selectSource('CHOOSE_FOLDER') }, "\u25B1 Choose Folder")); }
    renderAi() { const s = this.state.boot.settings; return React.createElement("div", { className: "final-page ai-simple" },
        React.createElement("section", { className: "panel ai-main-panel" },
            React.createElement("div", { className: "simple-heading" },
                React.createElement("h2", null, "AI Chat (LLM)"),
                React.createElement("p", null, "Ask questions, review code, or get help using your engineering knowledge base")),
            React.createElement(Step, { n: "1", title: "Source Selection", sub: "(What code do you want to analyze?)", tone: "blue" }),
            this.sourceButtonsAi(),
            React.createElement("div", { className: "path-field" },
                React.createElement("span", null, "\u25A7"),
                React.createElement("span", { className: "path-text" }, this.state.sourceDisplay || this.state.boot.project.activeFilePath || 'No source selected'),
                React.createElement("button", { onClick: () => this.selectSource('CHOOSE_FILE') }, "\u25B1")),
            React.createElement(Step, { n: "2", title: "Your Prompt", sub: "(Natural language)", tone: "green" }),
            React.createElement("div", { className: "prompt-wrap" },
                React.createElement("textarea", { maxLength: 4000, value: this.state.prompt, onChange: (e) => this.setState({ prompt: e.target.value }) }),
                React.createElement("span", { className: "counter" },
                    this.state.prompt.length,
                    "/4000")),
            React.createElement(Step, { n: "3", title: "Advanced Options", sub: "(Optional)", tone: "yellow" }),
            React.createElement("div", { className: "options-row simple-options" },
                React.createElement("label", null,
                    "Review Type",
                    React.createElement("select", { value: this.state.reviewType, onChange: (e) => this.setState({ reviewType: e.target.value }) },
                        React.createElement("option", null, "Security"),
                        React.createElement("option", null, "Code Quality"),
                        React.createElement("option", null, "Performance"),
                        React.createElement("option", null, "Architecture"))),
                React.createElement("label", null,
                    "Framework",
                    React.createElement("select", { value: this.state.framework, onChange: (e) => this.setState({ framework: e.target.value }) },
                        React.createElement("option", null, "Spring Boot"),
                        React.createElement("option", null, "Java"),
                        React.createElement("option", null, "Generic"))),
                React.createElement("label", null,
                    "Include Rules",
                    React.createElement("select", { value: this.state.rules, onChange: (e) => this.setState({ rules: e.target.value }) },
                        React.createElement("option", null, "OWASP Top 10"),
                        React.createElement("option", null, "Company Standards"),
                        React.createElement("option", null, "Best Practices"))),
                React.createElement("label", { className: "check-label" },
                    React.createElement("input", { type: "checkbox", checked: this.state.useKnowledge, onChange: (e) => this.setState({ useKnowledge: e.target.checked }) }),
                    " Use MCP Knowledge Base")),
            React.createElement("button", { className: "primary", disabled: !s.llmEnabled, onClick: () => this.askAi() }, "\u27A4 Send to AI (LLM + MCP)")),
        this.renderAiResult()); }
    summaryCards(s) { return React.createElement("div", { className: "summary-cards" },
        React.createElement("div", { className: "summary-card total" },
            React.createElement("b", null, s.total || 0),
            React.createElement("small", null, "Total Issues")),
        React.createElement("div", { className: "summary-card high" },
            React.createElement("b", null,
                "! ",
                s.high || 0),
            React.createElement("small", null, "High")),
        React.createElement("div", { className: "summary-card medium" },
            React.createElement("b", null,
                "\u26A0 ",
                s.medium || 0),
            React.createElement("small", null, "Medium")),
        React.createElement("div", { className: "summary-card low" },
            React.createElement("b", null,
                "i ",
                s.low || 0),
            React.createElement("small", null, "Low"))); }
    renderAiResult() { const r = this.state.aiResult; if (!r)
        return React.createElement("div", { className: "panel result-panel ai-empty" },
            React.createElement("div", { className: "result-tabs" },
                React.createElement("b", null, "AI Response"),
                React.createElement("span", null, "Findings"),
                React.createElement("span", null, "Suggestions"),
                React.createElement("span", null, "Related Docs")),
            React.createElement(Empty, { title: "Ready for AI review", text: "Select a source, enter your prompt, then send it to your configured LLM gateway." })); const s = r.summary || {}; return React.createElement("div", { className: "panel result-panel" },
        React.createElement("div", { className: "result-tabs" },
            React.createElement("b", null, "AI Response"),
            React.createElement("span", null,
                "Findings (",
                s.total || 0,
                ")"),
            React.createElement("span", null, "Suggestions"),
            React.createElement("span", null, "Related Docs"),
            React.createElement("em", null,
                "\u25CF Completed in ",
                (r.elapsedMs / 1000).toFixed(1),
                "s")),
        React.createElement("div", { className: "result-content" },
            React.createElement("div", { className: "result-title" },
                "</> ",
                React.createElement("span", null, "Security Code Review Results")),
            React.createElement("p", { className: "muted" }, "Response from your configured LLM using the selected IDE source and MCP knowledge settings."),
            this.summaryCards(s),
            React.createElement("pre", { className: "markdown-view ai-response-text" }, r.text))); }
    renderMcp() { const tool = this.selectedToolObj(); const integration = tool ? this.detectIntegration(tool) : 'Other'; const enabled = this.enabledIntegrationNames(); return React.createElement("div", { className: "final-page mcp-final" },
        React.createElement("section", { className: "mcp-main" },
            React.createElement("div", { className: "panel mcp-form" },
                React.createElement(Step, { n: "1", title: "Select MCP Tool", tone: "purple" }),
                React.createElement("div", { className: "integration-chips" },
                    React.createElement("button", { className: this.state.integrationFilter === 'All' ? 'active' : '', onClick: () => this.changeIntegration('All') },
                        "All (",
                        this.tools().length,
                        ")"),
                    enabled.map((x) => React.createElement("button", { key: x, className: this.state.integrationFilter === x ? 'active' : '', onClick: () => this.changeIntegration(x) },
                        x,
                        " (",
                        (this.integrationGroups()[x] || []).length,
                        ")"))),
                React.createElement("div", { className: "tool-row" },
                    React.createElement("select", { value: this.state.selectedTool, onChange: (e) => this.changeTool(e.target.value) }, this.visibleTools().map((t) => React.createElement("option", { key: t.name, value: t.name }, t.name))),
                    React.createElement("button", { className: "secondary", onClick: () => this.refreshTools() }, "\u21BB Refresh Tools")),
                React.createElement("div", { className: "description-box" },
                    React.createElement("div", null,
                        React.createElement(Badge, { kind: "source" }, integration),
                        React.createElement("span", null, tool && tool.description || 'MCP tools are discovered dynamically from tools/list.'))),
                React.createElement(Step, { n: "2", title: "Select Source", tone: "green" }),
                this.sourceButtonsMcp(),
                React.createElement("div", { className: "path-field" },
                    React.createElement("span", null, "\u25A7"),
                    React.createElement("span", { className: "path-text" }, this.state.sourceDisplay || this.state.boot.project.activeFilePath || 'No source selected'),
                    React.createElement("button", { onClick: () => this.selectSource('CHOOSE_FOLDER') }, "\u25B1")),
                React.createElement(Step, { n: "3", title: "Input (JSON)", tone: "yellow" }),
                React.createElement("textarea", { className: "json-editor final-json", value: this.state.toolArgs, onChange: (e) => this.setState({ toolArgs: e.target.value }) }),
                React.createElement("button", { className: "primary", onClick: () => this.runMcp() }, "\u25B6 Run MCP Tool")),
            this.renderMcpResult()),
        React.createElement("aside", { className: "mcp-preview" },
            React.createElement("div", { className: "side-card how" },
                React.createElement("h3", null, "\uD83D\uDCA1 How it works"),
                ['Select the MCP tool you want to use', 'Choose a source (file or folder)', 'Provide input configuration (JSON)', 'Click Run MCP Tool', 'View the result on screen'].map((x, i) => React.createElement("div", { key: x },
                    React.createElement("span", { className: 'num n' + (i + 1) }, i + 1),
                    x))),
            React.createElement("div", { className: "side-card enabled-integrations" },
                React.createElement("h3", null, "Connected MCP Sources"),
                enabled.map((x) => React.createElement("div", { className: "integration-row2", key: x },
                    React.createElement("span", { className: "integration-ok" }, "\u2713"),
                    React.createElement("b", null, x),
                    React.createElement("small", null,
                        (this.integrationGroups()[x] || []).length,
                        " tools")))),
            React.createElement("div", { className: "side-card preview-card" },
                React.createElement("h3", null, "\u25A7 Selected File Preview"),
                React.createElement("b", null, this.state.sourceDisplay ? this.basename(this.state.sourceDisplay) : this.state.boot.project.activeFile),
                React.createElement("small", null, this.state.sourceDisplay || this.state.boot.project.activeFilePath),
                React.createElement("pre", { className: "code-preview" }, this.previewText())))); }
    renderMcpResult() { const r = this.state.mcpResult; if (!r)
        return React.createElement("div", { className: "panel result-panel compact" },
            React.createElement("div", { className: "result-tabs" },
                React.createElement("b", null, "MCP Tool Result")),
            React.createElement(Empty, { title: "No MCP result yet", text: "Enable an integration on the MCP server, select one of its discovered tools, and run it directly. No LLM is required." })); const s = r.summary || {}, tool = this.selectedToolObj(), integration = tool ? this.detectIntegration(tool) : 'MCP'; return React.createElement("div", { className: "panel result-panel compact" },
        React.createElement("div", { className: "result-tabs" },
            React.createElement("b", null,
                integration,
                " Result"),
            React.createElement("span", null,
                "Tool: ",
                this.state.selectedTool),
            React.createElement("em", null,
                "\u25CF Completed in ",
                (r.elapsedMs / 1000).toFixed(1),
                "s")),
        React.createElement("div", { className: "integration-result-head" },
            React.createElement(Badge, { kind: "source" }, integration),
            React.createElement("span", null, "Result returned live from the enabled MCP integration.")),
        React.createElement("div", { className: "mcp-final-result" },
            this.shouldShowSeverity(integration, s) && this.summaryCards(s),
            React.createElement("pre", { className: "raw-result" }, r.text))); }
    shouldShowSeverity(integration, s) { return (s.total || 0) > 0 && !['Oracle', 'SQL Server'].includes(integration); }
    renderKnowledge() { const cat = this.state.knowledgeCategory, items = this.state.knowledge[cat] || [], sel = this.state.selectedKnowledge; return React.createElement("div", { className: "kb-page final-kb" },
        React.createElement("aside", { className: "kb-tree panel" },
            React.createElement("h2", null, "\u25A4 Knowledge Base"),
            React.createElement("p", null, "Browse and explore shared engineering knowledge from the internal repository"),
            React.createElement("div", { className: "search-box" },
                React.createElement("input", { placeholder: "Search agents, skills, docs\u2026", value: this.state.knowledgeSearch, onChange: (e) => this.setState({ knowledgeSearch: e.target.value }), onKeyDown: (e) => e.key === 'Enter' && this.searchKnowledge() }),
                React.createElement("button", { onClick: () => this.searchKnowledge() }, "\u2315")),
            React.createElement("div", { className: "tree-root" }, "\u25A3 All Content"),
            ['agents', 'skills', 'instructions', 'scripts'].map(c => React.createElement("div", { key: c },
                React.createElement("button", { className: 'tree-category ' + (cat === c ? 'active' : ''), onClick: () => this.loadKnowledge(c) },
                    React.createElement("span", null, c === 'agents' ? '🤖' : c === 'skills' ? '🔧' : c === 'instructions' ? '📄' : '⌘'),
                    this.cap(c),
                    " ",
                    React.createElement("small", null,
                        "(",
                        (this.state.knowledge[c] || []).length,
                        ")")),
                cat === c && (this.state.knowledge[c] || []).slice(0, 14).map((x) => React.createElement("button", { className: 'tree-child ' + (sel && sel.name === x.name ? 'active' : ''), onClick: () => this.openKnowledge(c, x.name), key: x.name },
                    "\u25A7 ",
                    x.name))))),
        React.createElement("section", { className: "kb-list panel" },
            React.createElement("div", { className: "kb-list-title" },
                React.createElement("div", { className: "big-icon" }, "\uD83D\uDD27"),
                React.createElement("div", null,
                    React.createElement("h2", null, this.cap(cat)),
                    React.createElement("p", null,
                        "Reusable ",
                        cat,
                        " and guidelines for common engineering tasks"))),
            React.createElement("div", { className: "filters" },
                React.createElement("button", null, "All Categories\u2304"),
                React.createElement("button", null, "All Tags\u2304"),
                React.createElement("button", null, "Sort: Name (A-Z)\u2304")),
            items.length ? items.map((x, i) => React.createElement("button", { className: 'knowledge-card ' + (sel && sel.name === x.name ? 'active' : ''), onClick: () => this.openKnowledge(cat, x.name), key: x.name },
                React.createElement("div", { className: 'knowledge-icon k' + (i % 5) }, cat === 'skills' ? '&lt;/&gt;' : cat === 'agents' ? 'AI' : cat === 'instructions' ? 'i' : '$'),
                React.createElement("div", { className: "knowledge-main" },
                    React.createElement("div", null,
                        React.createElement("b", null, x.name),
                        React.createElement("span", null, x.version || 'v1.0')),
                    React.createElement("p", null, x.description),
                    React.createElement("div", null, (x.tags || []).slice(0, 4).map((t) => React.createElement(Badge, { key: t }, t)))))) : React.createElement(Empty, { title: 'No ' + cat + ' loaded', text: this.state.knowledgeRaw[cat] || 'This list depends on the matching list_* MCP tool being exposed by the server.' })),
        React.createElement("section", { className: "kb-detail panel" }, sel ? React.createElement(React.Fragment, null,
            React.createElement("div", { className: "detail-head" },
                React.createElement("div", { className: "big-icon" }, "</>"),
                React.createElement("div", null,
                    React.createElement("h2", null, sel.name),
                    React.createElement("p", null, "Guidelines and shared engineering knowledge")),
                React.createElement(Badge, null, "v1.0")),
            React.createElement("div", { className: "tag-line" },
                React.createElement(Badge, null, "code-quality"),
                React.createElement(Badge, null, "review"),
                React.createElement(Badge, null, "best-practices")),
            React.createElement("div", { className: "meta-row" },
                React.createElement("span", null,
                    React.createElement("small", null, "Type"),
                    React.createElement("b", null, this.cap(sel.category || cat).replace(/s$/, ''))),
                React.createElement("span", null,
                    React.createElement("small", null, "Owner"),
                    React.createElement("b", null, "Engineering Excellence")),
                React.createElement("span", null,
                    React.createElement("small", null, "Source"),
                    React.createElement("b", null, "MCP Knowledge"))),
            React.createElement("div", { className: "detail-tabs" },
                React.createElement("b", null, "Content"),
                React.createElement("span", null, "Examples"),
                React.createElement("span", null, "Related"),
                React.createElement("span", null, "Versions")),
            React.createElement("pre", { className: "markdown-view" }, sel.content),
            React.createElement("button", { className: "primary kb-use", onClick: () => this.useKnowledgeInChat(sel) }, "\u27A4 Use in AI Chat")) : React.createElement(Empty, { title: "Select a knowledge item", text: "Choose an Agent, Skill, Instruction or Script. Content is loaded live through the MCP server." }))); }
    useKnowledgeInChat(sel) { const context = 'Use this engineering knowledge as context: ' + sel.name + '\n\n' + (sel.content || ''); this.setState({ tab: 'ai', prompt: context.slice(0, 4000), useKnowledge: true }); }
    previewText() { const c = this.state.sourceContext || ''; if (c)
        return c.length > 5000 ? c.slice(0, 5000) + '\n…' : c; const files = this.state.sourceFiles || []; if (files.length)
        return files.slice(0, 30).map((f) => f.path || f.name).join('\n'); return 'Select Current File or Choose Folder to preview source.'; }
    basename(p) { return (p || '').replace(/\\/g, '/').split('/').pop() || p; }
    actionIcon(x) { return x === 'Analyze Code' ? '⌁' : x === 'Explain Code' ? '▧' : x === 'Debug & Fix' ? '⚙' : x === 'Code Review' ? '◉' : '⬟'; }
    cap(x) { return x.charAt(0).toUpperCase() + x.slice(1); }
}
ReactDOM.render(React.createElement(App, null), document.getElementById('root'));
