package com.company.engineeringai.web;

import com.company.engineeringai.context.IdeContextProvider;
import com.company.engineeringai.mcp.McpCapabilities;
import com.company.engineeringai.mcp.McpClient;
import com.company.engineeringai.orchestrator.AiOrchestrator;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.company.engineeringai.toolwindow.EngineeringAiHistoryService;
import com.google.gson.*;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.options.ShowSettingsUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;

import javax.swing.*;
import java.io.File;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.stream.Stream;

/** JSON bridge exposed to the React webview through JBCefJSQuery. */
public final class EngineeringAiBridge {
    private final Project project;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final McpClient mcp = new McpClient();
    private final AiOrchestrator orchestrator = new AiOrchestrator();
    private JsonArray cachedTools = new JsonArray();
    private String chosenPath = "";
    private String chosenScope = "CURRENT_FILE";

    public EngineeringAiBridge(Project project) {
        this.project = project;
    }

    public String handle(String raw) {
        try {
            JsonObject request = JsonParser.parseString(raw == null ? "{}" : raw).getAsJsonObject();
            String action = str(request, "action", "bootstrap");
            JsonObject payload = request.has("payload") && request.get("payload").isJsonObject()
                    ? request.getAsJsonObject("payload") : new JsonObject();
            JsonElement data = switch (action) {
                case "bootstrap" -> bootstrap();
                case "refreshTools" -> refreshTools();
                case "toggleLlm" -> toggleLlm(payload);
                case "setMode" -> setMode(payload);
                case "openSettings" -> openSettings();
                case "selectSource" -> selectSource(payload);
                case "runMcpTool" -> runMcpTool(payload);
                case "aiAsk" -> aiAsk(payload);
                case "knowledgeList" -> knowledgeList(payload);
                case "knowledgeGet" -> knowledgeGet(payload);
                case "knowledgeSearch" -> knowledgeSearch(payload);
                case "getHistory" -> historyJson();
                case "clearHistory" -> clearHistory();
                default -> throw new IllegalArgumentException("Unknown bridge action: " + action);
            };
            JsonObject response = new JsonObject();
            response.addProperty("ok", true);
            response.add("data", data == null ? JsonNull.INSTANCE : data);
            return gson.toJson(response);
        } catch (Exception ex) {
            JsonObject response = new JsonObject();
            response.addProperty("ok", false);
            response.addProperty("error", safe(ex));
            return gson.toJson(response);
        }
    }

    private JsonObject bootstrap() {
        JsonObject out = new JsonObject();
        out.add("settings", settingsJson());
        out.add("project", projectJson());
        try {
            out.add("mcp", refreshTools());
        } catch (Exception ex) {
            JsonObject m = new JsonObject();
            m.addProperty("connected", false);
            m.addProperty("error", safe(ex));
            m.add("tools", new JsonArray());
            m.add("capabilities", capabilitiesJson(new McpCapabilities(new JsonArray())));
            out.add("mcp", m);
        }
        out.add("history", historyJson());
        return out;
    }

    private JsonObject settingsJson() {
        EngineeringAiSettings.StateData s = EngineeringAiSettings.getInstance().getState();
        JsonObject o = new JsonObject();
        if (s == null) return o;
        o.addProperty("mode", s.mode);
        o.addProperty("llmEnabled", s.llmEnabled);
        o.addProperty("llmModel", s.llmModel);
        o.addProperty("llmConfigured", s.llmUrl != null && !s.llmUrl.isBlank());
        o.addProperty("mcpUrl", s.mcpUrl);
        o.addProperty("knowledgeLabel", s.centralKnowledgeLabel);
        o.addProperty("maxFolderFiles", s.maxFolderFiles);
        return o;
    }

    private JsonObject projectJson() {
        JsonObject o = new JsonObject();
        o.addProperty("name", project.getName());
        o.addProperty("basePath", project.getBasePath() == null ? "" : project.getBasePath());
        var editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
        if (editor != null) {
            VirtualFile f = FileDocumentManager.getInstance().getFile(editor.getDocument());
            o.addProperty("activeFile", f == null ? "" : f.getName());
            o.addProperty("activeFilePath", f == null ? "" : f.getPath());
            String selected = editor.getSelectionModel().getSelectedText();
            o.addProperty("selection", selected == null || selected.isBlank() ? "Entire file" : "Selected code");
            o.addProperty("lineCount", editor.getDocument().getLineCount());
        } else {
            o.addProperty("activeFile", "No active file");
            o.addProperty("activeFilePath", "");
            o.addProperty("selection", "None");
            o.addProperty("lineCount", 0);
        }
        return o;
    }

    private JsonObject refreshTools() throws Exception {
        cachedTools = mcp.listTools();
        McpCapabilities caps = new McpCapabilities(cachedTools);
        JsonObject out = new JsonObject();
        out.addProperty("connected", true);
        out.add("tools", cachedTools.deepCopy());
        out.add("capabilities", capabilitiesJson(caps));
        return out;
    }

    private JsonObject capabilitiesJson(McpCapabilities c) {
        JsonObject o = new JsonObject();
        o.addProperty("knowledge", c.knowledge());
        o.addProperty("splunk", c.splunk());
        o.addProperty("newRelic", c.newRelic());
        o.addProperty("pcf", c.pcf());
        o.addProperty("oracle", c.oracle());
        o.addProperty("sqlServer", c.sqlServer());
        o.addProperty("jenkins", c.jenkins());
        JsonArray enabled = new JsonArray();
        c.enabledSources().forEach(enabled::add);
        o.add("enabledSources", enabled);
        return o;
    }

    private JsonObject toggleLlm(JsonObject payload) {
        var s = settings();
        boolean enabled = bool(payload, "enabled", !s.llmEnabled);
        s.llmEnabled = enabled;
        if (enabled && "DIRECT_MCP".equalsIgnoreCase(s.mode)) s.mode = "AUTO";
        if (!enabled) s.mode = "DIRECT_MCP";
        return settingsJson();
    }

    private JsonObject setMode(JsonObject payload) {
        var s = settings();
        String mode = str(payload, "mode", s.mode).toUpperCase(Locale.ROOT);
        if (!Set.of("AUTO", "LLM_GATEWAY", "DIRECT_MCP").contains(mode)) mode = "AUTO";
        s.mode = mode;
        if ("DIRECT_MCP".equals(mode)) s.llmEnabled = false;
        return settingsJson();
    }

    private JsonObject openSettings() {
        SwingUtilities.invokeLater(() -> ShowSettingsUtil.getInstance().showSettingsDialog(project, "Engineering AI"));
        JsonObject o = new JsonObject();
        o.addProperty("opened", true);
        return o;
    }

    private JsonObject selectSource(JsonObject payload) throws Exception {
        String scope = str(payload, "scope", "CURRENT_FILE").toUpperCase(Locale.ROOT);
        chosenScope = scope;
        JsonObject out = new JsonObject();
        out.addProperty("scope", scope);
        switch (scope) {
            case "SELECTED_CODE" -> {
                String context = IdeContextProvider.collectSelectedCode(project);
                out.addProperty("display", activePath());
                out.addProperty("context", context);
                out.add("files", oneFileArray(activePath()));
            }
            case "CURRENT_FILE" -> {
                String context = IdeContextProvider.collectCurrentFile(project);
                chosenPath = activePath();
                out.addProperty("display", chosenPath);
                out.addProperty("context", context);
                out.add("files", oneFileArray(chosenPath));
            }
            case "CHOOSE_FILE" -> {
                File f = choose(false);
                if (f == null) throw new IllegalStateException("File selection cancelled.");
                chosenPath = f.getAbsolutePath();
                out.addProperty("display", chosenPath);
                out.addProperty("context", IdeContextProvider.collectFile(f.toPath()));
                out.add("files", oneFileArray(chosenPath));
            }
            case "CHOOSE_FOLDER" -> {
                File f = choose(true);
                if (f == null) throw new IllegalStateException("Folder selection cancelled.");
                chosenPath = f.getAbsolutePath();
                out.addProperty("display", chosenPath);
                out.addProperty("context", IdeContextProvider.collectFolder(f.toPath()));
                out.add("files", previewFolder(f.toPath()));
            }
            default -> throw new IllegalArgumentException("Unsupported source scope: " + scope);
        }
        return out;
    }

    private JsonObject runMcpTool(JsonObject payload) throws Exception {
        String name = str(payload, "name", "");
        if (name.isBlank()) throw new IllegalArgumentException("Select an MCP tool first.");
        JsonObject args = payload.has("arguments") && payload.get("arguments").isJsonObject()
                ? payload.getAsJsonObject("arguments").deepCopy() : new JsonObject();
        boolean attach = bool(payload, "attachSource", false);
        if (attach) attachSourceIfSupported(name, args);

        long start = System.currentTimeMillis();
        JsonObject rpc = mcp.callTool(name, args);
        String text = mcp.callToolAsTextFromResponse(rpc);
        long elapsed = System.currentTimeMillis() - start;

        EngineeringAiHistoryService.getInstance().add(new EngineeringAiHistoryService.HistoryEntry(
                "DIRECT_MCP", name, gson.toJson(args), chosenScope + ": " + chosenPath, text));

        JsonObject out = new JsonObject();
        out.add("rpc", rpc);
        out.addProperty("text", text);
        out.addProperty("elapsedMs", elapsed);
        out.add("summary", summarizeResult(text, rpc));
        return out;
    }

    private JsonObject aiAsk(JsonObject payload) throws Exception {
        var s = settings();
        if (!s.llmEnabled) throw new IllegalStateException("LLM is OFF. Turn LLM ON or use MCP Tools for Direct MCP.");
        String prompt = str(payload, "prompt", "");
        if (prompt.isBlank()) throw new IllegalArgumentException("Enter a prompt first.");
        String scope = str(payload, "scope", chosenScope);
        String context = collectScope(scope);
        String reviewType = str(payload, "reviewType", "Security");
        String framework = str(payload, "framework", "Spring Boot");
        String rules = str(payload, "rules", "OWASP Top 10");
        boolean useKnowledge = bool(payload, "useKnowledge", true);
        String enriched = prompt + "\n\nReview type: " + reviewType + "\nFramework: " + framework + "\nRules: " + rules +
                "\nUse MCP knowledge base: " + useKnowledge;

        long start = System.currentTimeMillis();
        String result = orchestrator.ask(enriched, context);
        long elapsed = System.currentTimeMillis() - start;

        EngineeringAiHistoryService.getInstance().add(new EngineeringAiHistoryService.HistoryEntry(
                "AI_CHAT", reviewType + " review", prompt, scope + ": " + chosenPath, result));

        JsonObject out = new JsonObject();
        out.addProperty("text", result);
        out.addProperty("elapsedMs", elapsed);
        out.add("summary", summarizeText(result));
        return out;
    }

    private JsonObject knowledgeList(JsonObject payload) throws Exception {
        String category = str(payload, "category", "skills").toLowerCase(Locale.ROOT);
        String tool = switch (category) {
            case "agents" -> "list_agents";
            case "instructions" -> "list_instructions";
            case "scripts" -> "list_scripts";
            default -> "list_skills";
        };
        if (!hasTool(tool)) return emptyKnowledge(category, "MCP server does not expose " + tool);
        String raw = mcp.callToolAsText(tool, new JsonObject());
        JsonObject out = new JsonObject();
        out.addProperty("category", category);
        out.addProperty("raw", raw);
        out.add("items", extractKnowledgeItems(raw, category));
        return out;
    }

    private JsonObject knowledgeGet(JsonObject payload) throws Exception {
        String category = str(payload, "category", "skills").toLowerCase(Locale.ROOT);
        String name = str(payload, "name", "");
        if (name.isBlank()) throw new IllegalArgumentException("Knowledge item name is required.");
        String tool = switch (category) {
            case "agents" -> "get_agent";
            case "instructions" -> "get_instruction";
            case "scripts" -> "get_script";
            default -> "get_skill";
        };
        JsonObject args = new JsonObject();
        args.addProperty("name", name);
        String raw;
        if (hasTool(tool)) raw = mcp.callToolAsText(tool, args);
        else {
            JsonObject q = new JsonObject(); q.addProperty("query", category + " " + name);
            raw = mcp.callToolAsText("search_shared_docs", q);
        }
        JsonObject out = new JsonObject();
        out.addProperty("category", category);
        out.addProperty("name", name);
        out.addProperty("content", raw);
        return out;
    }

    private JsonObject knowledgeSearch(JsonObject payload) throws Exception {
        String query = str(payload, "query", "");
        JsonObject args = new JsonObject(); args.addProperty("query", query);
        String raw = mcp.callToolAsText("search_shared_docs", args);
        JsonObject out = new JsonObject(); out.addProperty("query", query); out.addProperty("content", raw); return out;
    }

    private JsonArray historyJson() {
        JsonArray a = new JsonArray();
        for (EngineeringAiHistoryService.HistoryEntry e : EngineeringAiHistoryService.getInstance().entries()) {
            JsonObject o = new JsonObject();
            o.addProperty("timestamp", e.timestamp); o.addProperty("mode", e.mode); o.addProperty("title", e.title);
            o.addProperty("prompt", e.prompt); o.addProperty("source", e.source); o.addProperty("result", e.result);
            a.add(o);
        }
        return a;
    }

    private JsonArray clearHistory() {
        EngineeringAiHistoryService.getInstance().clear();
        return new JsonArray();
    }

    private void attachSourceIfSupported(String toolName, JsonObject args) throws Exception {
        JsonObject tool = findTool(toolName);
        if (tool == null || !tool.has("inputSchema") || !tool.get("inputSchema").isJsonObject()) return;
        JsonObject schema = tool.getAsJsonObject("inputSchema");
        if (!schema.has("properties") || !schema.get("properties").isJsonObject()) return;
        JsonObject props = schema.getAsJsonObject("properties");
        String context = collectScope(chosenScope);
        for (String key : List.of("code", "context", "source", "content")) {
            if (props.has(key) && !args.has(key)) { args.addProperty(key, context); break; }
        }
        if (props.has("filePath") && !args.has("filePath")) args.addProperty("filePath", chosenPath.isBlank() ? activePath() : chosenPath);
        if (props.has("language") && !args.has("language")) args.addProperty("language", languageOf(chosenPath.isBlank() ? activePath() : chosenPath));
    }

    private String collectScope(String scopeRaw) throws Exception {
        String scope = scopeRaw == null ? "CURRENT_FILE" : scopeRaw.toUpperCase(Locale.ROOT);
        chosenScope = scope;
        return switch (scope) {
            case "SELECTED_CODE" -> IdeContextProvider.collectSelectedCode(project);
            case "CHOOSE_FILE" -> chosenPath.isBlank() ? IdeContextProvider.collectCurrentFile(project) : IdeContextProvider.collectFile(Path.of(chosenPath));
            case "CHOOSE_FOLDER" -> chosenPath.isBlank() ? IdeContextProvider.collectCurrentFile(project) : IdeContextProvider.collectFolder(Path.of(chosenPath));
            default -> IdeContextProvider.collectCurrentFile(project);
        };
    }

    private JsonObject summarizeResult(String text, JsonObject rpc) {
        JsonObject o = summarizeText(text);
        try {
            JsonObject result = rpc.has("result") && rpc.get("result").isJsonObject() ? rpc.getAsJsonObject("result") : null;
            if (result != null && result.has("isError")) o.addProperty("isError", result.get("isError").getAsBoolean());
        } catch (Exception ignored) { }
        return o;
    }

    private JsonObject summarizeText(String text) {
        String lower = text == null ? "" : text.toLowerCase(Locale.ROOT);
        JsonObject o = new JsonObject();
        o.addProperty("high", countWords(lower, "high", "critical", "hardcoded secret", "sql injection", "csrf"));
        o.addProperty("medium", countWords(lower, "medium", "warning", "deprecated", "validation"));
        o.addProperty("low", countWords(lower, "low", "info", "minor"));
        o.addProperty("total", Math.max(0, o.get("high").getAsInt() + o.get("medium").getAsInt() + o.get("low").getAsInt()));
        return o;
    }

    private int countWords(String text, String... terms) {
        int n = 0;
        for (String term : terms) {
            int from = 0;
            while ((from = text.indexOf(term, from)) >= 0) { n++; from += term.length(); }
        }
        return Math.min(n, 99);
    }

    private JsonArray extractKnowledgeItems(String raw, String category) {
        LinkedHashSet<String> items = new LinkedHashSet<>();
        if (raw != null) {
            for (String line : raw.split("\\R")) {
                String x = line.trim();
                if (x.startsWith("PATH:")) x = x.substring(5).trim();
                x = x.replaceFirst("^[\\-*•>\\d.\\s]+", "");
                if (x.isBlank() || x.startsWith("SOURCE:") || x.startsWith("SCORE:") || x.length() > 120) continue;
                x = x.replace("`", "").replace("\\", "/");
                if (x.contains("/")) x = x.substring(x.lastIndexOf('/') + 1);
                x = x.replaceAll("\\.(agent\\.)?md$", "").replaceAll("\\.(mjs|cjs|sh|js|ts)$", "");
                if (x.matches("[A-Za-z0-9_.-]{2,80}")) items.add(x);
            }
        }
        JsonArray a = new JsonArray();
        int i = 0;
        for (String name : items) {
            JsonObject o = new JsonObject(); o.addProperty("name", name); o.addProperty("category", category);
            o.addProperty("description", defaultDescription(category, name)); o.addProperty("version", "v1.0");
            JsonArray tags = new JsonArray(); for (String t : name.split("[-_.]")) if (t.length() > 2) tags.add(t); o.add("tags", tags);
            a.add(o); if (++i >= 100) break;
        }
        return a;
    }

    private String defaultDescription(String category, String name) {
        return switch (category) {
            case "agents" -> "Engineering agent: " + name;
            case "instructions" -> "Shared engineering instruction: " + name;
            case "scripts" -> "Repository automation/script: " + name;
            default -> "Reusable engineering skill and guidance: " + name;
        };
    }

    private JsonObject emptyKnowledge(String category, String message) {
        JsonObject o = new JsonObject(); o.addProperty("category", category); o.addProperty("raw", message); o.add("items", new JsonArray()); return o;
    }

    private boolean hasTool(String name) throws Exception {
        if (cachedTools.isEmpty()) cachedTools = mcp.listTools();
        return findTool(name) != null;
    }

    private JsonObject findTool(String name) {
        for (JsonElement e : cachedTools) if (e.isJsonObject() && name.equals(str(e.getAsJsonObject(), "name", ""))) return e.getAsJsonObject();
        return null;
    }

    private File choose(boolean folder) throws Exception {
        final File[] selected = new File[1];
        Runnable r = () -> {
            JFileChooser chooser = new JFileChooser(project.getBasePath());
            chooser.setFileSelectionMode(folder ? JFileChooser.DIRECTORIES_ONLY : JFileChooser.FILES_ONLY);
            chooser.setDialogTitle(folder ? "Choose source folder" : "Choose source file");
            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) selected[0] = chooser.getSelectedFile();
        };
        if (SwingUtilities.isEventDispatchThread()) r.run(); else SwingUtilities.invokeAndWait(r);
        return selected[0];
    }

    private JsonArray previewFolder(Path root) throws Exception {
        JsonArray a = new JsonArray();
        int limit = Math.max(1, settings().maxFolderFiles);
        try (Stream<Path> walk = Files.walk(root)) {
            walk.filter(Files::isRegularFile).filter(this::previewAllowed).filter(p -> !ignored(root, p)).limit(limit).forEach(p -> {
                JsonObject o = new JsonObject(); o.addProperty("name", p.getFileName().toString()); o.addProperty("path", root.relativize(p).toString().replace('\\','/')); a.add(o);
            });
        }
        return a;
    }

    private boolean previewAllowed(Path p) {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        return n.matches(".*\\.(java|kt|kts|xml|yml|yaml|properties|gradle|groovy|js|ts|tsx|jsx|json|md|sql)$");
    }

    private boolean ignored(Path root, Path p) {
        Set<String> ignored = Set.of(".git", ".idea", "build", "target", "node_modules", "out", "dist");
        for (Path part : root.relativize(p)) if (ignored.contains(part.toString())) return true;
        return false;
    }

    private JsonArray oneFileArray(String path) {
        JsonArray a = new JsonArray(); if (path == null || path.isBlank()) return a;
        JsonObject o = new JsonObject(); o.addProperty("name", Path.of(path).getFileName().toString()); o.addProperty("path", path); a.add(o); return a;
    }

    private String activePath() {
        var editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
        if (editor == null) return "";
        VirtualFile f = FileDocumentManager.getInstance().getFile(editor.getDocument());
        return f == null ? "" : f.getPath();
    }

    private String languageOf(String path) {
        int dot = path == null ? -1 : path.lastIndexOf('.');
        return dot < 0 ? "text" : path.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private EngineeringAiSettings.StateData settings() {
        var s = EngineeringAiSettings.getInstance().getState();
        if (s == null) throw new IllegalStateException("Engineering AI settings unavailable.");
        return s;
    }

    private static String str(JsonObject o, String key, String fallback) {
        try { return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : fallback; } catch (Exception e) { return fallback; }
    }
    private static boolean bool(JsonObject o, String key, boolean fallback) {
        try { return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsBoolean() : fallback; } catch (Exception e) { return fallback; }
    }
    private static String safe(Throwable e) {
        String m = e.getMessage(); return (m == null || m.isBlank()) ? e.getClass().getSimpleName() : m;
    }
}
