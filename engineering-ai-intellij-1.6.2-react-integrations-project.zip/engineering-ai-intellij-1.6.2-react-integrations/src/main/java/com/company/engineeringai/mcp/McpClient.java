package com.company.engineeringai.mcp;

import com.company.engineeringai.settings.EngineeringAiSettings;
import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;

public final class McpClient {
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private String sessionId;
    private boolean initialized;

    public JsonArray listTools() throws Exception {
        ensureInitialized();
        JsonObject response = parseJsonRpc(sendRpc("tools/list", new JsonObject(), true));
        JsonObject result = response.has("result") && response.get("result").isJsonObject() ? response.getAsJsonObject("result") : null;
        return result != null && result.has("tools") && result.get("tools").isJsonArray() ? result.getAsJsonArray("tools") : new JsonArray();
    }

    public McpCapabilities capabilities() throws Exception { return new McpCapabilities(listTools()); }
    public String initializeAndListTools() throws Exception { return gson.toJson(listTools()); }

    public JsonObject callTool(String name, JsonObject args) throws Exception {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Select an MCP tool first.");
        ensureInitialized();
        JsonObject params = new JsonObject();
        params.addProperty("name", name);
        params.add("arguments", args == null ? new JsonObject() : args);
        return parseJsonRpc(sendRpc("tools/call", params, true));
    }

    public String callToolAsText(String name, JsonObject args) throws Exception {
        JsonObject rpc = callTool(name, args);
        return callToolAsTextFromResponse(rpc);
    }

    public String callToolAsTextFromResponse(JsonObject rpc) {
        if (!rpc.has("result")) return gson.toJson(rpc);
        JsonElement result = rpc.get("result");
        if (!result.isJsonObject()) return gson.toJson(result);
        JsonObject resultObject = result.getAsJsonObject();
        if (resultObject.has("content") && resultObject.get("content").isJsonArray()) {
            StringBuilder text = new StringBuilder();
            for (JsonElement element : resultObject.getAsJsonArray("content")) {
                if (!element.isJsonObject()) continue;
                JsonObject item = element.getAsJsonObject();
                if (item.has("text") && !item.get("text").isJsonNull()) {
                    if (!text.isEmpty()) text.append("\n\n");
                    text.append(item.get("text").getAsString());
                }
            }
            if (!text.isEmpty()) return text.toString();
        }
        return gson.toJson(resultObject);
    }

    public JsonObject parseArguments(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.isEmpty()) return new JsonObject();
        JsonElement element = JsonParser.parseString(value);
        if (!element.isJsonObject()) throw new IllegalArgumentException("MCP arguments must be a JSON object, for example {\"query\":\"security\"}.");
        return element.getAsJsonObject();
    }

    public JsonObject buildArgumentTemplate(JsonObject tool) {
        JsonObject out = new JsonObject();
        if (tool == null || !tool.has("inputSchema") || !tool.get("inputSchema").isJsonObject()) return out;
        JsonObject schema = tool.getAsJsonObject("inputSchema");
        if (!schema.has("properties") || !schema.get("properties").isJsonObject()) return out;
        JsonObject properties = schema.getAsJsonObject("properties");
        for (String key : properties.keySet()) {
            JsonObject property = properties.get(key).isJsonObject() ? properties.getAsJsonObject(key) : new JsonObject();
            String type = property.has("type") && property.get("type").isJsonPrimitive() ? property.get("type").getAsString() : "string";
            switch (type) {
                case "boolean" -> out.addProperty(key, false);
                case "integer", "number" -> out.addProperty(key, 0);
                case "array" -> out.add(key, new JsonArray());
                case "object" -> out.add(key, new JsonObject());
                default -> out.addProperty(key, "");
            }
        }
        return out;
    }

    public String pretty(JsonElement element) { return gson.toJson(element); }

    private void ensureInitialized() throws Exception {
        if (initialized) return;
        JsonObject params = new JsonObject();
        params.addProperty("protocolVersion", "2025-03-26");
        params.add("capabilities", new JsonObject());
        JsonObject info = new JsonObject();
        info.addProperty("name", "engineering-ai-intellij");
        info.addProperty("version", "1.6.0");
        params.add("clientInfo", info);
        sendRpc("initialize", params, true);
        initialized = true;
    }

    private String sendRpc(String method, JsonObject params, boolean hasId) throws Exception {
        var s = EngineeringAiSettings.getInstance().getState();
        if (s == null || s.mcpUrl == null || s.mcpUrl.isBlank()) throw new IllegalStateException("Configure MCP server URL in Settings > Engineering AI.");
        JsonObject body = new JsonObject();
        body.addProperty("jsonrpc", "2.0");
        if (hasId) body.addProperty("id", UUID.randomUUID().toString());
        body.addProperty("method", method);
        body.add("params", params);

        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(s.mcpUrl))
                .timeout(Duration.ofSeconds(90))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json, text/event-stream")
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(body)));
        if (sessionId != null && !sessionId.isBlank()) builder.header("Mcp-Session-Id", sessionId);

        HttpResponse<String> response = client.send(builder.build(), HttpResponse.BodyHandlers.ofString());
        response.headers().firstValue("Mcp-Session-Id").ifPresent(v -> sessionId = v);
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            String contentType = response.headers().firstValue("Content-Type").orElse("<none>");
            throw new IllegalStateException("MCP HTTP " + response.statusCode() + " (" + contentType + "): " + response.body());
        }
        return extractJson(response.body());
    }

    private JsonObject parseJsonRpc(String raw) {
        JsonElement element = JsonParser.parseString(raw);
        if (!element.isJsonObject()) throw new IllegalStateException("Invalid MCP JSON-RPC response.");
        JsonObject object = element.getAsJsonObject();
        if (object.has("error") && !object.get("error").isJsonNull()) throw new IllegalStateException("MCP error: " + object.get("error"));
        return object;
    }

    /** Supports plain JSON and the common SSE response shape. */
    private String extractJson(String body) {
        String text = body == null ? "" : body.trim();
        if (text.startsWith("{")) return text;
        StringBuilder data = new StringBuilder();
        for (String line : text.split("\\R")) {
            if (line.startsWith("data:")) {
                String value = line.substring(5).trim();
                if (!value.equals("[DONE]")) data.append(value);
            }
        }
        if (data.isEmpty()) throw new IllegalStateException("MCP response did not contain JSON: " + text);
        return data.toString();
    }
}
