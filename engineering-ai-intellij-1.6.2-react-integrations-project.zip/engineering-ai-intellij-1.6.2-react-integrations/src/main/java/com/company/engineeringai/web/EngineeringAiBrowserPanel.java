package com.company.engineeringai.web;

import com.intellij.openapi.Disposable;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Disposer;
import com.intellij.ui.jcef.JBCefApp;
import com.intellij.ui.jcef.JBCefBrowser;
import com.intellij.ui.jcef.JBCefJSQuery;

import javax.swing.*;
import java.awt.*;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** React UI host. Java owns IDE access, MCP, LLM, settings and persistence; React owns presentation. */
public final class EngineeringAiBrowserPanel extends JPanel implements Disposable {
    private JBCefBrowser browser;
    private JBCefJSQuery bridgeQuery;

    public EngineeringAiBrowserPanel(Project project) {
        super(new BorderLayout());
        if (!JBCefApp.isSupported()) {
            add(buildFallback(), BorderLayout.CENTER);
            return;
        }

        browser = new JBCefBrowser();
        bridgeQuery = JBCefJSQuery.create(browser);
        EngineeringAiBridge bridge = new EngineeringAiBridge(project);
        bridgeQuery.addHandler(request -> new JBCefJSQuery.Response(bridge.handle(request)));

        String bridgeJs = bridgeQuery.inject(
                "payload",
                "function(response){ resolve(response); }",
                "function(errorCode,errorMessage){ reject(errorMessage || ('Bridge error '+errorCode)); }"
        );

        String html = resource("/web/index.html")
                .replace("/*__REACT__*/", resource("/web/vendor/react.production.min.js"))
                .replace("/*__REACT_DOM__*/", resource("/web/vendor/react-dom.production.min.js"))
                .replace("/*__APP_CSS__*/", resource("/web/app.css"))
                .replace("/*__APP_JS__*/", resource("/web/app.js"))
                .replace("/*__JAVA_BRIDGE__*/", bridgeJs);

        browser.loadHTML(html);
        add(browser.getComponent(), BorderLayout.CENTER);

        Disposer.register(this, bridgeQuery);
        Disposer.register(this, browser);
    }

    private static JComponent buildFallback() {
        JPanel p = new JPanel(new BorderLayout());
        JLabel label = new JLabel("<html><div style='padding:24px'><h2>Engineering AI</h2>" +
                "JCEF is not available in this IDE runtime.<br/>" +
                "Run IntelliJ with the bundled JetBrains Runtime (JBR) that includes JCEF.</div></html>");
        label.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        p.add(label, BorderLayout.NORTH);
        return p;
    }

    private static String resource(String path) {
        try (InputStream in = EngineeringAiBrowserPanel.class.getResourceAsStream(path)) {
            if (in == null) throw new IllegalStateException("Missing plugin resource: " + path);
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to load plugin web resource " + path, ex);
        }
    }

    @Override
    public void dispose() {
        // Children are registered with Disposer.
    }
}
