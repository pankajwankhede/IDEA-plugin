# Engineering AI IntelliJ Plugin 1.2.4

Java 21 IntelliJ plugin for enterprise engineering assistance using:

- Optional LLM Gateway
- Dynamic MCP tool discovery
- Centralized shared knowledge through the MCP server
- IDE current-file and selected-code context
- Explicit no-LLM Direct MCP mode

## Modes

### LLM enabled

```text
Developer question
      |
      v
LLM Gateway
      |
      | tools/list
      v
engineering-mcp-server
      |
      +-- Bitbucket company-ai-agents
      +-- Splunk (when enabled)
      +-- New Relic (when enabled)
      +-- PCF (when enabled)
      +-- Oracle / SQL Server (when enabled)
      +-- Jenkins (when enabled)
      |
      v
LLM final answer
```

The LLM sees the tools currently exposed by MCP and decides which tool(s) to call.

### LLM disabled / DIRECT_MCP

```text
Engineering AI Tool Window
      |
      | tools/list
      v
MCP Tool dropdown
      |
      | developer selects tool
      | JSON arguments
      v
tools/call
      |
      v
Raw/formatted MCP response
```

No `engineering_ask` tool is required.

## Direct MCP workflow

Open **Engineering AI -> Direct MCP**.

1. Click **Refresh MCP Tools**.
2. The plugin calls `tools/list`.
3. Only tools enabled on the MCP server appear.
4. Select a tool.
5. The plugin generates an argument JSON template from `inputSchema`.
6. Fill in the values.
7. Click **Run MCP Tool**.

Example with only Bitbucket knowledge enabled:

```text
search_shared_docs
get_agent
get_instruction
get_skill
get_service_context
```

If Splunk is later enabled on the MCP server and `tools/list` exposes `search_splunk`, it appears automatically. No IntelliJ plugin release is required.

## Settings

**File -> Settings -> Engineering AI**

Recommended:

```text
Mode: AUTO
Enable LLM gateway: true/false
LLM Gateway URL: ...
LLM model: ...
MCP server URL: http://localhost:8080/mcp

Central knowledge:
Bitbucket company-ai-agents
```

The plugin never stores the Bitbucket URL/token. Those stay inside `engineering-mcp-server`.

## Java

Java 21 is configured through the Gradle toolchain.

In IntelliJ:

```text
Project SDK: Java 21
Gradle JVM: Java 21
```

## Run in sandbox

```bash
gradlew.bat runIde
```

`runIde` intentionally opens a second sandbox IntelliJ instance.

## Build installable plugin

```bash
gradlew.bat clean buildPlugin
```

Output:

```text
build/distributions/
```

Install using:

```text
Settings -> Plugins -> Gear -> Install Plugin from Disk
```

## Important 1.2.3 changes

- Added `@Service(Service.Level.APP)` to the persistent settings service.
- Removed hard dependency on `engineering_ask`.
- Added a **Direct MCP** tab.
- Added dynamic `tools/list` discovery.
- Added MCP tool dropdown.
- Added schema-based JSON argument template generation.
- Added direct `tools/call`.
- LLM ON and LLM OFF are now separate, explicit workflows.
- Updated shared knowledge defaults to `Bitbucket company-ai-agents`.
