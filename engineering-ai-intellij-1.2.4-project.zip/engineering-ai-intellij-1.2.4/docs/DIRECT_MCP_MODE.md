# Direct MCP Mode

Direct MCP mode is intended for environments where the LLM is disabled or unavailable.

## Behavior

The plugin does not try to understand arbitrary natural-language intent.

Instead it:

1. Calls `initialize`.
2. Calls `tools/list`.
3. Displays returned tools in the IDE.
4. Displays an input argument template generated from each tool's `inputSchema`.
5. Calls `tools/call` with the selected tool and JSON arguments.
6. Displays the MCP response.

This means `engineering_ask` is not required.

## Example

If MCP returns:

```json
{
  "name": "search_shared_docs",
  "description": "Search centralized Bitbucket engineering documentation",
  "inputSchema": {
    "type": "object",
    "properties": {
      "query": { "type": "string" },
      "maxResults": { "type": "integer" }
    },
    "required": ["query"]
  }
}
```

the IDE generates:

```json
{
  "query": "",
  "maxResults": 0
}
```

The developer fills in:

```json
{
  "query": "authentication standards",
  "maxResults": 5
}
```

and clicks **Run MCP Tool**.

## Dynamic integration enable/disable

The IntelliJ plugin does not know whether Splunk, New Relic, PCF, Oracle, SQL Server or Jenkins is enabled.

`tools/list` is authoritative.

If an integration is disabled on `engineering-mcp-server`, its tools are not shown.
