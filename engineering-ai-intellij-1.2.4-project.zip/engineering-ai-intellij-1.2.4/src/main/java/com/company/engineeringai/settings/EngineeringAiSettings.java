package com.company.engineeringai.settings;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.PersistentStateComponent;
import com.intellij.openapi.components.Service;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.Storage;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Service(Service.Level.APP)
@State(name = "EngineeringAiSettings", storages = @Storage("engineering-ai.xml"))
public final class EngineeringAiSettings implements PersistentStateComponent<EngineeringAiSettings.StateData> {

    public static final class StateData {
        /** AUTO = prefer LLM when enabled/configured, otherwise direct MCP. */
        public String mode = "AUTO";

        /** Master switch. When false the plugin never calls the LLM gateway. */
        public boolean llmEnabled = true;

        // Generic OpenAI-compatible enterprise LLM gateway settings.
        public String llmUrl = "http://localhost:8081/v1/chat/completions";
        public String llmModel = "enterprise-model";

        /** Environment variable containing the bearer token. The token itself is never persisted. */
        public String llmTokenEnv = "ENGINEERING_AI_LLM_TOKEN";
        public int maxToolRounds = 6;

        // The plugin only knows the MCP endpoint. Bitbucket and enterprise credentials remain server-side.
        public String mcpUrl = "http://localhost:8080/mcp";

        // Centralized knowledge behind MCP.
        public boolean useCentralKnowledge = true;
        public String centralKnowledgeLabel = "Bitbucket company-ai-agents";
        public String knowledgeToolHints =
                "search_shared_docs,get_agent,get_instruction,get_skill,get_service_context";

        // IDE context settings.
        public boolean includeCurrentFile = true;
        public boolean includeSelectedCode = true;
    }

    private StateData state = new StateData();

    public static EngineeringAiSettings getInstance() {
        return ApplicationManager.getApplication().getService(EngineeringAiSettings.class);
    }

    @Override
    public @Nullable StateData getState() {
        return state;
    }

    @Override
    public void loadState(@NotNull StateData state) {
        this.state = state;
    }
}
