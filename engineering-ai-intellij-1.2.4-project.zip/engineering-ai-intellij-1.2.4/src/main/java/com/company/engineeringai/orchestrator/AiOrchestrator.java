package com.company.engineeringai.orchestrator;

import com.company.engineeringai.llm.LlmGatewayClient;
import com.company.engineeringai.mcp.McpClient;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.google.gson.*;

public final class AiOrchestrator {
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final McpClient mcp = new McpClient();
    private final LlmGatewayClient llm = new LlmGatewayClient();

    /**
     * Natural-language orchestration path.
     *
     * LLM ON:
     *   IDE context -> LLM -> MCP tools when needed -> LLM final answer.
     *
     * LLM OFF / DIRECT_MCP:
     *   The Tool Window handles direct MCP execution explicitly using tools/list + tools/call.
     */
    public String ask(String query, String context) throws Exception {
        var s = EngineeringAiSettings.getInstance().getState();
        if (s == null) {
            throw new IllegalStateException("Engineering AI settings unavailable.");
        }

        String mode = s.mode == null ? "AUTO" : s.mode.trim().toUpperCase();
        boolean llmConfigured = s.llmEnabled
                && s.llmUrl != null
                && !s.llmUrl.isBlank();

        if ("DIRECT_MCP".equals(mode) || !s.llmEnabled) {
            throw new IllegalStateException(
                    "LLM is disabled. Use the Direct MCP section in the Engineering AI tool window: " +
                    "Refresh MCP Tools -> select a tool -> enter arguments -> Run MCP Tool."
            );
        }

        if ("LLM_GATEWAY".equals(mode)) {
            if (!llmConfigured) {
                throw new IllegalStateException(
                        "LLM_GATEWAY mode is selected but the LLM gateway is disabled or not configured."
                );
            }
            return askViaLlm(query, context, s);
        }

        // AUTO: use LLM when it is enabled/configured.
        // MCP remains optional inside the LLM path.
        if (llmConfigured) {
            return askViaLlm(query, context, s);
        }

        throw new IllegalStateException(
                "AUTO mode has no configured LLM. Use the Direct MCP section or enable/configure the LLM gateway."
        );
    }

    private String askViaLlm(
            String query,
            String context,
            EngineeringAiSettings.StateData settings
    ) throws Exception {

        JsonArray mcpTools = new JsonArray();
        String mcpStatus = "available";

        try {
            mcpTools = mcp.listTools();
        } catch (Exception ex) {
            // MCP is optional for LLM/code-only analysis.
            mcpStatus = "unavailable: " + safe(ex.getMessage());
        }

        JsonArray llmTools = toLlmTools(mcpTools);

        JsonArray messages = new JsonArray();
        messages.add(message("system", systemPrompt(settings, mcpStatus)));
        messages.add(message("user", buildUserMessage(query, context)));

        int rounds = Math.max(1, Math.min(settings.maxToolRounds, 12));

        for (int i = 0; i < rounds; i++) {
            JsonObject assistant = llm.chat(messages, llmTools);
            messages.add(assistant.deepCopy());

            JsonArray calls = assistant.has("tool_calls")
                    && assistant.get("tool_calls").isJsonArray()
                    ? assistant.getAsJsonArray("tool_calls")
                    : null;

            if (calls == null || calls.isEmpty()) {
                return contentOf(assistant);
            }

            for (JsonElement element : calls) {
                JsonObject call = element.getAsJsonObject();
                JsonObject function = call.getAsJsonObject("function");

                String name = function.get("name").getAsString();
                String callId = call.has("id")
                        ? call.get("id").getAsString()
                        : name;

                JsonObject args = parseArgs(
                        function.has("arguments")
                                ? function.get("arguments")
                                : null
                );

                JsonObject result;

                try {
                    result = mcp.callTool(name, args);
                } catch (Exception ex) {
                    result = new JsonObject();
                    result.addProperty(
                            "error",
                            "MCP tool unavailable: " + safe(ex.getMessage())
                    );
                    result.addProperty("tool", name);
                }

                JsonObject toolMessage = new JsonObject();
                toolMessage.addProperty("role", "tool");
                toolMessage.addProperty("tool_call_id", callId);
                toolMessage.addProperty("content", gson.toJson(result));

                messages.add(toolMessage);
            }
        }

        JsonObject finalMessage = llm.chat(messages, new JsonArray());
        return contentOf(finalMessage);
    }

    private JsonArray toLlmTools(JsonArray mcpTools) {
        JsonArray out = new JsonArray();

        for (JsonElement element : mcpTools) {
            if (!element.isJsonObject()) continue;

            JsonObject mcpTool = element.getAsJsonObject();
            if (!mcpTool.has("name")) continue;

            JsonObject function = new JsonObject();
            function.addProperty("name", mcpTool.get("name").getAsString());
            function.addProperty(
                    "description",
                    mcpTool.has("description")
                            ? mcpTool.get("description").getAsString()
                            : "MCP tool"
            );

            function.add(
                    "parameters",
                    mcpTool.has("inputSchema")
                            ? mcpTool.get("inputSchema").deepCopy()
                            : emptyObjectSchema()
            );

            JsonObject wrapper = new JsonObject();
            wrapper.addProperty("type", "function");
            wrapper.add("function", function);

            out.add(wrapper);
        }

        return out;
    }

    private JsonObject emptyObjectSchema() {
        JsonObject object = new JsonObject();
        object.addProperty("type", "object");
        object.add("properties", new JsonObject());
        return object;
    }

    private JsonObject message(String role, String content) {
        JsonObject message = new JsonObject();
        message.addProperty("role", role);
        message.addProperty("content", content);
        return message;
    }

    private JsonObject parseArgs(JsonElement element) {
        if (element == null || element.isJsonNull()) {
            return new JsonObject();
        }

        if (element.isJsonObject()) {
            return element.getAsJsonObject();
        }

        try {
            return JsonParser.parseString(element.getAsString()).getAsJsonObject();
        } catch (Exception ignored) {
            return new JsonObject();
        }
    }

    private String contentOf(JsonObject message) {
        if (!message.has("content") || message.get("content").isJsonNull()) {
            return "LLM returned no final text response.";
        }

        if (message.get("content").isJsonPrimitive()) {
            return message.get("content").getAsString();
        }

        return gson.toJson(message.get("content"));
    }

    private String buildUserMessage(String query, String context) {
        return "QUESTION:\n"
                + query
                + "\n\nLOCAL IDE CONTEXT:\n"
                + (context == null || context.isBlank() ? "(none)" : context);
    }

    private String systemPrompt(
            EngineeringAiSettings.StateData settings,
            String mcpStatus
    ) {
        String source = settings.centralKnowledgeLabel == null
                || settings.centralKnowledgeLabel.isBlank()
                ? "central shared knowledge repository"
                : settings.centralKnowledgeLabel;

        String hints = settings.knowledgeToolHints == null
                || settings.knowledgeToolHints.isBlank()
                ? "(none configured)"
                : settings.knowledgeToolHints;

        return """
You are Engineering AI inside IntelliJ IDEA.

The developer's IDE code/context is supplied directly in the user message.
Shared Markdown files, agent definitions, instructions and skills are centrally managed
behind the MCP server in: %s.

When MCP tools are available, use tools/list as authoritative tool discovery.
Knowledge tools may resemble: %s.

MCP status for this request: %s.

Rules:
- If MCP is available, use the relevant MCP tool when centralized knowledge or live enterprise evidence is needed.
- If MCP is unavailable, continue with IDE code/context when possible and clearly state what could not be verified.
- Never invent Bitbucket Markdown, agent instructions, logs, metrics, database results or MCP results.
- Prefer the shared knowledge tools for architecture, instructions, agents, skills, runbooks and service context.
- Prefer live read-only tools for logs, traces, platform status and dependency evidence when enabled.
- Distinguish IDE-code evidence, shared-knowledge evidence and live-system evidence in the final answer when useful.
- Never expose credentials, tokens or secrets.
""".formatted(source, hints, mcpStatus);
    }

    private String safe(String value) {
        return value == null || value.isBlank()
                ? "unknown error"
                : value;
    }
}
