package com.company.engineeringai.toolwindow;

import com.company.engineeringai.context.IdeContextProvider;
import com.company.engineeringai.mcp.McpClient;
import com.company.engineeringai.orchestrator.AiOrchestrator;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowFactory;
import com.intellij.ui.components.JBLabel;
import com.intellij.ui.components.JBScrollPane;
import com.intellij.ui.components.JBTextArea;
import com.intellij.ui.content.Content;
import com.intellij.ui.content.ContentFactory;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public final class EngineeringAiToolWindowFactory implements ToolWindowFactory {

    private final Map<String, JsonObject> discoveredTools = new LinkedHashMap<>();

    @Override
    public void createToolWindowContent(
            @NotNull Project project,
            @NotNull ToolWindow toolWindow
    ) {
        JPanel root = new JPanel(new BorderLayout(8, 8));

        JBTextArea output = new JBTextArea();
        output.setEditable(false);
        output.setLineWrap(true);
        output.setWrapStyleWord(true);
        output.setText(
                "Engineering AI 1.2.4\n\n" +
                "LLM ON: ask natural-language questions and the LLM can choose MCP tools automatically.\n" +
                "LLM OFF / DIRECT_MCP: refresh MCP tools, select one, provide JSON arguments, and run it directly."
        );

        JTabbedPane tabs = new JTabbedPane();

        // -----------------------------
        // AI Chat tab (LLM path)
        // -----------------------------
        JPanel chatPanel = new JPanel(new BorderLayout(6, 6));

        JBTextArea input = new JBTextArea(5, 40);
        input.setLineWrap(true);
        input.setWrapStyleWord(true);

        JButton ask = new JButton("Ask Engineering AI");
        JButton preview = new JButton("Preview IDE Context");
        JLabel modeLabel = new JLabel();
        refreshMode(modeLabel);

        JPanel chatButtons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        chatButtons.add(ask);
        chatButtons.add(preview);
        chatButtons.add(modeLabel);

        chatPanel.add(new JBScrollPane(input), BorderLayout.CENTER);
        chatPanel.add(chatButtons, BorderLayout.SOUTH);

        // -----------------------------
        // Direct MCP tab (no LLM)
        // -----------------------------
        JPanel directPanel = new JPanel(new BorderLayout(6, 6));

        JComboBox<String> toolCombo = new JComboBox<>();
        toolCombo.setPrototypeDisplayValue("search_shared_docs                         ");

        JButton refreshTools = new JButton("Refresh MCP Tools");
        JButton runTool = new JButton("Run MCP Tool");

        JBTextArea toolDescription = new JBTextArea(3, 40);
        toolDescription.setEditable(false);
        toolDescription.setLineWrap(true);
        toolDescription.setWrapStyleWord(true);

        JBTextArea toolArguments = new JBTextArea(8, 40);
        toolArguments.setLineWrap(true);
        toolArguments.setWrapStyleWord(true);
        toolArguments.setText("{}");

        JPanel toolTop = new JPanel(new BorderLayout(6, 6));

        JPanel toolSelector = new JPanel(new BorderLayout(6, 6));
        toolSelector.add(new JBLabel("MCP Tool:"), BorderLayout.WEST);
        toolSelector.add(toolCombo, BorderLayout.CENTER);
        toolSelector.add(refreshTools, BorderLayout.EAST);

        toolTop.add(toolSelector, BorderLayout.NORTH);
        toolTop.add(new JBScrollPane(toolDescription), BorderLayout.CENTER);

        JPanel argsPanel = new JPanel(new BorderLayout(4, 4));
        argsPanel.add(
                new JBLabel(
                        "<html>MCP arguments (JSON). The template is generated from the tool's inputSchema.</html>"
                ),
                BorderLayout.NORTH
        );
        argsPanel.add(new JBScrollPane(toolArguments), BorderLayout.CENTER);
        argsPanel.add(runTool, BorderLayout.SOUTH);

        directPanel.add(toolTop, BorderLayout.NORTH);
        directPanel.add(argsPanel, BorderLayout.CENTER);

        tabs.addTab("AI Chat", chatPanel);
        tabs.addTab("Direct MCP", directPanel);

        JSplitPane split = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                new JBScrollPane(output),
                tabs
        );
        split.setResizeWeight(0.62);
        split.setDividerLocation(350);

        root.add(split, BorderLayout.CENTER);

        preview.addActionListener(e -> {
            String context = collect(project);
            output.setText(
                    context.isBlank()
                            ? "No IDE context found. Open a source file or select code."
                            : context
            );
        });

        ask.addActionListener(e -> {
            String question = input.getText().trim();

            if (question.isEmpty()) {
                output.setText("Enter a question first.");
                return;
            }

            refreshMode(modeLabel);

            var settings = EngineeringAiSettings.getInstance().getState();
            boolean direct = settings != null
                    && ("DIRECT_MCP".equalsIgnoreCase(settings.mode)
                    || !settings.llmEnabled);

            if (direct) {
                tabs.setSelectedIndex(1);
                output.setText(
                        "LLM is OFF / DIRECT_MCP is active.\n\n" +
                        "Use the Direct MCP tab:\n" +
                        "1. Refresh MCP Tools\n" +
                        "2. Select a tool\n" +
                        "3. Enter JSON arguments\n" +
                        "4. Run MCP Tool"
                );
                return;
            }

            String context = collect(project);

            runBackground(
                    output,
                    "Engineering AI is analyzing IDE context and available MCP knowledge/tools...",
                    () -> new AiOrchestrator().ask(question, context)
            );
        });

        refreshTools.addActionListener(e ->
                loadTools(output, toolCombo, toolDescription, toolArguments)
        );

        toolCombo.addActionListener(e ->
                renderSelectedTool(toolCombo, toolDescription, toolArguments)
        );

        runTool.addActionListener(e -> {
            String toolName = (String) toolCombo.getSelectedItem();

            if (toolName == null || toolName.isBlank()) {
                output.setText(
                        "No MCP tool selected. Click 'Refresh MCP Tools' first."
                );
                return;
            }

            String rawArgs = toolArguments.getText();

            runBackground(
                    output,
                    "Calling MCP tool: " + toolName + " ...",
                    () -> {
                        McpClient client = new McpClient();
                        return client.callToolAsText(
                                toolName,
                                client.parseArguments(rawArgs)
                        );
                    }
            );
        });

        Content content = ContentFactory.getInstance()
                .createContent(root, "", false);

        toolWindow.getContentManager().addContent(content);

        // Load tools lazily after the Tool Window is shown. Failure is non-fatal.
        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try {
                JsonArray tools = new McpClient().listTools();
                ApplicationManager.getApplication().invokeLater(
                        () -> applyTools(tools, toolCombo, toolDescription, toolArguments)
                );
            } catch (Exception ignored) {
                // The developer can click Refresh MCP Tools after configuring the URL.
            }
        });
    }

    private void loadTools(
            JBTextArea output,
            JComboBox<String> toolCombo,
            JBTextArea description,
            JBTextArea arguments
    ) {
        output.setText("Loading enabled MCP tools...");

        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            try {
                JsonArray tools = new McpClient().listTools();

                ApplicationManager.getApplication().invokeLater(() -> {
                    applyTools(tools, toolCombo, description, arguments);
                    output.setText(
                            "MCP tools loaded: " + tools.size() +
                            "\n\nOnly tools currently exposed by the MCP server are shown."
                    );
                });
            } catch (Exception ex) {
                String message = ex.getMessage();

                ApplicationManager.getApplication().invokeLater(() ->
                        output.setText(
                                "ERROR loading MCP tools\n\n" +
                                (message == null ? ex.toString() : message)
                        )
                );
            }
        });
    }

    private void applyTools(
            JsonArray tools,
            JComboBox<String> toolCombo,
            JBTextArea description,
            JBTextArea arguments
    ) {
        discoveredTools.clear();
        toolCombo.removeAllItems();

        for (JsonElement element : tools) {
            if (!element.isJsonObject()) continue;

            JsonObject tool = element.getAsJsonObject();
            if (!tool.has("name")) continue;

            String name = tool.get("name").getAsString();
            discoveredTools.put(name, tool);
            toolCombo.addItem(name);
        }

        if (toolCombo.getItemCount() == 0) {
            description.setText(
                    "MCP server returned no enabled tools."
            );
            arguments.setText("{}");
            return;
        }

        toolCombo.setSelectedIndex(0);
        renderSelectedTool(toolCombo, description, arguments);
    }

    private void renderSelectedTool(
            JComboBox<String> toolCombo,
            JBTextArea description,
            JBTextArea arguments
    ) {
        String name = (String) toolCombo.getSelectedItem();
        if (name == null) return;

        JsonObject tool = discoveredTools.get(name);
        if (tool == null) return;

        StringBuilder details = new StringBuilder(name);

        if (tool.has("description") && !tool.get("description").isJsonNull()) {
            details.append("\n\n").append(tool.get("description").getAsString());
        }

        description.setText(details.toString());

        McpClient client = new McpClient();
        arguments.setText(
                client.pretty(client.buildArgumentTemplate(tool))
        );
        arguments.setCaretPosition(0);
    }

    private String collect(Project project) {
        return IdeContextProvider.collect(project);
    }

    private void refreshMode(JLabel label) {
        var settings = EngineeringAiSettings.getInstance().getState();

        if (settings == null) {
            label.setText("Mode: ?");
            return;
        }

        label.setText(
                "Mode: " + settings.mode +
                " | LLM: " + (settings.llmEnabled ? "ON" : "OFF")
        );
    }

    private void runBackground(
            JBTextArea output,
            String loading,
            ThrowingSupplier supplier
    ) {
        output.setText(loading);

        ApplicationManager.getApplication().executeOnPooledThread(() -> {
            String result;

            try {
                result = supplier.get();
            } catch (Exception ex) {
                result = "ERROR\n\n" +
                        (ex.getMessage() == null ? ex.toString() : ex.getMessage());
            }

            String finalResult = result;

            ApplicationManager.getApplication().invokeLater(
                    () -> output.setText(finalResult)
            );
        });
    }

    @FunctionalInterface
    private interface ThrowingSupplier {
        String get() throws Exception;
    }
}
