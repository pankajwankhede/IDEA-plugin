package com.company.engineeringai.context;

import com.company.engineeringai.settings.EngineeringAiSettings;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileDocumentManager;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;

public final class IdeContextProvider {
    private IdeContextProvider() {}

    public static String collect(Project project) {
        EngineeringAiSettings.StateData s = EngineeringAiSettings.getInstance().getState();
        if (s == null) return "";

        Editor editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
        if (editor == null) return "";

        StringBuilder out = new StringBuilder();
        VirtualFile file = FileDocumentManager.getInstance().getFile(editor.getDocument());
        if (file != null && s.includeCurrentFile) {
            out.append("\n\n### CURRENT_FILE: ").append(file.getPath()).append("\n");
            String text = editor.getDocument().getText();
            if (text.length() > 30000) text = text.substring(0, 30000) + "\n...[truncated]";
            out.append(text);
        }

        if (s.includeSelectedCode) {
            String selected = editor.getSelectionModel().getSelectedText();
            if (selected != null && !selected.isBlank()) {
                out.append("\n\n### SELECTED_CODE\n").append(selected);
            }
        }
        return out.toString();
    }
}
