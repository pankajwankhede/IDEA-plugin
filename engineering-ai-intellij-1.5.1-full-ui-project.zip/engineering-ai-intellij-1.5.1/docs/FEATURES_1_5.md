# Engineering AI IntelliJ 1.5.0 — Full UI implementation

This release implements the real Swing/IntelliJ UI to closely match the approved mockups rather than merely bundling reference images.

## Implemented UI

- Branded Engineering AI header with LLM ON/OFF toggle and Settings button.
- Dynamic integration pills derived from MCP `tools/list`.
- AI Chat page with source selection, natural-language prompt, quick actions, review/framework/rules selectors, LLM + MCP action, auto-used MCP tools, helpful prompts, and result tabs.
- MCP Tools page with numbered workflow, source selection, review type, JSON options, How it works, selected-folder preview, prominent Run button, raw result, and findings summary.
- Knowledge Base with searchable three-pane browser for Agents, Skills, Instructions, Scripts, and Shared Docs.
- History with search, prior prompts/tool calls, source, and result details.
- Local Selected Code / Current File / Choose File / Choose Folder support.
- Folder preview of supported source/config files.
- Dark card styling, blue primary actions, status pills, step accents, and structured layout inspired by the approved mockups.

## Important behavior

The interface is functional, not a static image. It calls the existing `McpClient`, `AiOrchestrator`, settings, IDE context provider, and history service.

Unavailable integrations remain hidden from the normal experience because feature visibility is inferred from MCP `tools/list`.
