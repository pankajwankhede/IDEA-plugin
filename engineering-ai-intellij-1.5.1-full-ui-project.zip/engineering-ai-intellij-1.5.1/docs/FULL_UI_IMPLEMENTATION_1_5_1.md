# Engineering AI 1.5.1 – Full UI Implementation

This release implements the approved UI direction as real IntelliJ Swing components rather than embedding the reference image.

## Implemented views

- Header with Engineering AI branding, LLM ON/OFF, active LLM model/gateway display, Settings, and dynamic MCP capability badges.
- AI Chat with left engineering-action rail, source selection, natural-language prompt, review/framework/rule selectors, MCP knowledge option, right-side MCP/context/help panels, and result tabs.
- Direct MCP with numbered workflow, tool discovery, local source selection, review type, JSON options, help card, folder preview, raw results, and summarized findings.
- Knowledge Base with browse tree, item list, detail tabs, search, copy/use-in-chat actions, and dynamic `list_*` / `get_*` MCP integration.
- History with search, persisted prior requests, details, copy, refresh, and clear.
- Dynamic feature visibility from MCP `tools/list`; unavailable integrations do not create active feature surfaces.

## Important runtime behavior

The UI is implemented in the plugin. Actual data remains dependent on the external services:

- MCP tools come from the configured MCP server.
- Knowledge Base content comes through MCP; the plugin does not access Bitbucket directly.
- LLM Chat requires an approved LLM gateway configuration.
- Local source review without LLM requires an MCP tool whose `inputSchema` accepts a code/context field (for example `review_local_code`).

## Reference

See `docs/images/approved-full-ui-1.5.1.png`.
