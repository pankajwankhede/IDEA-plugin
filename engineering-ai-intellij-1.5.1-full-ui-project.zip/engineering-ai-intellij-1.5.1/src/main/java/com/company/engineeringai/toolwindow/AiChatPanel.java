package com.company.engineeringai.toolwindow;

import com.company.engineeringai.mcp.McpCapabilities;
import com.company.engineeringai.orchestrator.AiOrchestrator;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.intellij.openapi.project.Project;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public final class AiChatPanel extends JPanel {
    private final AiOrchestrator orchestrator = new AiOrchestrator();
    private final SourceSelectorPanel sourceSelector;
    private final JTextArea promptArea = UiSupport.textArea(6, true);
    private final JComboBox<String> reviewType = new JComboBox<>(new String[]{"Security Review", "Code Review", "Debug & Fix", "Performance", "Refactor", "Unit Tests", "General"});
    private final JComboBox<String> framework = new JComboBox<>(new String[]{"Spring Boot", "Java", "Kotlin", "SQL", "Frontend", "Auto Detect"});
    private final JComboBox<String> includeRules = new JComboBox<>(new String[]{"OWASP Top 10", "Best Practices", "Coding Standards", "None"});
    private final JCheckBox useKnowledge = new JCheckBox("Use MCP Knowledge Base", true);
    private final JButton sendButton = UiSupport.primaryButton("✈  Send to AI (LLM + MCP)");
    private final JLabel llmDisabled = UiSupport.pill("LLM is OFF — enable it in the header", UiSupport.RED.darker());
    private final JTextArea responseArea = UiSupport.textArea(18, false);
    private final JTextArea findingsArea = UiSupport.textArea(18, false);
    private final JTextArea suggestionsArea = UiSupport.textArea(18, false);
    private final JTextArea relatedArea = UiSupport.textArea(18, false);
    private final JLabel status = UiSupport.muted("Ready");
    private final JPanel mcpAutoPanel = UiSupport.card();
    private final JPanel selectedFilesPanel = UiSupport.card();
    private McpCapabilities capabilities;

    public AiChatPanel(Project project) {
        super(new BorderLayout(10, 10)); setBackground(UiSupport.BG); setBorder(new EmptyBorder(10,10,10,10)); sourceSelector = new SourceSelectorPanel(project);
        UiSupport.styleCombo(reviewType); UiSupport.styleCombo(framework); UiSupport.styleCombo(includeRules); UiSupport.styleToggle(useKnowledge);

        JPanel center = new JPanel(); center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS)); center.setOpaque(false);
        JPanel source = UiSupport.card(); source.add(UiSupport.section("1", "Select Source (What code to analyze?)"), BorderLayout.NORTH); source.add(sourceSelector, BorderLayout.CENTER); center.add(source); center.add(Box.createVerticalStrut(8));

        JPanel prompt = UiSupport.card(); prompt.add(UiSupport.section("2", "Your Prompt (Natural language)"), BorderLayout.NORTH); promptArea.setText("Review this Java code for security vulnerabilities and suggest best practices for Spring Boot. Also check for OWASP Top 10 issues and give improvement suggestions."); prompt.add(UiSupport.scroll(promptArea), BorderLayout.CENTER);
        JButton explain = UiSupport.ghostButton("Explain Code"), issues = UiSupport.ghostButton("Find Issues"), refactor = UiSupport.ghostButton("Refactor"), tests = UiSupport.ghostButton("Generate Tests");
        explain.addActionListener(e->{reviewType.setSelectedItem("General");promptArea.setText("Explain this code clearly, including responsibilities, data flow, dependencies, edge cases, and production concerns.");});
        issues.addActionListener(e->{reviewType.setSelectedItem("Security Review");promptArea.setText("Review this code for security vulnerabilities, correctness issues, risky patterns, and production-readiness problems. Prioritize fixes.");});
        refactor.addActionListener(e->{reviewType.setSelectedItem("Refactor");promptArea.setText("Refactor this code for readability, maintainability, testability, and clean design while preserving behavior.");});
        tests.addActionListener(e->{reviewType.setSelectedItem("Unit Tests");promptArea.setText("Generate a focused unit-test plan, including success, failure, boundary, and security cases.");});
        prompt.add(UiSupport.row(new JLabel("Quick Actions:"), explain, issues, refactor, tests), BorderLayout.SOUTH); center.add(prompt); center.add(Box.createVerticalStrut(8));

        JPanel advanced = UiSupport.card(); advanced.add(UiSupport.section("3", "Advanced Options (Optional)"), BorderLayout.NORTH);
        advanced.add(UiSupport.row(new JLabel("Review Type"), reviewType, new JLabel("Framework"), framework, new JLabel("Include Rules"), includeRules, useKnowledge), BorderLayout.CENTER); advanced.add(sendButton, BorderLayout.SOUTH); center.add(advanced); center.add(Box.createVerticalStrut(5)); center.add(status); center.add(Box.createVerticalStrut(5)); center.add(llmDisabled);

        mcpAutoPanel.add(UiSupport.title("MCP Tools (Auto-used by AI)"), BorderLayout.NORTH); mcpAutoPanel.add(UiSupport.muted("No MCP capabilities discovered yet"), BorderLayout.CENTER);
        selectedFilesPanel.add(UiSupport.title("Selected Files"), BorderLayout.NORTH); selectedFilesPanel.add(UiSupport.muted(sourceSelector.describeSource()), BorderLayout.CENTER);
        JPanel helpful = UiSupport.card(); helpful.add(UiSupport.title("Helpful Prompts"), BorderLayout.NORTH); JTextArea h=UiSupport.textArea(10,false); h.setText("› Review for performance issues\n\n› Check for input validation\n\n› Suggest refactoring\n\n› Add unit tests\n\n› Explain this code\n\n› Find similar code in project"); helpful.add(UiSupport.scroll(h),BorderLayout.CENTER);
        JPanel right=new JPanel();right.setLayout(new BoxLayout(right,BoxLayout.Y_AXIS));right.setOpaque(false);right.add(mcpAutoPanel);right.add(Box.createVerticalStrut(8));right.add(selectedFilesPanel);right.add(Box.createVerticalStrut(8));right.add(helpful);

        // Left action rail mirrors the approved mockup while remaining native Swing.
        JPanel actionRail = UiSupport.card();
        actionRail.setLayout(new BoxLayout(actionRail, BoxLayout.Y_AXIS));
        actionRail.add(UiSupport.title("Engineering Actions"));
        actionRail.add(Box.createVerticalStrut(8));
        JButton analyze = UiSupport.primaryButton("Analyze Code");
        JButton explainRail = UiSupport.ghostButton("Explain Code");
        JButton generate = UiSupport.ghostButton("Generate Code");
        JButton debug = UiSupport.ghostButton("Debug & Fix");
        JButton codeReview = UiSupport.ghostButton("Code Review");
        JButton securityScan = UiSupport.ghostButton("Security Scan");
        JButton searchDocs = UiSupport.ghostButton("Search Docs");
        JButton architecture = UiSupport.ghostButton("Architecture Help");
        JButton refactorRail = UiSupport.ghostButton("Refactor");
        JButton unitTest = UiSupport.ghostButton("Unit Test");
        for (JButton b : new JButton[]{analyze, explainRail, generate, debug, codeReview, securityScan, searchDocs, architecture, refactorRail, unitTest}) {
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
            actionRail.add(b);
            actionRail.add(Box.createVerticalStrut(6));
        }
        analyze.addActionListener(e->{reviewType.setSelectedItem("Code Review"); promptArea.setText("Analyze this code for correctness, maintainability, production risks, and improvement opportunities.");});
        explainRail.addActionListener(e->explain.doClick());
        generate.addActionListener(e->{reviewType.setSelectedItem("General");promptArea.setText("Generate production-ready code for the requested behavior. Follow existing project patterns and engineering standards.");});
        debug.addActionListener(e->{reviewType.setSelectedItem("Debug & Fix");promptArea.setText("Debug this code, identify the root cause of failures, and provide the safest minimal fix with explanation.");});
        codeReview.addActionListener(e->{reviewType.setSelectedItem("Code Review");promptArea.setText("Perform a detailed code review covering correctness, maintainability, design, testing, and production-readiness.");});
        securityScan.addActionListener(e->issues.doClick());
        searchDocs.addActionListener(e->{reviewType.setSelectedItem("General");promptArea.setText("Find and apply relevant centralized engineering documentation, standards, skills, and instructions for this code.");});
        architecture.addActionListener(e->{reviewType.setSelectedItem("General");promptArea.setText("Review the architecture and design of this code. Identify coupling, scalability, resilience, security, and maintainability concerns.");});
        refactorRail.addActionListener(e->refactor.doClick());
        unitTest.addActionListener(e->tests.doClick());

        JSplitPane centerRight=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,UiSupport.scroll(center),UiSupport.scroll(right));
        centerRight.setResizeWeight(.74);centerRight.setBorder(BorderFactory.createEmptyBorder());
        JSplitPane formSplit=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,UiSupport.scroll(actionRail),centerRight);
        formSplit.setResizeWeight(.16);formSplit.setBorder(BorderFactory.createEmptyBorder());

        JTabbedPane resultTabs=new JTabbedPane(); resultTabs.addTab("AI Response",UiSupport.scroll(responseArea)); resultTabs.addTab("Findings",UiSupport.scroll(findingsArea)); resultTabs.addTab("Suggestions",UiSupport.scroll(suggestionsArea)); resultTabs.addTab("Related Docs",UiSupport.scroll(relatedArea));
        JSplitPane main=new JSplitPane(JSplitPane.VERTICAL_SPLIT,formSplit,resultTabs);main.setResizeWeight(.66);main.setBorder(BorderFactory.createEmptyBorder());add(main,BorderLayout.CENTER);
        sendButton.addActionListener(e->runAsk()); refreshLlmState();
    }

    public void setCapabilities(McpCapabilities c) { capabilities=c; useKnowledge.setVisible(c!=null&&c.knowledge()); refreshMcpPanel(); }
    public void refreshLlmState() { var s=EngineeringAiSettings.getInstance().getState(); boolean enabled=s!=null&&s.llmEnabled; sendButton.setEnabled(enabled); promptArea.setEnabled(enabled); llmDisabled.setVisible(!enabled); status.setText(enabled?"Ready":"LLM disabled — use MCP Tools for direct calls."); }

    private void refreshMcpPanel() {
        mcpAutoPanel.removeAll(); mcpAutoPanel.add(UiSupport.title("MCP Tools (Auto-used by AI)"),BorderLayout.NORTH); JPanel list=new JPanel();list.setLayout(new BoxLayout(list,BoxLayout.Y_AXIS));list.setOpaque(false);
        if(capabilities==null||capabilities.toolNames().isEmpty()) list.add(UiSupport.muted("No tools discovered yet")); else for(String t:capabilities.toolNames()) if(t.contains("search")||t.startsWith("get_")||t.startsWith("list_")) list.add(UiSupport.label("✓  "+t,UiSupport.GREEN));
        mcpAutoPanel.add(list,BorderLayout.CENTER); mcpAutoPanel.revalidate();mcpAutoPanel.repaint();
    }

    private void runAsk() {
        String p=promptArea.getText()==null?"":promptArea.getText().trim(); if(p.isBlank()){JOptionPane.showMessageDialog(this,"Enter a prompt first.","Engineering AI",JOptionPane.WARNING_MESSAGE);return;}
        sendButton.setEnabled(false);status.setText("Collecting local context and analyzing...");responseArea.setText("");findingsArea.setText("");suggestionsArea.setText("");relatedArea.setText("");
        SwingWorker<String,Void>w=new SwingWorker<>(){private String src;@Override protected String doInBackground()throws Exception{String context=sourceSelector.collectContext();src=sourceSelector.describeSource();return orchestrator.ask(buildPrompt(p),context);}@Override protected void done(){try{String r=get();responseArea.setText(r);findingsArea.setText(extractLines(r,List.of("issue","risk","vulnerab","finding","high","medium","low")));suggestionsArea.setText(extractLines(r,List.of("recommend","suggest","improve","should","fix","use ")));relatedArea.setText(capabilities!=null&&capabilities.knowledge()?"MCP Knowledge Base was available. Enabled sources: "+String.join(", ",capabilities.enabledSources()):"No centralized MCP Knowledge Base available.");EngineeringAiHistoryService.getInstance().add(new EngineeringAiHistoryService.HistoryEntry("AI Chat",summarize(p),p,src,r));status.setText("✓ Completed");}catch(Exception ex){responseArea.setText("AI request failed:\n\n"+UiSupport.safe(ex));status.setText("Failed");}finally{refreshLlmState();}}};w.execute();
    }

    private String buildPrompt(String p){return p+"\n\nReview type: "+reviewType.getSelectedItem()+"\nFramework: "+framework.getSelectedItem()+"\nRules: "+includeRules.getSelectedItem()+(useKnowledge.isSelected()?"\nUse relevant centralized MCP knowledge and engineering standards when available.":"");}
    private static String summarize(String p){String x=p.replaceAll("\\s+"," ").trim();return x.length()>70?x.substring(0,70)+"…":x;}
    private static String extractLines(String result,List<String>terms){if(result==null||result.isBlank())return"No structured items detected. See AI Response.";List<String>m=new ArrayList<>();for(String line:result.split("\\R")){String l=line.toLowerCase();for(String t:terms)if(l.contains(t)){m.add(line);break;}}return m.isEmpty()?"No structured items detected. See AI Response.":String.join("\n",m);}
}
