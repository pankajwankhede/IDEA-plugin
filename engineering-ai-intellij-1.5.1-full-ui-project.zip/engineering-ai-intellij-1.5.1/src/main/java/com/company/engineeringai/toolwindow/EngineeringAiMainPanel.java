package com.company.engineeringai.toolwindow;

import com.company.engineeringai.mcp.McpCapabilities;
import com.company.engineeringai.settings.EngineeringAiSettings;
import com.intellij.openapi.options.ShowSettingsUtil;
import com.intellij.openapi.project.Project;
import com.google.gson.JsonArray;

import javax.swing.*;
import java.awt.*;

public final class EngineeringAiMainPanel extends JPanel {
    private final Project project;
    private final JToggleButton llmToggle = new JToggleButton("LLM OFF");
    private final JLabel modeLabel = UiSupport.subtitle("");
    private final JComboBox<String> gatewayCombo = new JComboBox<>();
    private final IntegrationStatusPanel integrationStatus = new IntegrationStatusPanel();
    private final JTabbedPane tabs = new JTabbedPane();
    private final AiChatPanel aiChatPanel;
    private final McpToolsPanel mcpToolsPanel;
    private final KnowledgeBasePanel knowledgeBasePanel;
    private final HistoryPanel historyPanel = new HistoryPanel();
    private McpCapabilities capabilities = new McpCapabilities(new JsonArray());

    public EngineeringAiMainPanel(Project project) {
        super(new BorderLayout(0, 10)); this.project = project; setBackground(UiSupport.BG); setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        aiChatPanel = new AiChatPanel(project); mcpToolsPanel = new McpToolsPanel(project, this::setCapabilities); knowledgeBasePanel = new KnowledgeBasePanel(project, this::setCapabilities);
        add(buildHeader(), BorderLayout.NORTH);
        tabs.setBackground(UiSupport.BG); tabs.setForeground(UiSupport.TEXT);
        tabs.addTab("AI Chat (LLM)", aiChatPanel); tabs.addTab("MCP Tools", mcpToolsPanel); tabs.addTab("Knowledge Base", knowledgeBasePanel); tabs.addTab("History", historyPanel);
        tabs.addChangeListener(e -> { if (tabs.getSelectedComponent() == historyPanel) historyPanel.reload(); }); add(tabs, BorderLayout.CENTER);
        refreshHeaderFromSettings(); setCapabilities(capabilities);
    }

    private JComponent buildHeader() {
        JPanel outer = UiSupport.card();
        JPanel top = new JPanel(new BorderLayout(14, 0)); top.setOpaque(false);
        JPanel title = new JPanel(); title.setLayout(new BoxLayout(title, BoxLayout.Y_AXIS)); title.setOpaque(false);
        JLabel brand = UiSupport.title("✦  Engineering AI"); title.add(brand); title.add(UiSupport.subtitle("Your AI assistant for secure, high-quality, production-ready code")); title.add(Box.createVerticalStrut(3)); title.add(modeLabel); top.add(title, BorderLayout.WEST);
        JButton settings = UiSupport.ghostButton("⚙ Settings"); settings.addActionListener(e -> ShowSettingsUtil.getInstance().showSettingsDialog(project, "Engineering AI"));
        UiSupport.styleToggle(llmToggle); llmToggle.addActionListener(e -> toggleLlm());
        UiSupport.styleCombo(gatewayCombo); gatewayCombo.setFocusable(false); gatewayCombo.setPrototypeDisplayValue("Using: Corporate LLM Gateway");
        top.add(UiSupport.row(llmToggle, gatewayCombo, settings), BorderLayout.EAST);
        outer.add(top, BorderLayout.NORTH); outer.add(integrationStatus, BorderLayout.SOUTH); return outer;
    }

    private void toggleLlm() {
        var s = EngineeringAiSettings.getInstance().getState(); if (s == null) return;
        s.llmEnabled = llmToggle.isSelected(); s.mode = s.llmEnabled ? "AUTO" : "DIRECT_MCP"; refreshHeaderFromSettings(); aiChatPanel.refreshLlmState();
        tabs.setSelectedComponent(s.llmEnabled ? aiChatPanel : mcpToolsPanel);
    }

    private void refreshHeaderFromSettings() {
        var s = EngineeringAiSettings.getInstance().getState(); boolean llm = s != null && s.llmEnabled; llmToggle.setSelected(llm); llmToggle.setText(llm ? "LLM: ON" : "LLM: OFF");
        llmToggle.setBackground(llm ? UiSupport.BLUE : UiSupport.SURFACE_2); llmToggle.setForeground(Color.WHITE);
        String mode = s == null || s.mode == null ? "AUTO" : s.mode; modeLabel.setText("Mode: " + mode + (llm ? "  •  LLM + MCP orchestration" : "  •  Direct MCP tools only"));
        gatewayCombo.removeAllItems();
        String model = s == null || s.llmModel == null || s.llmModel.isBlank() ? "Corporate LLM Gateway" : s.llmModel;
        gatewayCombo.addItem("Using: " + model);
        gatewayCombo.setEnabled(llm);
    }

    public void setCapabilities(McpCapabilities capabilities) {
        this.capabilities = capabilities == null ? new McpCapabilities(new JsonArray()) : capabilities; integrationStatus.update(this.capabilities); aiChatPanel.setCapabilities(this.capabilities); knowledgeBasePanel.setCapabilities(this.capabilities); updateKnowledgeTabVisibility();
    }

    private void updateKnowledgeTabVisibility() {
        boolean available = capabilities.knowledge(); int idx = indexOfComponent(knowledgeBasePanel);
        if (available && idx < 0) { int h = indexOfComponent(historyPanel); tabs.insertTab("Knowledge Base", null, knowledgeBasePanel, "Browse shared agents, skills, instructions and docs", Math.max(0, h)); }
        else if (!available && idx >= 0) { if (tabs.getSelectedComponent() == knowledgeBasePanel) tabs.setSelectedComponent(mcpToolsPanel); tabs.remove(knowledgeBasePanel); }
    }

    private int indexOfComponent(Component c) { for (int i=0;i<tabs.getTabCount();i++) if (tabs.getComponentAt(i)==c) return i; return -1; }
}
