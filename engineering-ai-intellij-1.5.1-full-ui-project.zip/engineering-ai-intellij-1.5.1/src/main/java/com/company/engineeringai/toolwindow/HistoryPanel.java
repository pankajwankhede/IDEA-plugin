package com.company.engineeringai.toolwindow;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import java.awt.*;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public final class HistoryPanel extends JPanel {
    private final DefaultListModel<EngineeringAiHistoryService.HistoryEntry> model = new DefaultListModel<>();
    private final JList<EngineeringAiHistoryService.HistoryEntry> list = new JList<>(model);
    private final JTextArea details = UiSupport.textArea(24, false);
    private final JTextField search = UiSupport.textField();
    private final JButton refresh = UiSupport.ghostButton("↻ Refresh");
    private final JButton clear = UiSupport.ghostButton("Clear History");
    private final JButton copy = UiSupport.ghostButton("Copy Result");

    public HistoryPanel() {
        super(new BorderLayout(10,10)); setBackground(UiSupport.BG); setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        UiSupport.styleList(list);
        list.setCellRenderer(new DefaultListCellRenderer(){@Override public Component getListCellRendererComponent(JList<?> l,Object v,int i,boolean s,boolean f){EngineeringAiHistoryService.HistoryEntry e=(EngineeringAiHistoryService.HistoryEntry)v;String when=e.timestamp;try{when=DateTimeFormatter.ofPattern("MMM d, HH:mm").withZone(ZoneId.systemDefault()).format(Instant.parse(e.timestamp));}catch(Exception ignored){}return super.getListCellRendererComponent(l,"▣  "+e.title+"   •   "+e.mode+"   •   "+when,i,s,f);}});
        JPanel header=UiSupport.card();header.add(UiSupport.title("History"),BorderLayout.WEST);JPanel tools=new JPanel(new BorderLayout(8,0));tools.setOpaque(false);search.setToolTipText("Search history");tools.add(search,BorderLayout.CENTER);tools.add(UiSupport.row(refresh,clear),BorderLayout.EAST);header.add(tools,BorderLayout.CENTER);add(header,BorderLayout.NORTH);
        JPanel left=UiSupport.card();left.add(UiSupport.title("Previous prompts and results"),BorderLayout.NORTH);left.add(UiSupport.scroll(list),BorderLayout.CENTER);
        JPanel right=UiSupport.card();right.add(UiSupport.title("Details"),BorderLayout.NORTH);right.add(UiSupport.scroll(details),BorderLayout.CENTER);right.add(copy,BorderLayout.SOUTH);
        JSplitPane split=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,left,right);split.setResizeWeight(.42);split.setBorder(BorderFactory.createEmptyBorder());add(split,BorderLayout.CENTER);
        refresh.addActionListener(e->reload());clear.addActionListener(e->{EngineeringAiHistoryService.getInstance().clear();reload();});copy.addActionListener(e->{details.selectAll();details.copy();details.select(0,0);});search.addActionListener(e->filter());list.addListSelectionListener(this::selectionChanged);reload();
    }
    public void reload(){populate("");}
    private void filter(){populate(search.getText()==null?"":search.getText().trim().toLowerCase());}
    private void populate(String q){model.clear();for(var e:EngineeringAiHistoryService.getInstance().entries()){String all=(e.title+" "+e.mode+" "+e.prompt+" "+e.source).toLowerCase();if(q.isBlank()||all.contains(q))model.addElement(e);}if(!model.isEmpty())list.setSelectedIndex(0);else details.setText("No history yet. AI Chat, Direct MCP, and Knowledge Base searches will appear here.");}
    private void selectionChanged(ListSelectionEvent e){if(e.getValueIsAdjusting())return;var x=list.getSelectedValue();if(x==null)return;details.setText("TITLE\n"+x.title+"\n\nMODE\n"+x.mode+"\n\nSOURCE\n"+x.source+"\n\nPROMPT / ARGUMENTS\n"+x.prompt+"\n\nRESULT\n"+x.result);details.setCaretPosition(0);}
}
