package com.company.engineeringai.toolwindow;

import com.company.engineeringai.mcp.McpCapabilities;
import com.company.engineeringai.mcp.McpClient;
import com.google.gson.*;
import com.intellij.openapi.project.Project;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

public final class McpToolsPanel extends JPanel {
    private final McpClient mcp = new McpClient();
    private final JComboBox<String> toolCombo = new JComboBox<>();
    private final JButton refreshButton = UiSupport.ghostButton("↻ Refresh MCP Tools");
    private final JTextArea toolDescription = UiSupport.textArea(3, false);
    private final JTextArea argumentsArea = UiSupport.textArea(10, true);
    private final JTextArea resultArea = UiSupport.textArea(16, false);
    private final JCheckBox attachLocal = new JCheckBox("Attach local source when tool schema supports code/context", true);
    private final SourceSelectorPanel sourceSelector;
    private final JButton runButton = UiSupport.primaryButton("▶  Run MCP Tool");
    private final JLabel status = UiSupport.muted("Not connected");
    private final JLabel high = UiSupport.pill("0 High", UiSupport.RED.darker());
    private final JLabel medium = UiSupport.pill("0 Medium", new Color(170, 112, 20));
    private final JLabel low = UiSupport.pill("0 Low", new Color(31, 120, 75));
    private final JTextArea findings = UiSupport.textArea(9, false);
    private final JPanel previewHost = UiSupport.card();
    private final Map<String, JsonObject> tools = new LinkedHashMap<>();
    private final Consumer<McpCapabilities> capabilitiesConsumer;

    public McpToolsPanel(Project project, Consumer<McpCapabilities> capabilitiesConsumer) {
        super(new BorderLayout(10, 10)); this.capabilitiesConsumer = capabilitiesConsumer; this.sourceSelector = new SourceSelectorPanel(project);
        setBackground(UiSupport.BG); setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel selectorCard = UiSupport.card(); selectorCard.add(UiSupport.section("1", "Select MCP Tool"), BorderLayout.NORTH);
        JPanel selectorRow = new JPanel(new BorderLayout(8, 0)); selectorRow.setOpaque(false); UiSupport.styleCombo(toolCombo); selectorRow.add(toolCombo, BorderLayout.CENTER); selectorRow.add(refreshButton, BorderLayout.EAST);
        selectorCard.add(selectorRow, BorderLayout.CENTER); selectorCard.add(UiSupport.scroll(toolDescription), BorderLayout.SOUTH);

        JPanel sourceCard = UiSupport.card(); sourceCard.add(UiSupport.section("2", "Select Source"), BorderLayout.NORTH);
        UiSupport.styleToggle(attachLocal); JPanel sourceBody = new JPanel(new BorderLayout(6, 6)); sourceBody.setOpaque(false); sourceBody.add(sourceSelector, BorderLayout.CENTER); sourceBody.add(attachLocal, BorderLayout.SOUTH); sourceCard.add(sourceBody, BorderLayout.CENTER);

        JComboBox<String> reviewType = new JComboBox<>(new String[]{"Security", "Code Quality", "Spring Security", "Performance", "Custom Rules"}); UiSupport.styleCombo(reviewType);
        JPanel reviewCard = UiSupport.card(); reviewCard.add(UiSupport.section("3", "Review Type"), BorderLayout.NORTH); reviewCard.add(reviewType, BorderLayout.CENTER);

        JPanel argsCard = UiSupport.card(); argsCard.add(UiSupport.section("4", "Additional Options (JSON)"), BorderLayout.NORTH); argsCard.add(UiSupport.scroll(argumentsArea), BorderLayout.CENTER);
        JTextArea common = UiSupport.textArea(7, false); common.setText("Common Options\n\nSecurity Review\n{ \"reviewType\": \"security\" }\n\nCode Quality\n{ \"reviewType\": \"code-quality\" }");
        JSplitPane argsSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, UiSupport.scroll(argumentsArea), UiSupport.scroll(common)); argsSplit.setResizeWeight(.68); argsSplit.setBorder(BorderFactory.createEmptyBorder()); argsCard.removeAll(); argsCard.add(UiSupport.section("4", "Additional Options (JSON)"), BorderLayout.NORTH); argsCard.add(argsSplit, BorderLayout.CENTER);

        JPanel left = new JPanel(); left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS)); left.setOpaque(false); left.add(selectorCard); left.add(Box.createVerticalStrut(8)); left.add(sourceCard); left.add(Box.createVerticalStrut(8)); left.add(reviewCard); left.add(Box.createVerticalStrut(8)); left.add(argsCard); left.add(Box.createVerticalStrut(8)); left.add(runButton); left.add(Box.createVerticalStrut(4)); left.add(status);

        JPanel help = UiSupport.card(); help.add(UiSupport.title("💡 How it works"), BorderLayout.NORTH);
        JTextArea helpText = UiSupport.textArea(8, false); helpText.setText("1  Select the MCP tool\n\n2  Choose source (code, file, or folder)\n\n3  Set review type and options\n\n4  Click Run MCP Tool\n\n5  View results and findings"); help.add(UiSupport.scroll(helpText), BorderLayout.CENTER);
        previewHost.add(UiSupport.title("📁 Selected Folder Preview"), BorderLayout.NORTH); previewHost.add(UiSupport.muted("Choose Folder to preview files"), BorderLayout.CENTER);
        JPanel right = new JPanel(); right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS)); right.setOpaque(false); right.add(help); right.add(Box.createVerticalStrut(8)); right.add(previewHost);

        JSplitPane top = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, UiSupport.scroll(left), UiSupport.scroll(right)); top.setResizeWeight(.72); top.setBorder(BorderFactory.createEmptyBorder());

        JPanel resultCard = UiSupport.card(); resultCard.add(UiSupport.title("MCP Tool Result"), BorderLayout.NORTH);
        JTabbedPane resultTabs = new JTabbedPane(); resultTabs.addTab("Raw Result", UiSupport.scroll(resultArea));
        JPanel summaryPanel = new JPanel(new BorderLayout(8,8)); summaryPanel.setOpaque(false); summaryPanel.add(UiSupport.row(high, medium, low), BorderLayout.NORTH); summaryPanel.add(UiSupport.scroll(findings), BorderLayout.CENTER); resultTabs.addTab("Summary / Findings", summaryPanel); resultCard.add(resultTabs, BorderLayout.CENTER);

        JSplitPane main = new JSplitPane(JSplitPane.VERTICAL_SPLIT, top, resultCard); main.setResizeWeight(.64); main.setBorder(BorderFactory.createEmptyBorder()); add(main, BorderLayout.CENTER);

        refreshButton.addActionListener(e -> refreshTools()); toolCombo.addActionListener(e -> toolChanged()); runButton.addActionListener(e -> runTool());
        attachLocal.addActionListener(e -> refreshPreview()); reviewType.addActionListener(e -> injectReviewType((String) reviewType.getSelectedItem()));
        refreshTools();
    }

    private void refreshTools() {
        refreshButton.setEnabled(false); status.setText("Discovering MCP tools...");
        SwingWorker<JsonArray, Void> worker = new SwingWorker<>() {
            @Override protected JsonArray doInBackground() throws Exception { return mcp.listTools(); }
            @Override protected void done() {
                try { JsonArray arr = get(); tools.clear(); toolCombo.removeAllItems(); for (JsonElement e:arr) if (e.isJsonObject()) { JsonObject t=e.getAsJsonObject(); if (t.has("name")) { String n=t.get("name").getAsString(); tools.put(n,t); toolCombo.addItem(n); } }
                    if (capabilitiesConsumer != null) capabilitiesConsumer.accept(new McpCapabilities(arr)); status.setText(tools.size()+" MCP tools available"); if (toolCombo.getItemCount()>0) toolCombo.setSelectedIndex(0);
                } catch (Exception ex) { resultArea.setText("Unable to load MCP tools.\n\n"+UiSupport.safe(ex)); status.setText("MCP unavailable"); }
                finally { refreshButton.setEnabled(true); }
            }
        }; worker.execute();
    }

    private void toolChanged() {
        String n=(String)toolCombo.getSelectedItem(); JsonObject t=n==null?null:tools.get(n); if (t==null) return;
        toolDescription.setText(n+"\n\n"+(t.has("description")?t.get("description").getAsString():"No description provided by MCP server."));
        argumentsArea.setText(mcp.pretty(mcp.buildArgumentTemplate(t))); String contextField=findContextField(t); attachLocal.setEnabled(contextField!=null); if (contextField==null) attachLocal.setSelected(false); refreshPreview();
    }

    private void injectReviewType(String type) {
        try { JsonObject obj=mcp.parseArguments(argumentsArea.getText()); if (obj.has("reviewType") || (type!=null && tools.containsKey("review_local_code"))) { obj.addProperty("reviewType", normalizeType(type)); argumentsArea.setText(mcp.pretty(obj)); } } catch (Exception ignored) {}
    }
    private static String normalizeType(String t) { if (t==null) return "security"; return t.toLowerCase().replace(' ','-'); }

    private void refreshPreview() {
        previewHost.removeAll(); previewHost.add(UiSupport.title("📁 Selected Folder Preview"), BorderLayout.NORTH);
        if (sourceSelector.choice()==SourceSelectorPanel.SourceChoice.CHOOSE_FOLDER && sourceSelector.selectedPath()!=null) previewHost.add(UiSupport.scroll(sourceSelector.buildPreviewTree()), BorderLayout.CENTER);
        else previewHost.add(UiSupport.muted(sourceSelector.describeSource()), BorderLayout.CENTER); previewHost.revalidate(); previewHost.repaint();
    }

    private void runTool() {
        String name=(String)toolCombo.getSelectedItem(); JsonObject tool=name==null?null:tools.get(name); if (name==null||tool==null) return; runButton.setEnabled(false); status.setText("Running "+name+"..."); resultArea.setText(""); findings.setText("");
        SwingWorker<String, Void> worker = new SwingWorker<>() {
            private String sourceDescription="";
            @Override protected String doInBackground() throws Exception { JsonObject args=mcp.parseArguments(argumentsArea.getText()); String cf=findContextField(tool); if (attachLocal.isSelected()&&cf!=null) { String ctx=sourceSelector.collectContext(); sourceDescription=sourceSelector.describeSource(); args.addProperty(cf,ctx); } return mcp.callToolAsText(name,args); }
            @Override protected void done() { try { String result=get(); resultArea.setText(result); resultArea.setCaretPosition(0); summarizeResult(result); status.setText("✓ Completed"); EngineeringAiHistoryService.getInstance().add(new EngineeringAiHistoryService.HistoryEntry("Direct MCP",name,argumentsArea.getText(),sourceDescription,result)); } catch(Exception ex){ resultArea.setText("MCP tool failed\n\nException: "+ex.getClass().getName()+"\n\n"+UiSupport.safe(ex)); status.setText("Failed"); } finally { runButton.setEnabled(true); } }
        }; worker.execute();
    }

    private void summarizeResult(String result) {
        int h=0,m=0,l=0; StringBuilder f=new StringBuilder(); if(result!=null) for(String line:result.split("\\R")){String x=line.toLowerCase(); if(x.contains("high")){h++;f.append("• ").append(line).append('\n');} else if(x.contains("medium")){m++;f.append("• ").append(line).append('\n');} else if(x.contains("low")){l++;f.append("• ").append(line).append('\n');} else if(x.contains("issue")||x.contains("risk")||x.contains("vulnerab"))f.append("• ").append(line).append('\n');}
        high.setText(h+" High"); medium.setText(m+" Medium"); low.setText(l+" Low"); findings.setText(f.length()==0?"No structured severity markers detected. Review Raw Result for the full response.":f.toString());
    }

    private static String findContextField(JsonObject tool) { if(tool==null||!tool.has("inputSchema")||!tool.get("inputSchema").isJsonObject()) return null; JsonObject s=tool.getAsJsonObject("inputSchema"); if(!s.has("properties")||!s.get("properties").isJsonObject()) return null; JsonObject p=s.getAsJsonObject("properties"); for(String x:new String[]{"code","context","source","content","localContext","fileContent"}) if(p.has(x)) return x; return null; }
}
