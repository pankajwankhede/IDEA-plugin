package com.company.engineeringai.toolwindow;

import com.intellij.ui.JBColor;
import com.intellij.util.ui.JBUI;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

final class UiSupport {
    private UiSupport() {}

    static final Color BG = new Color(20, 26, 35);
    static final Color SURFACE = new Color(27, 35, 46);
    static final Color SURFACE_2 = new Color(32, 42, 55);
    static final Color BORDER = new Color(61, 76, 94);
    static final Color BLUE = new Color(34, 126, 246);
    static final Color CYAN = new Color(58, 207, 255);
    static final Color GREEN = new Color(61, 204, 107);
    static final Color YELLOW = new Color(255, 188, 48);
    static final Color RED = new Color(242, 80, 80);
    static final Color PURPLE = new Color(132, 92, 246);
    static final Color TEXT = new Color(232, 238, 246);
    static final Color MUTED = new Color(159, 172, 190);

    static JPanel card(LayoutManager layout) {
        JPanel panel = new RoundedPanel(layout, SURFACE, 14);
        panel.setBorder(JBUI.Borders.empty(12));
        panel.setOpaque(false);
        return panel;
    }

    static JPanel card() { return card(new BorderLayout(10, 10)); }

    static Border cardBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                JBUI.Borders.empty(10)
        );
    }

    static JLabel title(String text) {
        JLabel label = label(text, TEXT);
        Font base = label.getFont();
        label.setFont(base.deriveFont(Font.BOLD, base.getSize2D() + 5f));
        return label;
    }

    static JLabel subtitle(String text) {
        JLabel label = label(text, MUTED);
        Font base = label.getFont();
        label.setFont(base.deriveFont(base.getSize2D() + 1f));
        return label;
    }

    static JLabel section(String number, String text) {
        JPanel fake = null; // keeps call-sites simple; actual badge is encoded as HTML in label.
        Color c = switch (number) {
            case "1" -> PURPLE;
            case "2" -> GREEN;
            case "3" -> YELLOW;
            case "4" -> CYAN;
            default -> BLUE;
        };
        JLabel label = label("●  " + text, TEXT);
        label.setForeground(c);
        Font base = label.getFont();
        label.setFont(base.deriveFont(Font.BOLD, base.getSize2D() + 1f));
        label.setToolTipText("Step " + number);
        return label;
    }

    static JLabel muted(String text) { return label(text, MUTED); }
    static JLabel label(String text, Color color) { JLabel l = new JLabel(text); l.setForeground(color); return l; }

    static JLabel pill(String text, Color color) {
        JLabel label = new JLabel("  " + text + "  ");
        label.setOpaque(true);
        label.setForeground(Color.WHITE);
        label.setBackground(color);
        label.setBorder(JBUI.Borders.empty(4, 8));
        label.setFont(label.getFont().deriveFont(Font.BOLD));
        return label;
    }

    static JScrollPane scroll(Component component) {
        JScrollPane scroll = new JScrollPane(component);
        scroll.setBorder(JBUI.Borders.empty());
        scroll.getViewport().setBackground(SURFACE);
        scroll.setBackground(SURFACE);
        return scroll;
    }

    static JTextArea textArea(int rows, boolean editable) {
        JTextArea area = new JTextArea(rows, 30);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setEditable(editable);
        area.setBackground(SURFACE_2);
        area.setForeground(TEXT);
        area.setCaretColor(TEXT);
        area.setSelectionColor(BLUE.darker());
        area.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                JBUI.Borders.empty(8)
        ));
        return area;
    }

    static JTextField textField() {
        JTextField field = new JTextField();
        field.setBackground(SURFACE_2);
        field.setForeground(TEXT);
        field.setCaretColor(TEXT);
        field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER), JBUI.Borders.empty(6, 8)));
        return field;
    }

    static JPanel row(Component... components) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        panel.setOpaque(false);
        for (Component c : components) panel.add(c);
        return panel;
    }

    static JButton primaryButton(String text) {
        JButton b = new JButton(text);
        b.setForeground(Color.WHITE);
        b.setBackground(BLUE);
        b.setOpaque(true);
        b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BLUE.brighter()), JBUI.Borders.empty(8, 14)));
        b.setFocusPainted(false);
        b.setFont(b.getFont().deriveFont(Font.BOLD));
        return b;
    }

    static JButton ghostButton(String text) {
        JButton b = new JButton(text);
        b.setForeground(TEXT);
        b.setBackground(SURFACE_2);
        b.setOpaque(true);
        b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER), JBUI.Borders.empty(7, 12)));
        b.setFocusPainted(false);
        return b;
    }

    static void styleCombo(JComboBox<?> combo) {
        combo.setBackground(SURFACE_2);
        combo.setForeground(TEXT);
    }

    static void styleToggle(AbstractButton b) {
        b.setForeground(TEXT);
        b.setBackground(SURFACE_2);
        b.setFocusPainted(false);
    }

    static void styleTree(JTree tree) {
        tree.setBackground(SURFACE);
        tree.setForeground(TEXT);
        tree.setRootVisible(false);
        tree.setShowsRootHandles(true);
    }

    static void styleList(JList<?> list) {
        list.setBackground(SURFACE);
        list.setForeground(TEXT);
        list.setSelectionBackground(new Color(31, 86, 160));
        list.setSelectionForeground(Color.WHITE);
    }

    static String safe(Throwable t) {
        if (t == null) return "Unknown error";
        String message = t.getMessage();
        return message == null || message.isBlank() ? t.getClass().getName() : message;
    }

    private static final class RoundedPanel extends JPanel {
        private final Color fill;
        private final int radius;
        RoundedPanel(LayoutManager layout, Color fill, int radius) { super(layout); this.fill = fill; this.radius = radius; setOpaque(false); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(fill); g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.setColor(BORDER); g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, radius, radius);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
