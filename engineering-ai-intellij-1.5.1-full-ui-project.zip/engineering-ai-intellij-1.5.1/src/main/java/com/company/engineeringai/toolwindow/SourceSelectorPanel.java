package com.company.engineeringai.toolwindow;

import com.company.engineeringai.context.IdeContextProvider;
import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.nio.file.*;
import java.util.EnumMap;
import java.util.Map;

public final class SourceSelectorPanel extends JPanel {
    public enum SourceChoice {
        SELECTED_CODE("Selected Code"), CURRENT_FILE("Current File"), CHOOSE_FILE("Choose File..."), CHOOSE_FOLDER("Choose Folder...");
        private final String label; SourceChoice(String label) { this.label = label; } @Override public String toString() { return label; }
    }

    private final Project project;
    private final Map<SourceChoice, JToggleButton> buttons = new EnumMap<>(SourceChoice.class);
    private final JTextField pathField = UiSupport.textField();
    private final JButton browseButton = UiSupport.ghostButton("Browse...");
    private final JCheckBox includeSubfolders = new JCheckBox("Include subfolders", true);
    private final JButton previewButton = UiSupport.ghostButton("Preview Files");
    private SourceChoice choice = SourceChoice.CURRENT_FILE;
    private Path selectedPath;

    public SourceSelectorPanel(Project project) {
        super(new BorderLayout(8, 8));
        this.project = project;
        setOpaque(false);
        pathField.setEditable(false);

        JPanel choices = new JPanel(new GridLayout(1, 4, 8, 0)); choices.setOpaque(false);
        ButtonGroup group = new ButtonGroup();
        for (SourceChoice c : SourceChoice.values()) {
            JToggleButton b = new JToggleButton(c.toString()); UiSupport.styleToggle(b); buttons.put(c, b); group.add(b); choices.add(b);
            b.addActionListener(e -> { choice = c; if (c != SourceChoice.CHOOSE_FILE && c != SourceChoice.CHOOSE_FOLDER) selectedPath = null; refreshForChoice(); if (c == SourceChoice.CHOOSE_FILE || c == SourceChoice.CHOOSE_FOLDER) choosePath(); });
        }
        buttons.get(SourceChoice.CURRENT_FILE).setSelected(true);

        JPanel pathRow = new JPanel(new BorderLayout(8, 0)); pathRow.setOpaque(false); pathRow.add(pathField, BorderLayout.CENTER); pathRow.add(browseButton, BorderLayout.EAST);
        JPanel options = UiSupport.row(includeSubfolders, previewButton);
        browseButton.addActionListener(e -> choosePath()); previewButton.addActionListener(e -> showPreviewDialog());

        add(choices, BorderLayout.NORTH); add(pathRow, BorderLayout.CENTER); add(options, BorderLayout.SOUTH); refreshForChoice();
    }

    public void setChoice(SourceChoice choice) { this.choice = choice == null ? SourceChoice.CURRENT_FILE : choice; JToggleButton b = buttons.get(this.choice); if (b != null) b.setSelected(true); selectedPath = null; refreshForChoice(); }
    public SourceChoice choice() { return choice; }
    public Path selectedPath() { return selectedPath; }

    public String describeSource() {
        return switch (choice) {
            case SELECTED_CODE -> "Selected code in active editor";
            case CURRENT_FILE -> "Current file in active editor";
            case CHOOSE_FILE -> selectedPath == null ? "No file selected" : selectedPath.toString();
            case CHOOSE_FOLDER -> selectedPath == null ? "No folder selected" : selectedPath.toString();
        };
    }

    public String collectContext() throws Exception {
        return switch (choice) {
            case SELECTED_CODE -> IdeContextProvider.collectSelectedCode(project);
            case CURRENT_FILE -> IdeContextProvider.collectCurrentFile(project);
            case CHOOSE_FILE -> { if (selectedPath == null) throw new IllegalStateException("Choose a file first."); yield IdeContextProvider.collectFile(selectedPath); }
            case CHOOSE_FOLDER -> { if (selectedPath == null) throw new IllegalStateException("Choose a folder first."); yield IdeContextProvider.collectFolder(selectedPath); }
        };
    }

    public JTree buildPreviewTree() {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode(selectedPath == null ? "No folder selected" : selectedPath.getFileName());
        if (selectedPath != null && Files.isDirectory(selectedPath)) {
            int depth = includeSubfolders.isSelected() ? 8 : 1;
            try (var stream = Files.walk(selectedPath, depth)) {
                stream.filter(Files::isRegularFile).filter(this::isSupported).limit(80).forEach(p -> addPath(root, selectedPath, p));
            } catch (Exception e) { root.add(new DefaultMutableTreeNode("Unable to preview: " + e.getMessage())); }
        }
        JTree tree = new JTree(new DefaultTreeModel(root)); UiSupport.styleTree(tree); tree.setRootVisible(true); return tree;
    }

    private boolean isSupported(Path p) {
        String n = p.getFileName().toString().toLowerCase();
        return n.endsWith(".java") || n.endsWith(".kt") || n.endsWith(".xml") || n.endsWith(".yml") || n.endsWith(".yaml") || n.endsWith(".properties") || n.endsWith(".gradle") || n.endsWith(".kts") || n.endsWith(".js") || n.endsWith(".ts") || n.endsWith(".md");
    }

    private static void addPath(DefaultMutableTreeNode root, Path base, Path file) {
        DefaultMutableTreeNode node = root; Path rel = base.relativize(file);
        for (Path part : rel) {
            String name = part.toString(); DefaultMutableTreeNode child = null;
            for (int i = 0; i < node.getChildCount(); i++) { DefaultMutableTreeNode c = (DefaultMutableTreeNode) node.getChildAt(i); if (name.equals(c.getUserObject())) { child = c; break; } }
            if (child == null) { child = new DefaultMutableTreeNode(name); node.add(child); }
            node = child;
        }
    }

    private void refreshForChoice() {
        boolean browse = choice == SourceChoice.CHOOSE_FILE || choice == SourceChoice.CHOOSE_FOLDER;
        browseButton.setVisible(browse); includeSubfolders.setVisible(choice == SourceChoice.CHOOSE_FOLDER); previewButton.setVisible(choice == SourceChoice.CHOOSE_FOLDER);
        if (!browse) pathField.setText(choice == SourceChoice.SELECTED_CODE ? "Uses currently highlighted editor selection" : "Uses the active editor file");
        else pathField.setText(selectedPath == null ? (choice == SourceChoice.CHOOSE_FILE ? "Select a local file" : "Select a local folder") : selectedPath.toString());
        revalidate(); repaint();
    }

    private void choosePath() {
        FileChooserDescriptor descriptor = choice == SourceChoice.CHOOSE_FOLDER ? FileChooserDescriptorFactory.createSingleFolderDescriptor() : FileChooserDescriptorFactory.createSingleFileDescriptor();
        descriptor.setTitle(choice == SourceChoice.CHOOSE_FOLDER ? "Choose Source Folder" : "Choose Source File");
        VirtualFile file = FileChooser.chooseFile(descriptor, project, null); if (file != null) selectedPath = Path.of(file.getPath()); refreshForChoice();
    }

    private void showPreviewDialog() { if (selectedPath == null) { JOptionPane.showMessageDialog(this, "Choose a folder first."); return; } JScrollPane s = UiSupport.scroll(buildPreviewTree()); s.setPreferredSize(new Dimension(560, 420)); JOptionPane.showMessageDialog(this, s, "Selected Folder Preview", JOptionPane.PLAIN_MESSAGE); }
}
