package com.company.engineeringai.toolwindow;

import com.company.engineeringai.mcp.McpCapabilities;
import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public final class IntegrationStatusPanel extends JPanel {
    private final Map<String, JLabel> labels = new LinkedHashMap<>();
    private final JLabel none = UiSupport.muted("MCP capabilities not checked yet");

    public IntegrationStatusPanel() {
        super(new FlowLayout(FlowLayout.LEFT, 8, 2));
        setOpaque(false);
        add(UiSupport.muted("Available:"));
        for (String name : new String[]{"Knowledge", "Splunk", "New Relic", "PCF", "Oracle", "SQL Server", "Jenkins"}) {
            JLabel label = UiSupport.pill("✓ " + name, UiSupport.GREEN.darker());
            label.setVisible(false); labels.put(name, label); add(label);
        }
        add(none);
    }

    public void update(McpCapabilities c) {
        boolean any = false;
        any |= show("Knowledge", c != null && c.knowledge());
        any |= show("Splunk", c != null && c.splunk());
        any |= show("New Relic", c != null && c.newRelic());
        any |= show("PCF", c != null && c.pcf());
        any |= show("Oracle", c != null && c.oracle());
        any |= show("SQL Server", c != null && c.sqlServer());
        any |= show("Jenkins", c != null && c.jenkins());
        none.setVisible(!any); revalidate(); repaint();
    }

    private boolean show(String name, boolean visible) { JLabel l = labels.get(name); if (l != null) l.setVisible(visible); return visible; }
}
